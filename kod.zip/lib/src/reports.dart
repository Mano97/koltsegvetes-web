part of '../main.dart';

class Rpt {
  final bool year;
  final String title;
  final List<Tx> tx;
  final double inc, exp;
  final List<MapEntry<String, double>> byOut, byIn;
  final List<List<Object>> months;
  Rpt(this.year, this.title, this.tx, this.inc, this.exp, this.byOut, this.byIn, this.months);
  double get net => inc - exp;
}

class XB {
  final Object v;
  XB(this.v);
}

String tyLabel(Tx t) => tr(t.type == 'in' ? 'Bevétel' : (t.type == 'out' ? 'Kiadás' : (t.type == 'tr' ? 'Átvezetés' : (t.type == 'lend' ? 'Kölcsönadás' : (t.type == 'back' ? 'Visszakapott' : (t.type == 'xout' ? 'Átváltás (ki)' : 'Átváltás (be)'))))));

String xe(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

String colL(int i) {
  var s = '';
  i++;
  while (i > 0) {
    final m = (i - 1) % 26;
    s = String.fromCharCode(65 + m) + s;
    i = (i - 1) ~/ 26;
  }
  return s;
}

String sheetXml(List<List<Object?>> rows, List<int> widths) {
  final b = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>');
  for (var i = 0; i < widths.length; i++) {
    b.write('<col min="${i + 1}" max="${i + 1}" width="${widths[i]}" customWidth="1"/>');
  }
  b.write('</cols><sheetData>');
  for (var ri = 0; ri < rows.length; ri++) {
    b.write('<row r="${ri + 1}">');
    for (var ci = 0; ci < rows[ri].length; ci++) {
      Object? c = rows[ri][ci];
      var bold = false;
      if (c is XB) {
        bold = true;
        c = c.v;
      }
      if (c == null || c == '') continue;
      final ref = '${colL(ci)}${ri + 1}', st1 = bold ? ' s="1"' : '';
      if (c is num) {
        b.write('<c r="$ref"$st1><v>$c</v></c>');
      } else {
        b.write('<c r="$ref"$st1 t="inlineStr"><is><t xml:space="preserve">${xe('$c')}</t></is></c>');
      }
    }
    b.write('</row>');
  }
  b.write('</sheetData></worksheet>');
  return b.toString();
}

List<int> rptXlsx(Rpt r) {
  final rows = <List<Object?>>[
    [XB('${tr('Költségvetés')} – ${r.title}')],
    [],
    [XB(tr('Bevétel')), r.inc],
    [XB(tr('Kiadás')), r.exp],
    [XB(tr('Megtakarítás')), r.net],
    [],
  ];
  if (r.year) {
    rows.add([XB(tr('Hónap')), XB(tr('Bevétel')), XB(tr('Kiadás')), XB(tr('Megtakarítás'))]);
    for (final m in r.months) {
      rows.add(m);
    }
    rows.add([XB(tr('Összesen')), r.inc, r.exp, r.net]);
    rows.add([]);
  }
  void cat(String t, List<MapEntry<String, double>> l, double tot) {
    if (l.isEmpty) return;
    rows.add([XB(tr(t))]);
    rows.add([XB(tr('Kategória')), XB(tr('Összeg')), XB(tr('Arány'))]);
    for (final e in l) {
      rows.add([e.key, e.value, tot > 0 ? '${(e.value / tot * 100).toStringAsFixed(1)}%' : '']);
    }
    rows.add([]);
  }

  cat('Kiadások kategóriánként', r.byOut, r.exp);
  cat('Bevételek kategóriánként', r.byIn, r.inc);
  final t = <List<Object?>>[
    [XB(tr('Dátum')), XB(tr('Típus')), XB(tr('Tétel')), XB(tr('Megjegyzés')), XB(tr('Számla')), XB(tr('Összeg'))]
  ];
  for (final x in r.tx) {
    t.add([st.ymd(x.date), tyLabel(x), tr(st.title(x)), x.note, x.type == 'tr' ? '${tr(accName(x.acc))} → ${tr(accName(x.to))}' : tr(accName(x.acc)), (x.type == 'in' || x.type == 'back' || x.type == 'tr') ? x.amt : -x.amt]);
  }
  final files = <String, String>{
    '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
    '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
    'xl/workbook.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${xe(tr('Összesítő'))}" sheetId="1" r:id="rId1"/><sheet name="${xe(tr('Tételek'))}" sheetId="2" r:id="rId2"/></sheets></workbook>',
    'xl/_rels/workbook.xml.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
    'xl/styles.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>',
    'xl/worksheets/sheet1.xml': sheetXml(rows, [34, 16, 16, 16]),
    'xl/worksheets/sheet2.xml': sheetXml(t, [12, 14, 34, 28, 22, 14]),
  };
  final a = Archive();
  files.forEach((n, c) {
    final b = utf8.encode(c);
    a.addFile(ArchiveFile(n, b.length, b));
  });
  return ZipEncoder().encode(a)!;
}

String rptHtml(Rpt r) {
  String n(double v) => '<td class="n">${xe(ft(v))}</td>';
  final b = StringBuffer('<html><head><meta charset="utf-8"><style>body{font-family:sans-serif;color:#000;font-size:12px}h1{font-size:20px}h2{font-size:15px;margin:16px 0 6px}table{border-collapse:collapse;width:100%}td,th{border-bottom:1px solid #bbb;padding:4px 6px;text-align:left}.n{text-align:right;white-space:nowrap}</style></head><body>');
  b.write('<h1>${xe(tr('Költségvetés'))} – ${xe(r.title)}</h1><table><tr><td>${xe(tr('Bevétel'))}</td>${n(r.inc)}</tr><tr><td>${xe(tr('Kiadás'))}</td>${n(r.exp)}</tr><tr><td><b>${xe(tr('Megtakarítás'))}</b></td>${n(r.net)}</tr></table>');
  if (r.year) {
    b.write('<h2>${xe(tr('Hónap'))}</h2><table><tr><th>${xe(tr('Hónap'))}</th><th class="n">${xe(tr('Bevétel'))}</th><th class="n">${xe(tr('Kiadás'))}</th><th class="n">${xe(tr('Megtakarítás'))}</th></tr>');
    for (final m in r.months) {
      b.write('<tr><td>${xe('${m[0]}')}</td>${n(m[1] as double)}${n(m[2] as double)}${n(m[3] as double)}</tr>');
    }
    b.write('<tr><td><b>${xe(tr('Összesen'))}</b></td>${n(r.inc)}${n(r.exp)}${n(r.net)}</tr></table>');
  }
  void cat(String t, List<MapEntry<String, double>> l, double tot) {
    if (l.isEmpty) return;
    b.write('<h2>${xe(tr(t))}</h2><table>');
    for (final e in l) {
      b.write('<tr><td>${xe(e.key)}</td>${n(e.value)}<td class="n">${tot > 0 ? (e.value / tot * 100).round() : 0}%</td></tr>');
    }
    b.write('</table>');
  }

  cat('Kiadások kategóriánként', r.byOut, r.exp);
  cat('Bevételek kategóriánként', r.byIn, r.inc);
  b.write('<h2>${xe(tr('Tételek'))}</h2><table><tr><th>${xe(tr('Dátum'))}</th><th>${xe(tr('Típus'))}</th><th>${xe(tr('Tétel'))}</th><th>${xe(tr('Számla'))}</th><th class="n">${xe(tr('Összeg'))}</th></tr>');
  for (final x in r.tx) {
    final acc = x.type == 'tr' ? '${tr(accName(x.acc))} → ${tr(accName(x.to))}' : tr(accName(x.acc));
    b.write('<tr><td>${x.date.year}. ${x.date.month.toString().padLeft(2, '0')}. ${x.date.day.toString().padLeft(2, '0')}.</td><td>${xe(tyLabel(x))}</td><td>${xe(tr(st.title(x)))}${x.note.isEmpty ? '' : ' – ${xe(x.note)}'}</td><td>${xe(acc)}</td>${n(x.amt)}</tr>');
  }
  b.write('</table></body></html>');
  return b.toString();
}

final launchAdd = ValueNotifier<int>(0);
String recDir = '';

