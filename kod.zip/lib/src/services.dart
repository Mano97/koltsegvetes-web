part of '../main.dart';

final _np = FlutterLocalNotificationsPlugin();

Future<void> initNotif() async {
  try {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Europe/Budapest'));
    await _np.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')), onDidReceiveNotificationResponse: (r) {
      if (r.actionId == 'add' || r.payload == 'add') launchAdd.value++;
    });
    await rescheduleAll();
  } catch (_) {}
}

Future<void> notifPerm() async {
  try {
    await _np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
  } catch (_) {}
}

Future<void> rescheduleAll() async {
  if (st.ws != 'huf') return;
  try {
    await _np.cancelAll();
    if (st.remOn) await scheduleReminder(TimeOfDay(hour: st.remH, minute: st.remM), ask: false);
    await schedulePayReminders();
    await scheduleLoanReminders();
    await scheduleRecvReminders();
  } catch (_) {}
}

Future<void> scheduleRecvReminders() async {
  if (st.payRem < 0) return;
  try {
    final now = tz.TZDateTime.now(tz.local);
    var id = 4000;
    for (final r in st.recvs) {
      final rem = st.recvRem(r);
      if (rem <= 0 || r.due.isEmpty) continue;
      final due = DateTime.parse(r.due);
      final at = tz.TZDateTime(tz.local, due.year, due.month, due.day, 9).subtract(Duration(days: st.payRem));
      if (at.isBefore(now)) continue;
      await _np.zonedSchedule(
        id++,
        tr('Kintlévőség'),
        trf('Esedékes a(z) {0} tartozása: {1} ({2})', [r.name, ft(rem), dfm('MMMM d.', due)]),
        at,
        NotificationDetails(android: AndroidNotificationDetails('payments2', tr('Fizetési emlékeztetők'), importance: Importance.high, priority: Priority.high)),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      );
    }
  } catch (_) {}
}

Future<void> scheduleLoanReminders() async {
  if (st.payRem < 0) return;
  try {
    final now = tz.TZDateTime.now(tz.local);
    var id = 3000;
    for (final l in st.loans) {
      if (st.loanRem(l) <= 0) continue;
      final ep = l.end.split('-');
      final endIdx = int.parse(ep[0]) * 12 + int.parse(ep[1]);
      for (var k = 0; k < 12; k++) {
        final m = DateTime(now.year, now.month + k);
        if (m.year * 12 + m.month > endIdx) break;
        if (k == 0 && st.loanPaidMonth(l, now)) continue;
        final dim = DateUtils.getDaysInMonth(m.year, m.month);
        final due = DateTime(m.year, m.month, l.day < dim ? l.day : dim);
        final at = tz.TZDateTime(tz.local, due.year, due.month, due.day, 9).subtract(Duration(days: st.payRem));
        if (at.isBefore(now)) continue;
        await _np.zonedSchedule(
          id++,
          tr('Hitel törlesztés'),
          '${l.name}: ${ft(l.pay)} (${dfm('MMMM d.', due)})',
          at,
          NotificationDetails(android: AndroidNotificationDetails('payments2', tr('Fizetési emlékeztetők'), importance: Importance.high, priority: Priority.high)),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    }
  } catch (_) {}
}

Future<void> schedulePayReminders() async {
  if (st.payRem < 0) return;
  try {
    final now = tz.TZDateTime.now(tz.local);
    var id = 2000;
    for (final r in st.rec) {
      if (r.type != 'out') continue;
      for (var k = 0; k < 12; k++) {
        final m = DateTime(now.year, now.month + k);
        final dim = DateUtils.getDaysInMonth(m.year, m.month);
        final due = DateTime(m.year, m.month, r.day < dim ? r.day : dim);
        final at = tz.TZDateTime(tz.local, due.year, due.month, due.day, 9).subtract(Duration(days: st.payRem));
        if (at.isBefore(now)) continue;
        await _np.zonedSchedule(
          id++,
          tr('Fizetési emlékeztető'),
          '${st.recName(r)}: ${ft(r.amt)} (${dfm('MMMM d.', due)})',
          at,
          NotificationDetails(android: AndroidNotificationDetails('payments2', tr('Fizetési emlékeztetők'), importance: Importance.high, priority: Priority.high)),
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    }
  } catch (_) {}
}

Future<String?> scheduleReminder(TimeOfDay t, {bool ask = true}) async {
  try {
    if (ask) await _np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
    final now = tz.TZDateTime.now(tz.local);
    var at = tz.TZDateTime(tz.local, now.year, now.month, now.day, t.hour, t.minute);
    if (at.isBefore(now)) at = at.add(const Duration(days: 1));
    await _np.zonedSchedule(
      1,
      tr('Költségvetés'),
      tr('Rögzítetted ma a költéseidet?'),
      at,
      NotificationDetails(android: AndroidNotificationDetails('reminder2', tr('Napi emlékeztető'), importance: Importance.high, priority: Priority.high, actions: [AndroidNotificationAction('add', tr('Rögzítek egy kiadást'), showsUserInterface: true)])),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      payload: 'add',
      matchDateTimeComponents: DateTimeComponents.time,
    );
    return null;
  } catch (e) {
    return '$e';
  }
}

Future<bool> notifEnabled() async {
  try {
    return await _np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.areNotificationsEnabled() ?? true;
  } catch (_) {
    return true;
  }
}

Future<void> notifPermOnce() async {
  try {
    final p = await SharedPreferences.getInstance();
    if (p.getBool('notifAsked') ?? false) return;
    await p.setBool('notifAsked', true);
    await notifPerm();
  } catch (_) {}
}

Future<String?> notifTest(bool delayed) async {
  try {
    final impl = _np.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await impl?.requestNotificationsPermission();
    if (!(await impl?.areNotificationsEnabled() ?? true)) return 'off';
    final details = NotificationDetails(android: AndroidNotificationDetails('reminder2', tr('Napi emlékeztető'), importance: Importance.high, priority: Priority.high));
    if (!delayed) {
      await _np.show(9001, tr('Költségvetés'), tr('Ez egy teszt értesítés.'), details);
    } else {
      final at = tz.TZDateTime.now(tz.local).add(const Duration(seconds: 60));
      await _np.zonedSchedule(9002, tr('Költségvetés'), tr('Ez egy időzített teszt értesítés.'), at, details, androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle, uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime);
    }
    return null;
  } catch (e) {
    return '$e';
  }
}

Future<void> cancelReminder() async {
  try {
    await _np.cancel(1);
  } catch (_) {}
}

final st = AppState();

Future<String> encText(String txt, String pw) async {
  final rnd = Random.secure();
  final salt = List<int>.generate(16, (_) => rnd.nextInt(256));
  final iv = List<int>.generate(12, (_) => rnd.nextInt(256));
  const it = 200000;
  final key = await cr.Pbkdf2(macAlgorithm: cr.Hmac.sha256(), iterations: it, bits: 256).deriveKeyFromPassword(password: pw, nonce: salt);
  final box = await cr.AesGcm.with256bits().encrypt(utf8.encode(txt), secretKey: key, nonce: iv);
  return jsonEncode({'kv': 'enc1', 'kdf': 'pbkdf2-sha256', 'iter': it, 'salt': base64.encode(salt), 'iv': base64.encode(iv), 'data': base64.encode(box.concatenation(nonce: false))});
}

Future<String> decText(Map o, String pw) async {
  final salt = base64.decode(o['salt'] as String), iv = base64.decode(o['iv'] as String), data = base64.decode(o['data'] as String);
  final key = await cr.Pbkdf2(macAlgorithm: cr.Hmac.sha256(), iterations: (o['iter'] as int?) ?? 200000, bits: 256).deriveKeyFromPassword(password: pw, nonce: salt);
  final box = cr.SecretBox(data.sublist(0, data.length - 16), nonce: iv, mac: cr.Mac(data.sublist(data.length - 16)));
  return utf8.decode(await cr.AesGcm.with256bits().decrypt(box, secretKey: key));
}

Future<Directory> snapDir() async {
  final d = Directory('${(await getApplicationDocumentsDirectory()).path}/snapshots');
  if (!await d.exists()) await d.create(recursive: true);
  return d;
}

Future<void> snapNow([String label = '']) async {
  try {
    if (st.txs.isEmpty && st.cats.isEmpty && st.recvs.isEmpty && st.loans.isEmpty) return;
    final dataF = st.fullBackup();
    final dir = await snapDir();
    final data = await dataF;
    final now = DateTime.now();
    final day = st.ymd(now);
    final name = label.isEmpty ? 'auto-$day.json' : 'pre-$day-${now.millisecondsSinceEpoch}-$label.json';
    final f = File('${dir.path}/$name');
    if (label.isEmpty && await f.exists()) return;
    await f.writeAsString(data);
    final files = (await dir.list().toList()).whereType<File>().toList();
    for (final p in ['auto-', 'pre-']) {
      final l = files.where((x) => x.uri.pathSegments.last.startsWith(p)).toList()..sort((a, b) => a.path.compareTo(b.path));
      final keep = p == 'auto-' ? 7 : 3;
      for (var i = 0; i < l.length - keep; i++) {
        await l[i].delete();
      }
    }
  } catch (_) {}
}

Future<List<File>> snapFiles() async {
  try {
    final dir = await snapDir();
    final l = (await dir.list().toList()).whereType<File>().toList();
    l.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    return l;
  } catch (_) {
    return <File>[];
  }
}

String snapLabel(File f) {
  final n = f.uri.pathSegments.last.replaceAll('.json', '');
  final day = n.startsWith('auto-') ? n.substring(5, 15) : n.substring(4, 14);
  final p = day.split('-');
  final txt = '${p[0]}. ${p[1]}. ${p[2]}.';
  if (n.endsWith('-restore')) return '$txt (${tr('Visszatöltés előtt')})';
  if (n.endsWith('-wipe')) return '$txt (${tr('Törlés előtt')})';
  return txt;
}

