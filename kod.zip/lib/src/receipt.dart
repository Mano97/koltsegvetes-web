part of '../main.dart';

// ---------- nyugta beolvasás ----------
class RcItem {
  String name;
  double amt;
  RcItem(this.name, this.amt);
}

class RcParsed {
  final String store, date;
  final List<RcItem> items;
  final double sum, total, diff;
  RcParsed(this.store, this.date, this.items, this.sum, this.total, this.diff);
}

class _NqAmt {
  final String name;
  final double amt;
  _NqAmt(this.name, this.amt);
}

String nqNorm(String s) {
  const from = 'áéíóöőúüűôõûũ';
  const to = 'aeiooouuuoouu';
  final b = StringBuffer();
  for (final r in s.toLowerCase().runes) {
    final c = String.fromCharCode(r);
    final i = from.indexOf(c);
    b.write(i >= 0 ? to[i] : c);
  }
  return b.toString();
}

double? nqNum(String t) {
  var s = t.replaceAll(RegExp(r'\s+'), '').replaceAll(RegExp(r'[^\d,.\-]'), '');
  if (s.isEmpty) return null;
  final neg = s.startsWith('-');
  s = s.replaceAll('-', '');
  final c = s.lastIndexOf(','), d = s.lastIndexOf('.');
  if (c >= 0 && d >= 0) {
    final dec = c > d ? c : d;
    s = '${s.substring(0, dec).replaceAll(RegExp(r'[.,]'), '')}.${s.substring(dec + 1)}';
  } else if (c >= 0) {
    if (RegExp(r'^\d{1,3}(,\d{3})+$').hasMatch(s)) {
      s = s.replaceAll(',', '');
    } else if (RegExp(r',\d{1,2}$').hasMatch(s)) {
      s = s.replaceFirst(',', '.');
    } else {
      s = s.replaceAll(',', '');
    }
  } else if (d >= 0) {
    if (RegExp(r'^\d{1,3}(\.\d{3})+$').hasMatch(s)) s = s.replaceAll('.', '');
  }
  final v = double.tryParse(s);
  if (v == null) return null;
  return neg ? -v : v;
}

final _nqSkip = RegExp(r'osszesen|fizetend|vegosszeg|reszosszeg|\bafa\b|adoalap|adoszam|\bado\b|keszpenz|bankkartya|bank kartya|visszajar|nyugta|szamlaszam|penztar|kassza|bizonylat|\btel\b|telefon|www\.|http|koszon|kerekit|szepkartya|sorszam|blokk|idopont|datum|elado|vevo|nyitva|hunseg|pontok|utalvany|ellenertek|\bmod\b|e-?mail|kartyaszam|engedelyszam|tranzakcio|terminal|\baid\b|\bvisa\b|mastercard|maestro|vasarlas|fizetes|netto|kapott|adott|atvett|fizetve');
final _nqAddr = RegExp(r'\b(utca|ut|utja|ter|tere|korut|krt|setany|koz|fasor|rakpart)\b\.?|^\s*\d{4}\s+[a-z]|\d{8}-\d-\d{2}');
const _nqStores = <List<String>>[
  ['interspar', 'Interspar'], ['lidl', 'Lidl'], ['aldi', 'Aldi'], ['spar', 'Spar'], ['tesco', 'Tesco'], ['auchan', 'Auchan'], ['coop', 'Coop'], ['penny', 'Penny'], ['cba', 'CBA'], ['real', 'Reál'],
  ['rossmann', 'Rossmann'], ['dm', 'dm'], ['muller', 'Müller'], ['mol', 'MOL'], ['shell', 'Shell'], ['omv', 'OMV'], ['mcdonald', 'McDonald’s'], ['kfc', 'KFC'], ['burger king', 'Burger King'],
  ['ikea', 'IKEA'], ['obi', 'OBI'], ['media markt', 'MediaMarkt'], ['decathlon', 'Decathlon'], ['gyogyszertar', 'Gyógyszertár'], ['patika', 'Patika'],
];

String nqDate(String t, DateTime now0) {
  var y = 0, mo = 0, d = 0;
  var ok = false;
  var m = RegExp(r'(20\d{2})\s?[.\-/]\s?(\d{1,2})\s?[.\-/]\s?(\d{1,2})').firstMatch(t);
  if (m != null) {
    y = int.parse(m.group(1)!);
    mo = int.parse(m.group(2)!);
    d = int.parse(m.group(3)!);
    ok = true;
  } else {
    m = RegExp(r'(\d{1,2})\s?[.\-/]\s?(\d{1,2})\s?[.\-/]\s?(20\d{2})').firstMatch(t);
    if (m != null) {
      d = int.parse(m.group(1)!);
      mo = int.parse(m.group(2)!);
      y = int.parse(m.group(3)!);
      ok = true;
    }
  }
  if (ok && mo >= 1 && mo <= 12 && d >= 1 && d <= 31) return '$y-${mo.toString().padLeft(2, '0')}-${d.toString().padLeft(2, '0')}';
  return '${now0.year}-${now0.month.toString().padLeft(2, '0')}-${now0.day.toString().padLeft(2, '0')}';
}

String nqStore(List<String> lines, String text) {
  final n = nqNorm(text);
  for (final st0 in _nqStores) {
    if (RegExp('(^|[^a-z])${RegExp.escape(st0[0])}([^a-z]|\$)').hasMatch(n)) return st0[1];
  }
  for (final l in lines.take(6)) {
    final t = l.trim(), nl = nqNorm(t);
    final letters = t.replaceAll(RegExp(r'[^A-Za-zÁÉÍÓÖŐÚÜŰáéíóöőúüű]'), '').length;
    if (letters >= 3 && !RegExp(r'nyugta|adoszam|szamla|\d{4}\s').hasMatch(nl) && !_nqAddr.hasMatch(nl)) {
      final r = t.replaceAll(RegExp(r'\b(kft|zrt|nyrt|bt|rt|kkt)\b\.?', caseSensitive: false), '').replaceAll(RegExp(r'\s+'), ' ').replaceAll(RegExp(r'[,.\s]+$'), '').trim();
      return r.length > 30 ? r.substring(0, 30) : r;
    }
  }
  return '';
}

String nqClean(String name) {
  var s = name
      .replaceAll(RegExp(r'\s+\d+[,.]?\d*\s*(?:kg|g|db|l|dl|cl|ml)?\s*[x×*]\s*\d[\d.,]*', caseSensitive: false), '')
      .replaceAll(RegExp(r'\s+\d+\s*db\b', caseSensitive: false), '')
      .replaceFirst(RegExp(r'^\d{6,}\s+'), '')
      .replaceAll(RegExp(r'[*#]+$'), '')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (s == s.toUpperCase() && RegExp(r'[A-ZÁÉÍÓÖŐÚÜŰ]{2}').hasMatch(s)) s = s.toLowerCase();
  return s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}

_NqAmt? nqAmtAt(String line) {
  final s = line.replaceFirst(RegExp(r'\s+$'), '').replaceFirst(RegExp(r'\s*(?:ft|huf)\.?\s*$', caseSensitive: false), '').replaceFirst(RegExp(r'\s+(?:[A-E]|\d{1,2}\s?%)\s*$'), '');
  final m = RegExp(r'^(.*\S)\s{2,}(-?\d[\d .]*(?:[,.]\d{1,2})?)$').firstMatch(s) ?? RegExp(r'^(.*[^\d\s.,-])\s+(-?\d[\d .]*(?:[,.]\d{1,2})?)$').firstMatch(s);
  if (m == null) return null;
  final a = nqNum(m.group(2)!);
  if (a == null) return null;
  return _NqAmt(m.group(1)!.trim(), a);
}

double? nqLastNum(String line) {
  final m = RegExp(r'(-?\d[\d .]*(?:[,.]\d{1,2})?)\s*(?:ft|huf|f)?\.?\s*(?:[a-e]|\d{1,2}\s?%)?\s*$', caseSensitive: false).firstMatch(line.replaceFirst(RegExp(r'\s+$'), ''));
  return m == null ? null : nqNum(m.group(1)!);
}

RcParsed parseReceipt(String text, DateTime now0) {
  final lines = text.split(RegExp(r'\r?\n')).map((l) => l.replaceAll('\t', '  ').replaceFirst(RegExp(r'\s+$'), '')).where((l) => l.trim().isNotEmpty).toList();
  final items = <RcItem>[];
  final fiz = <double>[], oss = <double>[], kar = <double>[];
  var pending = '';
  final qty = RegExp(r'^\s*(\d+(?:[,.]\d+)?)\s*(?:db|kg|l)?\s*[x×*]\s*(\d+(?:[.,]\d{1,2})?)\s*(?:ft|huf)?(?:/\w+)?(?:\s*=?\s*(\d[\d .]*(?:[,.]\d{1,2})?))?\s*(?:[A-Ea-e])?\s*$', caseSensitive: false);
  for (final raw in lines) {
    final l = raw.trim(), n = nqNorm(l);
    final a0 = nqLastNum(l);
    if (RegExp(r'fizetend|fizetett|fizetve').hasMatch(n)) {
      if (a0 != null) fiz.add(a0);
      pending = '';
      continue;
    }
    if (RegExp(r'ossz|oszz|vegossz|szumma|summa|brutto|\btotal\b|osszeg').hasMatch(n) && !RegExp(r'reszossz|netto').hasMatch(n)) {
      if (a0 != null) oss.add(a0);
      pending = '';
      continue;
    }
    if (RegExp(r'bankkartya|bank kartya|keszpenz|kartya|kapott|adott|atvett').hasMatch(n) && a0 != null) {
      kar.add(a0);
      pending = '';
      continue;
    }
    if (RegExp(r'kedvezm|engedm|akcio|leertek').hasMatch(n)) {
      if (items.isNotEmpty && a0 != null && a0 != 0) items.last.amt -= a0.abs();
      continue;
    }
    if (n.contains('kerekit')) continue;
    final q = qty.firstMatch(l);
    if (q != null) {
      if (pending.isNotEmpty) {
        final un = nqNum(q.group(2)!) ?? 0;
        final tt = q.group(3) != null ? (nqNum(q.group(3)!) ?? 0) : ((nqNum(q.group(1)!) ?? 0) * un).roundToDouble();
        if (tt > 0) items.add(RcItem(nqClean(pending), tt));
        pending = '';
      }
      continue;
    }
    if (_nqSkip.hasMatch(n) || _nqAddr.hasMatch(n)) continue;
    final r = nqAmtAt(l);
    if (r != null) {
      final nm = nqClean(r.name);
      if (r.amt > 0 && r.amt < 5e6 && nm.replaceAll(RegExp(r'[^A-Za-zÁÉÍÓÖŐÚÜŰáéíóöőúüű]'), '').length >= 2) {
        items.add(RcItem(nm, r.amt));
        pending = '';
      }
      continue;
    }
    pending = RegExp(r'[A-Za-zÁÉÍÓÖŐÚÜŰáéíóöőúüű]{2}').hasMatch(l) ? l : '';
  }
  if (items.length >= 3) {
    final s0 = items.fold(0.0, (a, t) => a + t.amt);
    for (var i = items.length - 1; i >= 0; i--) {
      final o = s0 - items[i].amt;
      final tol = items[i].amt * 0.003 > 1 ? items[i].amt * 0.003 : 1.0;
      if ((items[i].amt - o).abs() <= tol) {
        oss.add(items[i].amt);
        items.removeAt(i);
        break;
      }
    }
  }
  final sum = items.fold(0.0, (a, t) => a + t.amt);
  double? pick(List<double> a) => a.isEmpty ? null : a.last;
  var total = pick(fiz) ?? pick(oss) ?? pick(kar);
  if (total == null || total <= 0) total = sum;
  return RcParsed(nqStore(lines, text), nqDate(text, now0), items, sum, total, ((total - sum) * 100).round() / 100);
}

final _nqRoles = <MapEntry<String, RegExp>>[
  MapEntry('fuel', RegExp(r'benzin|gazolaj|dizel|diesel|uzemanyag|\b95\b|\be10\b|autopalya|matrica|parkol')),
  MapEntry('drug', RegExp(r'fogkrem|sampon|szappan|tusfurdo|wc.?papir|zsebkendo|mosopor|oblito|mosogato|tisztito|szemeteszsak|pelenka|dezodor|boritva')),
  MapEntry('rest', RegExp(r'etterem|menu\b|ebed|vacsora|pizza|burger|kebab|gyros|cappuccino|latte')),
  MapEntry('food', RegExp(r'tej|kenyer|kifli|zsemle|sajt|sonka|kolbasz|szalami|tojas|alma|banan|paradicsom|paprika|burgonya|krumpli|hagyma|salata|uborka|\bhus\b|csirke|sertes|marha|\bhal\b|teszta|rizs|liszt|cukor|\bso\b|olaj|\bvaj\b|margarin|joghurt|turo|tejfol|\bsor\b|\bbor\b|\bviz\b|udito|cola|juice|kave|\btea\b|csoki|keksz|chips|fagyi|muzli|lekvar|\bmez\b|snickers|szendvics|pekaru|zoldseg|gyumolcs')),
];
const _nqRoleCat = {'food': r'etel|elelmiszer|bevasarl|kaja|food|ennivalo', 'drug': r'drog|haztartas|tisztalkod|otthon|lakas', 'fuel': r'kozlekedes|uzemanyag|auto|benzin|utazas', 'rest': r'etterem|vendeglat|etkez|kavezo'};
const _nqStoreRole = {'lidl': 'food', 'aldi': 'food', 'interspar': 'food', 'spar': 'food', 'tesco': 'food', 'auchan': 'food', 'coop': 'food', 'penny': 'food', 'cba': 'food', 'real': 'food', 'rossmann': 'drug', 'dm': 'drug', 'muller': 'drug', 'mol': 'fuel', 'shell': 'fuel', 'omv': 'fuel', 'mcdonald': 'rest', 'kfc': 'rest', 'burger king': 'rest'};

String nqKey(String s) => nqNorm(s).replaceAll(RegExp(r'[^a-z0-9 ]'), '').replaceAll(RegExp(r'\s+'), ' ').trim();

String nqRoleCat(String role) {
  final re = _nqRoleCat[role];
  if (re == null) return '';
  final r = RegExp(re);
  for (final c in st.cats) {
    if (r.hasMatch(nqNorm(c.name))) return c.id;
  }
  return '';
}

class NqSug {
  final String cat, item;
  NqSug(this.cat, this.item);
}

NqSug nqSuggest(String name, String store) {
  final nl = nqNorm(name);
  var cat = '', item = '';
  final lk = st.rcl[nqKey(name)];
  if (lk != null) {
    final p = lk.split('|');
    if (st.cats.any((c) => c.id == p[0])) {
      cat = p[0];
      item = p.length > 1 ? p[1] : '';
    }
  }
  if (cat.isEmpty) {
    for (final r in _nqRoles) {
      if (r.value.hasMatch(nl)) {
        cat = nqRoleCat(r.key);
        break;
      }
    }
  }
  if (cat.isEmpty && store.isNotEmpty) {
    final sk = st.rcl['store:${nqKey(store)}'];
    if (sk != null && st.cats.any((c) => c.id == sk)) cat = sk;
  }
  if (cat.isEmpty && store.isNotEmpty) {
    final ns = nqNorm(store);
    for (final k in _nqStoreRole.keys) {
      if (ns.contains(k)) {
        cat = nqRoleCat(_nqStoreRole[k]!);
        break;
      }
    }
  }
  if (cat.isEmpty && st.cats.isNotEmpty) cat = st.cats.first.id;
  if (cat.isNotEmpty && item.isEmpty) {
    for (final c in st.cats) {
      if (c.id != cat) continue;
      for (final it in c.items) {
        if (it.name.length >= 3 && nl.contains(nqNorm(it.name))) {
          item = it.id;
          break;
        }
      }
    }
  }
  return NqSug(cat, item);
}

String nqPickCat(RcParsed p) {
  if (p.store.isNotEmpty) {
    final lk = st.rcl['store:${nqKey(p.store)}'];
    if (lk != null && st.cats.any((c) => c.id == lk)) return lk;
  }
  final sm = <String, double>{};
  for (final it in p.items) {
    final g = nqSuggest(it.name, p.store);
    if (g.cat.isNotEmpty) sm[g.cat] = (sm[g.cat] ?? 0) + it.amt;
  }
  if (sm.isNotEmpty) {
    final e = sm.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return e.first.key;
  }
  return st.cats.isEmpty ? '' : st.cats.first.id;
}

class _OL {
  final String t;
  final Rect r;
  _OL(this.t, this.r);
}

Future<String> ocrReceipt(String path) async {
  final rec = mlk.TextRecognizer(script: mlk.TextRecognitionScript.latin);
  try {
    final res = await rec.processImage(mlk.InputImage.fromFilePath(path));
    final ls = <_OL>[
      for (final b in res.blocks)
        for (final l in b.lines) _OL(l.text, l.boundingBox)
    ];
    ls.sort((a, b) => a.r.center.dy.compareTo(b.r.center.dy));
    final rows = <List<_OL>>[];
    for (final l in ls) {
      if (rows.isNotEmpty) {
        final last = rows.last;
        final cy = last.map((x) => x.r.center.dy).reduce((a, b) => a + b) / last.length;
        final h = last.map((x) => x.r.height).reduce((a, b) => a > b ? a : b);
        if ((l.r.center.dy - cy).abs() < h * 0.55) {
          last.add(l);
          continue;
        }
      }
      rows.add([l]);
    }
    return rows.map((r) {
      r.sort((a, b) => a.r.left.compareTo(b.r.left));
      return r.map((x) => x.t).join('  ');
    }).join('\n');
  } finally {
    await rec.close();
  }
}

class _RcLine {
  final TextEditingController name, amt;
  String cat, item;
  bool on;
  _RcLine(String n, String a, this.cat, this.item, this.on)
      : name = TextEditingController(text: n),
        amt = TextEditingController(text: a);
}

class ReceiptReview extends StatefulWidget {
  final RcParsed parsed;
  final String? photoPath;
  const ReceiptReview(this.parsed, this.photoPath, {super.key});
  @override
  State<ReceiptReview> createState() => _ReceiptReviewState();
}

class _ReceiptReviewState extends State<ReceiptReview> {
  late final TextEditingController store;
  late DateTime date;
  var acc = 'card';
  var single = true;
  late String cat;
  late final List<_RcLine> lines;

  @override
  void initState() {
    super.initState();
    final p = widget.parsed;
    store = TextEditingController(text: p.store);
    cat = nqPickCat(p);
    final dp = p.date.split('-');
    date = DateTime(int.parse(dp[0]), int.parse(dp[1]), int.parse(dp[2]));
    lines = [for (final it in p.items) mkLine(it, p.store)];
    if (lines.isEmpty) lines.add(_RcLine('', '', st.cats.isEmpty ? '' : st.cats.first.id, '', true));
  }

  _RcLine mkLine(RcItem it, String sn) {
    final g = nqSuggest(it.name, sn);
    return _RcLine(it.name, amtStr(it.amt), g.cat, g.item, true);
  }

  double amtOf(_RcLine l) => double.tryParse(l.amt.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;

  void save() {
    final on = lines.where((l) => l.on && amtOf(l) > 0 && (single || l.cat.isNotEmpty)).toList();
    if (on.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Nincs elkönyvelhető sor.')));
      return;
    }
    final sn = store.text.trim();
    final rows = <List<Object>>[];
    if (single) {
      if (cat.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Előbb hozz létre egy kategóriát a Kategóriák menüben (☰).')));
        return;
      }
      final tot = on.fold(0.0, (a, l) => a + amtOf(l));
      rows.add([cat, '', (tot * 100).round() / 100, sn.length > 160 ? sn.substring(0, 160) : sn]);
    } else {
      for (final l in on) {
        final note = l.name.text + (sn.isEmpty ? '' : ' · $sn');
        rows.add([l.cat, l.item, amtOf(l), note.length > 160 ? note.substring(0, 160) : note]);
      }
    }
    final total = rows.fold(0.0, (a, r) => a + (r[2] as double));
    void go() {
      final ids = <String>[];
      st.change(() {
        for (var k = 0; k < rows.length; k++) {
          final r = rows[k];
          final id = uid();
          ids.add(id);
          var ph = false;
          if (k == 0 && widget.photoPath != null) {
            try {
              File(widget.photoPath!).copySync('$recDir/$id.jpg');
              ph = true;
            } catch (_) {}
          }
          st.txs.add(Tx(id: id, type: 'out', acc: acc, cat: r[0] as String, item: r[1] as String, amt: r[2] as double, date: DateTime(date.year, date.month, date.day), note: r[3] as String, tags: const ['nyugta'], ph: ph, rl: single ? [for (final l in on) {'n': l.name.text, 'a': amtOf(l)}] : <Map<String, dynamic>>[], rs: single ? sn : ''));
        }
        if (!single) {
          for (final l in on) {
            final k = nqKey(l.name.text);
            if (k.isNotEmpty) st.rcl[k] = '${l.cat}|${l.item}';
          }
        }
        if (sn.isNotEmpty && single) {
          st.rcl['store:${nqKey(sn)}'] = cat;
        } else if (sn.isNotEmpty) {
          final cnt = <String, int>{};
          for (final l in on) {
            cnt[l.cat] = (cnt[l.cat] ?? 0) + 1;
          }
          final top = cnt.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
          if (top.isNotEmpty) st.rcl['store:${nqKey(sn)}'] = top.first.key;
        }
        st.month = DateTime(date.year, date.month);
      });
      Navigator.pop(context, ids);
    }

    if (st.bal(acc) < total) {
      showDialog<bool>(
          context: context,
          builder: (d) => AlertDialog(content: Text(trf('Nincs elég fedezet ({0}): elérhető {1}, a tétel összege {2}. Biztosan rögzíted?', [acc == 'cash' ? 'Készpénz' : 'Bankkártya', ft(st.bal(acc) < 0 ? 0 : st.bal(acc)), ft(total)])), actions: [
                TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Nem')),
                FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Igen')),
              ])).then((ok) {
        if (ok == true) go();
      });
    } else {
      go();
    }
  }

  @override
  Widget build(BuildContext context) {
    final onLines = lines.where((l) => l.on && amtOf(l) > 0).toList();
    final sum = onLines.fold(0.0, (a, l) => a + amtOf(l));
    final all = lines.where((l) => l.on).fold(0.0, (a, l) => a + amtOf(l));
    final total = widget.parsed.total;
    final diff = ((total - all) * 100).round() / 100;
    return Scaffold(
        appBar: AppBar(title: const Text('Nyugta ellenőrzése'), actions: [TextButton(onPressed: save, child: m.Text('${tr('Elkönyvelés')} (${single ? 1 : onLines.length})'))]),
        body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
          Text('A felismerés pontatlan lehet, ellenőrizd a tételeket, az összegeket és a kategóriákat.', style: TextStyle(fontSize: 13, color: Theme.of(context).hintColor)),
          const SizedBox(height: 12),
          TextField(controller: store, decoration: InputDecoration(labelText: tr('Üzlet'), border: const OutlineInputBorder())),
          const SizedBox(height: 10),
          OutlinedButton.icon(
              onPressed: () async {
                final p = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2000), lastDate: DateTime(2100));
                if (p != null) setState(() => date = p);
              },
              icon: const Icon(Icons.calendar_month),
              label: m.Text(dfm('yyyy. MMMM d.', date))),
          const SizedBox(height: 10),
          SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {acc}, onSelectionChanged: (v) => setState(() => acc = v.first)),
          if (single) ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
                value: st.cats.any((c) => c.id == cat) ? cat : null,
                decoration: InputDecoration(labelText: tr('Kategória'), border: const OutlineInputBorder()),
                items: [for (final c in st.cats) DropdownMenuItem(value: c.id, child: m.Text(c.name, overflow: TextOverflow.ellipsis))],
                onChanged: (v) => setState(() => cat = v ?? cat)),
          ],
          const SizedBox(height: 12),
          if (st.cats.isEmpty) const Text('Előbb hozz létre egy kategóriát a Kategóriák menüben (☰).'),
          for (var i = 0; i < lines.length; i++)
            Opacity(
                opacity: lines[i].on ? 1 : 0.45,
                child: Card(
                    child: Padding(
                        padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
                        child: Column(children: [
                          Row(children: [
                            Checkbox(value: lines[i].on, onChanged: (v) => setState(() => lines[i].on = v ?? true)),
                            Expanded(child: TextField(controller: lines[i].name, decoration: InputDecoration(isDense: true, hintText: tr('Tétel neve'), border: const OutlineInputBorder()))),
                            const SizedBox(width: 8),
                            SizedBox(width: 96, child: TextField(controller: lines[i].amt, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()))),
                          ]),
                          const SizedBox(height: 6),
                          Row(children: [
                            const SizedBox(width: 48),
                            Expanded(
                                child: single ? const SizedBox.shrink() : DropdownButton<String>(
                                    isExpanded: true,
                                    value: st.cats.any((c) => c.id == lines[i].cat) ? lines[i].cat : null,
                                    items: [for (final c in st.cats) DropdownMenuItem(value: c.id, child: m.Text(c.name, overflow: TextOverflow.ellipsis))],
                                    onChanged: (v) => setState(() {
                                          lines[i].cat = v ?? lines[i].cat;
                                          lines[i].item = '';
                                        }))),
                            IconButton(
                                icon: const Icon(Icons.close),
                                onPressed: () => setState(() {
                                      lines.removeAt(i);
                                      if (lines.isEmpty) lines.add(_RcLine('', '', st.cats.isEmpty ? '' : st.cats.first.id, '', true));
                                    })),
                          ]),
                        ])))),
          Align(alignment: Alignment.centerLeft, child: OutlinedButton.icon(onPressed: () => setState(() => lines.add(_RcLine('', '', st.cats.isEmpty ? '' : st.cats.first.id, '', true))), icon: const Icon(Icons.add), label: const Text('+ Új sor'))),
          SwitchListTile(contentPadding: EdgeInsets.zero, value: single, onChanged: (v) => setState(() => single = v), title: const Text('Egy összegként könyvelem')),
          Row(children: [
            Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Tételek összege', style: Theme.of(context).textTheme.bodySmall), m.Text(ft(sum), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))])))),
            Expanded(child: Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Végösszeg a nyugtán', style: Theme.of(context).textTheme.bodySmall), m.Text(ft(total), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))])))),
          ]),
          if (total > 0 && diff.abs() > 2) ...[
            Padding(padding: const EdgeInsets.only(top: 6), child: Text(trf('A tételek összege {0}, a nyugta végösszege {1}.', [ft(all), ft(total)]), style: const TextStyle(color: cOut))),
            if (diff > 0)
              Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton(
                      onPressed: () => setState(() {
                            final g = nqSuggest('egyéb', store.text);
                            lines.add(_RcLine('Egyéb', amtStr(diff), g.cat, '', true));
                          }),
                      child: const Text('Különbözet hozzáadása sorként'))),
          ],
        ]));
  }
}

