part of '../main.dart';

class AppState extends ChangeNotifier {
  List<Cat> cats = [];
  List<Tx> txs = [];
  List<Tpl> tpl = [];
  Map<String, String> rcl = {};
  List<String> recDismiss = [];
  String rptDismiss = '';
  List<Tx> trash = [];
  List<Rec> rec = [];
  Map<String, double> goalM = {};
  List<SG> sg = [];
  List<SGL> sgl = [];
  List<Loan> loans = [];
  List<Recv> recvs = [];
  List<Item> icats = [];
  double openCash = 0, openCard = 0;
  bool remOn = false;
  bool tutDone = false;
  String theme = 'system';
  String lang = 'hu';
  bool langSet = false;

  Future<void> setLang(String l) async {
    lang = l;
    langSet = true;
    final p = await SharedPreferences.getInstance();
    await p.setString('lang', l);
    notifyListeners();
  }

  int payRem = 1;
  String pin = '';
  bool bio = false;
  String lastBackup = '', firstUse = '', bkSnooze = '';
  String ws = 'huf'; // 'huf' | 'fx'
  bool initDone = false;
  bool fxOn = false, fxDecided = false, hide = false, voiceOn = false, scanOn = false;

  Future<void> setVoiceOn(bool v) async {
    voiceOn = v;
    notifyListeners();
    (await SharedPreferences.getInstance()).setBool('voiceOn', v);
  }

  Future<void> setScanOn(bool v) async {
    scanOn = v;
    notifyListeners();
    (await SharedPreferences.getInstance()).setBool('scanOn', v);
  }

  Future<void> setHide(bool v) async {
    hide = v;
    notifyListeners();
    (await SharedPreferences.getInstance()).setBool('hide', v);
    unawaited(pushWidget());
  }

  Future<void> setFxOn(bool v) async {
    final p = await SharedPreferences.getInstance();
    fxOn = v;
    fxDecided = true;
    await p.setBool('fxOn', v);
    if (!v && ws == 'fx') {
      await switchTo('huf');
    } else {
      notifyListeners();
    }
  }
  String cur = 'HUF'; // aktív deviza kódja ('HUF', 'EUR', ...; üres: még nincs deviza)
  List<String> fxCodes = [];
  String fxSel = '';
  Map<String, List<double>> fxSum = {}; // kód -> [készpénz, bankkártya, kintlévőség]
  Map<String, List<Tx>> fxTxs = {}; // kód -> tételek (a többi devizához)
  String get csym => (cur == 'HUF' || cur.isEmpty) ? 'Ft' : cur;

  List<double> sumFromJson(String s) {
    final j = jsonDecode(s);
    var cash = ((j['openCash'] ?? 0) as num).toDouble(), card = ((j['openCard'] ?? 0) as num).toDouble();
    final tx = ((j['txs'] ?? []) as List).map((e) => Tx.fromJson(e)).toList();
    for (final t in tx) {
      if (t.type == 'tr') {
        if (t.to == 'cash') cash += t.amt;
        if (t.to == 'card') card += t.amt;
        if (t.acc == 'cash') cash -= t.amt;
        if (t.acc == 'card') card -= t.amt;
      } else if (t.acc == 'cash') {
        cash += t.signed;
      } else if (t.acc == 'card') {
        card += t.signed;
      }
    }
    var rv = 0.0;
    for (final r in ((j['recvs'] ?? []) as List).map((e) => Recv.fromJson(e))) {
      if (r.closed) continue;
      final back = tx.where((t) => t.rc == r.id && t.type == 'back').fold(0.0, (a, t) => a + t.amt);
      if (r.total - back > 0) rv += r.total - back;
    }
    return [cash, card, rv];
  }

  Future<void> refreshFxSums() async {
    final p = await SharedPreferences.getInstance();
    final m = <String, List<double>>{};
    final tm = <String, List<Tx>>{};
    for (final c in fxCodes) {
      if (ws == 'fx' && c == cur) continue;
      final s = p.getString('fx_$c');
      if (s == null) continue;
      try {
        m[c] = sumFromJson(s);
        tm[c] = ((jsonDecode(s)['txs'] ?? []) as List).map((e) => Tx.fromJson(e)).toList();
      } catch (_) {}
    }
    fxSum = m;
    fxTxs = tm;
  }

  Future<void> switchTo(String newWs, [String code = '']) async {
    await flush();
    final p = await SharedPreferences.getInstance();
    await _save();
    final th = theme, td = tutDone, ro = remOn, rh = remH, rm = remM, pr = payRem;
    ws = newWs;
    if (newWs == 'huf') {
      cur = 'HUF';
    } else {
      cur = code.isNotEmpty ? code : (fxCodes.contains(fxSel) ? fxSel : (fxCodes.isNotEmpty ? fxCodes.first : ''));
      fxSel = cur;
    }
    final key = cur == 'HUF' ? 'kv1' : 'fx_$cur';
    final data = cur.isEmpty ? null : p.getString(key);
    fromBackup(data ?? '{"cats":[],"txs":[]}');
    theme = th;
    tutDone = td;
    remOn = ro;
    remH = rh;
    remM = rm;
    payRem = pr;
    await p.setString('ws', ws);
    await p.setString('fxSel', fxSel);
    await refreshFxSums();
    notifyListeners();
  }

  Future<void> addCurrency(String code) async {
    code = code.trim().toUpperCase();
    if (!RegExp(r'^[A-Z]{3}$').hasMatch(code) || code == 'HUF') return;
    final p = await SharedPreferences.getInstance();
    if (!fxCodes.contains(code)) {
      fxCodes = [...fxCodes, code];
      await p.setStringList('fxCodes', fxCodes);
      await p.setString('fx_$code', '{"cats":[],"txs":[],"initDone":false}');
    }
    await switchTo('fx', code);
  }

  String get activeKey => (cur == 'HUF' || cur.isEmpty) ? 'kv1' : 'fx_$cur';

  Future<void> addTxTo(String key, Tx t) async {
    if (key == activeKey) {
      change(() => txs.add(t));
      return;
    }
    final p = await SharedPreferences.getInstance();
    final j = jsonDecode(p.getString(key) ?? '{"cats":[],"txs":[]}');
    final l = (j['txs'] ?? []) as List;
    l.add(t.toJson());
    j['txs'] = l;
    await p.setString(key, jsonEncode(j));
  }

  Future<double> balOfKey(String key, String acc) async {
    if (key == activeKey) return bal(acc);
    final p = await SharedPreferences.getInstance();
    final s = p.getString(key);
    if (s == null) return 0;
    final v = sumFromJson(s);
    return acc == 'cash' ? v[0] : v[1];
  }

  Future<String> exchange({required String dir, required String code, required String src, required String dst, required double amt, required double rate, required double got, required DateTime date, required String note}) async {
    final id = uid();
    final dd = DateTime(date.year, date.month, date.day);
    final outT = Tx(id: uid(), type: 'out', acc: src, cat: 'xch', item: '', amt: amt, date: dd, note: note, xid: id, xc: dir == 'h2f' ? code : 'HUF', xr: rate, xo: got);
    final inT = Tx(id: uid(), type: 'in', acc: dst, cat: 'xch', item: '', amt: got, date: dd, note: note, xid: id, xc: dir == 'h2f' ? 'HUF' : code, xr: rate, xo: amt);
    await addTxTo(dir == 'h2f' ? 'kv1' : 'fx_$code', outT);
    await addTxTo(dir == 'h2f' ? 'fx_$code' : 'kv1', inT);
    await refreshFxSums();
    notifyListeners();
    return id;
  }

  Future<void> deleteXch(String xid) async {
    final p = await SharedPreferences.getInstance();
    for (final k in ['kv1', for (final c in fxCodes) 'fx_$c']) {
      if (k == activeKey) {
        change(() => txs.removeWhere((t) => t.xid == xid));
        continue;
      }
      final s = p.getString(k);
      if (s == null) continue;
      final j = jsonDecode(s);
      j['txs'] = ((j['txs'] ?? []) as List).where((e) => (e['xid'] ?? '') != xid).toList();
      await p.setString(k, jsonEncode(j));
    }
    await refreshFxSums();
    notifyListeners();
  }

  Future<void> deleteCurrency([String? code]) async {
    final c = code ?? cur;
    if (c.isEmpty || !fxCodes.contains(c)) return;
    final p = await SharedPreferences.getInstance();
    fxCodes = fxCodes.where((x) => x != c).toList();
    await p.setStringList('fxCodes', fxCodes);
    await p.remove('fx_$c');
    if (ws == 'fx' && c == cur) {
      cur = '';
      fxSel = '';
      await switchTo(fxCodes.isEmpty ? 'huf' : 'fx');
    } else {
      if (fxSel == c) fxSel = '';
      await refreshFxSums();
      notifyListeners();
    }
  }

  Future<String> fullBackup() async {
    final active = toBackup();
    final w = ws, c0 = cur;
    final p = await SharedPreferences.getInstance();
    final huf = w == 'huf' ? active : (p.getString('kv1') ?? '{"cats":[],"txs":[]}');
    final fx = <String, dynamic>{};
    for (final c in fxCodes) {
      final s = (w == 'fx' && c == c0) ? active : p.getString('fx_$c');
      if (s != null) fx[c] = jsonDecode(s);
    }
    final mp = <String, dynamic>{'v': 2, 'schema': kSchema, 'huf': jsonDecode(huf), 'fx': fx};
    mp['chk'] = backupChecksum(jsonEncode(mp));
    return jsonEncode(mp);
  }

  Future<void> restoreAny(String s) async {
    final j = jsonDecode(s);
    if (j is! Map) throw const FormatException('bad');
    await snapNow('restore');
    final p = await SharedPreferences.getInstance();
    final th = theme, td = tutDone, ro = remOn, rh = remH, rm = remM, pr = payRem;
    if (j.containsKey('huf')) {
      final hufS = jsonEncode(j['huf']);
      fromBackup(hufS);
      final fx = (j['fx'] ?? {}) as Map;
      for (final c in fxCodes) {
        await p.remove('fx_$c');
      }
      fxCodes = fx.keys.map((e) => e.toString()).toList();
      for (final c in fxCodes) {
        await p.setString('fx_$c', jsonEncode(fx[c]));
      }
      await p.setStringList('fxCodes', fxCodes);
      await p.setString('kv1', hufS);
    } else {
      fromBackup(s);
      await p.setString('kv1', s);
    }
    ws = 'huf';
    cur = 'HUF';
    fxSel = '';
    theme = th;
    tutDone = td;
    remOn = ro;
    remH = rh;
    remM = rm;
    payRem = pr;
    await p.setString('ws', 'huf');
    await p.setString('fxSel', '');
    await refreshFxSums();
    syncSg();
    notifyListeners();
  }
  double fs = 1.0;
  String _snapDay = '';

  Future<void> setFs(double v) async {
    fs = v;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setDouble('fs', v);
  }
  int pinFails = 0, pinUntil = 0;

  Future<void> markBackup() async {
    lastBackup = ymd(DateTime.now());
    final p = await SharedPreferences.getInstance();
    await p.setString('lastBackup', lastBackup);
    notifyListeners();
  }

  Future<void> snoozeBackup() async {
    bkSnooze = ymd(DateTime.now().add(const Duration(days: 7)));
    final p = await SharedPreferences.getInstance();
    await p.setString('bkSnooze', bkSnooze);
    notifyListeners();
  }

  void pinFail() {
    pinFails++;
    if (pinFails % 5 == 0) {
      final secs = 30 * (1 << ((pinFails ~/ 5) - 1));
      pinUntil = DateTime.now().millisecondsSinceEpoch + (secs > 900 ? 900 : secs) * 1000;
    }
    _savePinFails();
  }

  void pinOk() {
    pinFails = 0;
    pinUntil = 0;
    _savePinFails();
  }

  Future<void> _savePinFails() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('pinFails', pinFails);
    await p.setInt('pinUntil', pinUntil);
  }

  Future<void> setPin(String h) async {
    pin = h;
    if (h.isEmpty) bio = false;
    final p = await SharedPreferences.getInstance();
    await p.setString('pin', h);
    await p.setBool('bio', bio);
    notifyListeners();
  }

  Future<void> setBio(bool v) async {
    bio = v;
    final p = await SharedPreferences.getInstance();
    await p.setBool('bio', v);
    notifyListeners();
  }

  String recName(Rec r) => r.type == 'tr' ? 'Átvezetés' : (itemName(r.cat, r.item).isNotEmpty ? itemName(r.cat, r.item) : (r.type == 'in' ? (icName(r.cat).isEmpty ? 'Bevétel' : icName(r.cat)) : (catName(r.cat).isEmpty ? 'Kiadás' : catName(r.cat))));
  int remH = 20, remM = 0;
  double goal = 0;
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    ws = p.getString('ws') ?? 'huf';
    fxCodes = p.getStringList('fxCodes') ?? [];
    fxSel = p.getString('fxSel') ?? '';
    hide = p.getBool('hide') ?? false;
    voiceOn = p.getBool('voiceOn') ?? false;
    scanOn = p.getBool('scanOn') ?? false;
    final fp = p.getBool('fxOn');
    if (fp != null) {
      fxOn = fp;
      fxDecided = true;
    } else if (p.getString('kv1') != null || fxCodes.isNotEmpty) {
      fxOn = fxCodes.isNotEmpty;
      fxDecided = true;
      await p.setBool('fxOn', fxOn);
    }
    if (!fxOn) ws = 'huf';
    if (ws == 'fx' && fxCodes.isEmpty) ws = 'huf';
    if (ws == 'fx') {
      cur = fxCodes.contains(fxSel) ? fxSel : (fxCodes.isNotEmpty ? fxCodes.first : '');
    } else {
      cur = 'HUF';
    }
    final s = cur == 'HUF' ? p.getString('kv1') : (cur.isEmpty ? null : p.getString('fx_$cur'));
    pin = p.getString('pin') ?? '';
    final lg = p.getString('lang');
    lang = lg ?? 'hu';
    langSet = lg != null;
    bio = p.getBool('bio') ?? false;
    lastBackup = p.getString('lastBackup') ?? '';
    fs = p.getDouble('fs') ?? 1.0;
    bkSnooze = p.getString('bkSnooze') ?? '';
    pinFails = p.getInt('pinFails') ?? 0;
    pinUntil = p.getInt('pinUntil') ?? 0;
    firstUse = p.getString('firstUse') ?? '';
    if (firstUse.isEmpty) {
      firstUse = ymd(DateTime.now());
      await p.setString('firstUse', firstUse);
    }
    if (s != null) {
      fromBackup(s);
    } else {
      cats = [];
    }
    await refreshFxSums();
  }

  String toBackup() => jsonEncode({
        'schema': kSchema,
        'cats': cats.map((e) => e.toJson()).toList(),
        'txs': txs.map((e) => e.toJson()).toList(),
        'trash': trash.map((e) => e.toJson()).toList(),
        'rec': rec.map((e) => e.toJson()).toList(),
        'openCash': openCash,
        'openCard': openCard,
        'remOn': remOn,
        'remH': remH,
        'remM': remM,
        'tutDone': tutDone,
        'initDone': initDone,
        'theme': theme,
        'payRem': payRem,
        'goal': goal,
        'goalM': goalM,
        'sg': sg.map((e) => e.toJson()).toList(),
        'icats': icats.map((e) => e.toJson()).toList(),
        'sgl': sgl.map((e) => e.toJson()).toList(),
        'loans': loans.map((e) => e.toJson()).toList(),
        'recvs': recvs.map((e) => e.toJson()).toList(),
        'tpl': tpl.map((e) => e.toJson()).toList(),
        'rcl': rcl,
        'recDismiss': recDismiss,
        'rptDismiss': rptDismiss,
      });

  void fromBackup(String s) {
    ver++;
    final j = jsonDecode(s);
    cats = (j['cats'] as List).map((e) => Cat.fromJson(e)).toList();
    txs = (j['txs'] as List).map((e) => Tx.fromJson(e)).toList();
    trash = ((j['trash'] ?? []) as List).map((e) => Tx.fromJson(e)).toList();
    rec = ((j['rec'] ?? []) as List).map((e) => Rec.fromJson(e)).toList();
    openCash = (j['openCash'] ?? 0).toDouble();
    openCard = (j['openCard'] ?? 0).toDouble();
    remOn = j['remOn'] ?? false;
    remH = j['remH'] ?? 20;
    remM = j['remM'] ?? 0;
    tutDone = j['tutDone'] ?? false;
    initDone = j['initDone'] ?? true;
    theme = j['theme'] ?? 'system';
    payRem = j['payRem'] ?? 1;
    goal = (j['goal'] ?? 0).toDouble();
    goalM = ((j['goalM'] ?? {}) as Map).map((k, v) => MapEntry(k as String, (v as num).toDouble()));
    sg = ((j['sg'] ?? []) as List).map((e) => SG.fromJson(e)).toList();
    if (j['icats'] != null) icats = (j['icats'] as List).map((e) => Item.fromJson(e)).toList();
    sgl = ((j['sgl'] ?? []) as List).map((e) => SGL.fromJson(e)).toList();
    loans = ((j['loans'] ?? []) as List).map((e) => Loan.fromJson(e)).toList();
    recvs = ((j['recvs'] ?? []) as List).map((e) => Recv.fromJson(e)).toList();
    tpl = ((j['tpl'] ?? []) as List).map((e) => Tpl.fromJson(e)).toList();
    rcl = ((j['rcl'] ?? {}) as Map).map((k, v) => MapEntry(k.toString(), v.toString()));
    recDismiss = ((j['recDismiss'] ?? []) as List).map((e) => e.toString()).toList();
    rptDismiss = (j['rptDismiss'] ?? '').toString();
    migrateSgl();
    syncSg();
  }

  Color catColorById(String id) {
    if (id == 'xch') return const Color(0xFF0288D1);
    if (id == 'sav') return const Color(0xFF2E7D32);
    if (id == 'loan') return const Color(0xFF8E4585);
    for (var i = 0; i < cats.length; i++) {
      if (cats[i].id == id) return cats[i].color != 0 ? Color(cats[i].color) : palCols[i % palCols.length];
    }
    return Colors.grey;
  }

  Color incColorById(String id) {
    if (id == 'xch') return const Color(0xFF0288D1);
    for (var i = 0; i < icats.length; i++) {
      if (icats[i].id == id) return icats[i].color != 0 ? Color(icats[i].color) : palCols[(i + 3) % palCols.length];
    }
    return Colors.grey;
  }

  Color? colorFor(Tx t) {
    if (t.type != 'out' && t.type != 'in') return null;
    if (t.xid.isNotEmpty || t.cat == 'xch') return const Color(0xFF0288D1);
    if (t.type == 'out') {
      if (t.cat == 'sav' || t.cat == 'loan' || cats.any((c) => c.id == t.cat)) return catColorById(t.cat);
      return null;
    }
    return icats.any((c) => c.id == t.cat) ? incColorById(t.cat) : null;
  }

  String icName(String id) {
    if (id == 'xch') return 'Pénzváltás';
    for (final c in icats) {
      if (c.id == id) return c.name;
    }
    return '';
  }

  void restore(String s) {
    snapNow('restore');
    fromBackup(s);
    notifyListeners();
    _save();
  }

  Future<void> _save() async {
    if (ws == 'fx' && cur.isEmpty) return;
    final p = await SharedPreferences.getInstance();
    await p.setString(cur == 'HUF' || cur.isEmpty ? 'kv1' : 'fx_$cur', toBackup());
  }

  String toCsv() {
    final sb = StringBuffer('${tr('Dátum')};${tr('Típus')};${tr('Összeg')};${tr('Számla')};${tr('Kategória')};${tr('Tétel')};${tr('Megjegyzés')}\n');
    final l = [...txs]..sort((a, b) => a.date.compareTo(b.date));
    for (final t in l) {
      sb.writeln([
        DateFormat('yyyy-MM-dd').format(t.date),
        tr(t.type == 'in' ? 'Bevétel' : (t.type == 'out' ? 'Kiadás' : (t.type == 'lend' ? 'Kölcsönadás' : (t.type == 'back' ? 'Visszakapott' : (t.type == 'xout' ? 'Átváltás (ki)' : (t.type == 'xin' ? 'Átváltás (be)' : 'Átvezetés')))))),
        t.amt.round(),
        t.type == 'tr' ? '${accName(t.acc)} → ${accName(t.to)}' : accName(t.acc),
        t.type == 'in' ? icName(t.cat) : catName(t.cat),
        itemName(t.cat, t.item),
        '"${t.note.replaceAll('"', '""')}"',
      ].join(';'));
    }
    return sb.toString();
  }

  void wipe() {
    snapNow('wipe');
    change(() {
      initDone = false;
      cats = [];
      txs = [];
      trash = [];
      rec = [];
      sg = [];
      sgl = [];
      loans = [];
      recvs = [];
      tpl = [];
      rcl = {};
      recDismiss = [];
      rptDismiss = '';
      icats = [];
      goalM = {};
      goal = 0;
      openCash = 0;
      openCard = 0;
      tutDone = true;
    });
  }

  String ym(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}';

  List<Tx> loanPays(Loan l) {
    final x = txs.where((t) => t.ln == l.id).toList();
    x.sort((a, b) => a.date.compareTo(b.date));
    return x;
  }

  double loanRem(Loan l) {
    final r = l.total - loanPays(l).fold(0.0, (s, t) => s + t.amt);
    return r < 0 ? 0 : r;
  }

  String ymAdd(String s, int k) {
    final p = s.split('-');
    return ym(DateTime(int.parse(p[0]), int.parse(p[1]) + k, 1));
  }

  String loanSince(Loan l) {
    if (l.since.isNotEmpty) return l.since;
    final ms = txs.where((t) => t.ln == l.id && t.lm.isNotEmpty).map((t) => t.lm).toList()..sort();
    return ms.isNotEmpty ? ms.first : ym(DateTime.now());
  }

  List<String> loanMissed(Loan l, DateTime now) {
    final cur = ym(now);
    final out = <String>[];
    var m = loanSince(l);
    var g = 0;
    while (m.compareTo(cur) < 0 && m.compareTo(l.end) <= 0 && g++ < 48) {
      if (!txs.any((t) => t.ln == l.id && t.lm == m)) out.add(m);
      m = ymAdd(m, 1);
    }
    return out;
  }

  LoanSt loanState(Loan l, DateTime now) {
    final rem = loanRem(l), missed = loanMissed(l, now), done = loanPaidMonth(l, now);
    final d = daysBetween(DateTime(now.year, now.month, now.day), loanDue(l, now));
    return LoanSt(rem, missed, done, d, !done && d < 0 && rem > 0);
  }

  bool loanPaidMonth(Loan l, DateTime d) => txs.any((t) => t.ln == l.id && t.lm == ym(d));

  DateTime loanDue(Loan l, DateTime d) {
    final dim = DateUtils.getDaysInMonth(d.year, d.month);
    return DateTime(d.year, d.month, l.day < dim ? l.day : dim);
  }

  String ymd(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  double recvBack(Recv r) => txs.where((t) => t.rc == r.id && t.type == 'back').fold(0.0, (s, t) => s + t.amt);

  double recvRem(Recv r) {
    if (r.closed) return 0;
    final v = r.total - recvBack(r);
    return v < 0 ? 0 : v;
  }

  double recvSum() => recvs.fold(0.0, (s, r) => s + recvRem(r));

  int? recvDays(Recv r, DateTime now) {
    if (r.due.isEmpty) return null;
    return daysBetween(now, DateTime.parse(r.due));
  }

  List<Recv> overdueRecvs(DateTime now) => recvs.where((r) => recvRem(r) > 0 && (recvDays(r, now) ?? 0) < 0).toList();

  List<Loan> overdueLoans(DateTime now) {
    final today = DateTime(now.year, now.month, now.day);
    return loans.where((l) {
      final s = loanState(l, now);
      return s.rem > 0 && (s.missed.isNotEmpty || s.curOver);
    }).toList();
  }

  int loanMonthsLeft(Loan l, DateTime d) {
    final p = l.end.split('-');
    final v = (int.parse(p[0]) * 12 + int.parse(p[1])) - (d.year * 12 + d.month) + 1;
    return v < 0 ? 0 : v;
  }

  void syncSg() {
    for (final g in sg) {
      final d = txs.where((t) => t.sg == g.id).fold(0.0, (s, t) => s + (t.type == 'out' ? t.amt : -t.amt));
      final v = (g.base ?? 0) + d;
      g.saved = v < 0 ? 0 : v;
    }
  }

  void migrateSgl() {
    for (final g in sg) {
      g.base ??= ((g.saved - sgl.where((x) => x.goal == g.id).fold(0.0, (s, x) => s + x.amt)) < 0 ? 0 : g.saved - sgl.where((x) => x.goal == g.id).fold(0.0, (s, x) => s + x.amt));
    }
    for (final x in sgl) {
      txs.add(Tx(id: uid(), type: x.amt > 0 ? 'out' : 'in', acc: x.acc, cat: x.amt > 0 ? 'sav' : '', item: '', amt: x.amt.abs(), date: x.date, note: '', sg: x.goal));
    }
    sgl = [];
  }

  int ver = 0;
  Timer? _saveT;
  bool _dirty = false;

  @override
  void notifyListeners() {
    ver++;
    super.notifyListeners();
  }

  void _saveSoon() {
    _dirty = true;
    _saveT?.cancel();
    _saveT = Timer(const Duration(milliseconds: 500), flush);
  }

  Future<void> flush() async {
    _saveT?.cancel();
    if (!_dirty) return;
    _dirty = false;
    await _save();
    unawaited(pushWidget());
  }

  Future<void> pushWidget() async {
    try {
      if (ws != 'huf') return;
      await HomeWidget.saveWidgetData<String>('kv_total', hide ? '••••' : ftc(bal('cash') + bal('card'), 'HUF'));
      await HomeWidget.updateWidget(androidName: 'KvWidgetProvider');
    } catch (_) {}
  }

  void change(VoidCallback f) {
    f();
    syncSg();
    notifyListeners();
    _saveSoon();
    final d = ymd(DateTime.now());
    if (_snapDay != d) {
      _snapDay = d;
      snapNow();
    }
  }

  double goalFor(DateTime m) {
    final k = '${m.year}-${m.month.toString().padLeft(2, '0')}';
    String? best;
    for (final e in goalM.keys) {
      if (e.compareTo(k) <= 0 && (best == null || e.compareTo(best) > 0)) best = e;
    }
    return best == null ? goal : goalM[best]!;
  }

  final Map<String?, double> _bc = {};
  int _bcVer = -1, _bcLen = -1;
  double bal(String? acc) {
    if (_bcVer != ver || _bcLen != txs.length) {
      _bc.clear();
      _bcVer = ver;
      _bcLen = txs.length;
    }
    return _bc[acc] ??= _balCalc(acc);
  }

  double _balCalc(String? acc) {
    var s = acc == null ? openCash + openCard : (acc == 'cash' ? openCash : openCard);
    for (final t in txs) {
      if (t.type == 'tr') {
        if (acc != null) {
          if (t.to == acc) s += t.amt;
          if (t.acc == acc) s -= t.amt;
        }
      } else if (acc == null || t.acc == acc) {
        s += t.signed;
      }
    }
    return s;
  }

  void applyRec() {
    final n = DateTime.now();
    var ch = false;
    for (final r in rec) {
      final p = r.last.split('-');
      var y = int.parse(p[0]), m = int.parse(p[1]);
      while (true) {
        m++;
        if (m > 12) {
          m = 1;
          y++;
        }
        if (y > n.year || (y == n.year && m > n.month)) break;
        final dim = DateUtils.getDaysInMonth(y, m);
        final d = r.day < dim ? r.day : dim;
        if (y == n.year && m == n.month && d > n.day) break;
        txs.add(Tx(id: uid(), type: r.type, acc: r.acc, to: r.to, cat: r.cat, item: r.item, amt: r.amt, date: DateTime(y, m, d), note: r.note));
        r.last = '$y-${m.toString().padLeft(2, '0')}';
        ch = true;
      }
    }
    if (ch) {
      notifyListeners();
      _save();
    }
  }
  bool inMonth(DateTime d) => d.year == month.year && d.month == month.month;
  List<Tx>? _mc;
  int _mcVer = -1, _mcLen = -1;
  DateTime? _mcM;
  List<Tx> get mtx {
    if (_mc != null && _mcVer == ver && _mcLen == txs.length && _mcM == month) return _mc!;
    _mcVer = ver;
    _mcLen = txs.length;
    _mcM = month;
    return _mc = (txs.where((t) => inMonth(t.date)).toList()..sort((a, b) => b.date.compareTo(a.date)));
  }
  double sum(Iterable<Tx> l, String type) => l.where((t) => t.type == type).fold(0.0, (s, t) => s + t.amt);
  String catName(String id) {
    if (id == 'sav') return 'Megtakarítás';
    if (id == 'loan') return 'Hitel';
    if (id == 'xch') return 'Pénzváltás';
    for (final c in cats) {
      if (c.id == id) return c.name;
    }
    return '';
  }

  String itemName(String cid, String iid) {
    for (final c in cats) {
      if (c.id == cid) {
        for (final i in c.items) {
          if (i.id == iid) return i.name;
        }
      }
    }
    return '';
  }

  String title(Tx t) {
    if (t.xid.isNotEmpty) return trf('Átváltás: {0} → {1}', t.type == 'out' ? [cur, t.xc] : [t.xc, cur]);
    if (t.rc.isNotEmpty) {
      final rs = recvs.where((x) => x.id == t.rc);
      return trf(t.type == 'lend' ? 'Kölcsön: {0}' : 'Visszakapott: {0}', [rs.isEmpty ? '' : rs.first.name]);
    }
    if (t.ln.isNotEmpty) {
      final ls = loans.where((x) => x.id == t.ln);
      return trf('Hitel: {0}', [ls.isEmpty ? '' : ls.first.name]);
    }
    if (t.sg.isNotEmpty) {
      final gs = sg.where((x) => x.id == t.sg);
      return '${tr(t.type == 'in' ? 'Kivétel' : 'Megtakarítás')}: ${gs.isEmpty ? tr('cél') : gs.first.name}';
    }
    if (t.type == 'tr') return 'Átvezetés';
    if (t.type == 'in') return icName(t.cat).isNotEmpty ? icName(t.cat) : 'Bevétel';
    final i = itemName(t.cat, t.item);
    if (i.isNotEmpty) return i;
    final c = catName(t.cat);
    return c.isNotEmpty ? c : 'Kiadás';
  }
}

