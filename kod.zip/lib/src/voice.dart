part of '../main.dart';

class VoiceRes {
  final String type, cat, item, note;
  final double amt;
  const VoiceRes(this.type, this.amt, this.cat, this.item, this.note);
}

const _numw = <List<Object>>[
  ['nulla', 0], ['egy', 1], ['két', 2], ['kettő', 2], ['három', 3], ['négy', 4], ['öt', 5], ['hat', 6], ['hét', 7], ['nyolc', 8], ['kilenc', 9], ['tíz', 10], ['tizen', 10], ['húsz', 20], ['huszon', 20],
  ['harminc', 30], ['negyven', 40], ['ötven', 50], ['hatvan', 60], ['hetven', 70], ['nyolcvan', 80], ['kilencven', 90], ['száz', 100], ['ezer', 1000], ['millió', 1000000],
];

List<int>? numSeg(String tok) {
  final ws = [..._numw]..sort((a, b) => (b[0] as String).length.compareTo((a[0] as String).length));
  var i = 0;
  final out = <int>[];
  while (i < tok.length) {
    List<Object>? hit;
    for (final w in ws) {
      if (tok.startsWith(w[0] as String, i)) {
        hit = w;
        break;
      }
    }
    if (hit == null) return null;
    out.add(hit[1] as int);
    i += (hit[0] as String).length;
  }
  return out.isEmpty ? null : out;
}

VoiceRes parseVoice(String txt, List<Cat> cats, List<Item> icats) {
  final low = txt.trim().toLowerCase().replaceAll(RegExp(r'[.!?]+$'), '');
  var amt = 0.0;
  var rest = low;
  final dm = RegExp(r'(\d[\d ]*(?:[.,]\d+)?)(?:\s*(ezer|ezres|millió))?').firstMatch(low);
  if (dm != null) {
    var n = dm.group(1)!.replaceAll(RegExp(r'\s+'), '');
    if (RegExp(r'^\d{1,3}(\.\d{3})+$').hasMatch(n)) {
      n = n.replaceAll('.', '');
    } else {
      n = n.replaceFirst(',', '.');
    }
    amt = double.tryParse(n) ?? 0;
    final mu = dm.group(2);
    if (mu != null) amt *= mu == 'millió' ? 1000000 : 1000;
    rest = low.replaceFirst(dm.group(0)!, ' ');
  }
  final toks = rest.split(RegExp(r'[^a-záéíóöőúüű]+')).where((x) => x.isNotEmpty).toList();
  final words = <String>[];
  var tot = 0, cu = 0;
  const mul = ['ezer', 'száz', 'millió', 'százezer'];
  for (var i = 0; i < toks.length; i++) {
    final tk = toks[i];
    if (amt == 0) {
      final nx = i + 1 < toks.length ? toks[i + 1] : '';
      if (tk == 'egy' && !mul.any((x) => nx.startsWith(x))) {
        words.add(tk);
        continue;
      }
      final sg = numSeg(tk);
      if (sg != null) {
        for (final v in sg) {
          if (v == 1000 || v == 1000000) {
            tot += (cu == 0 ? 1 : cu) * v;
            cu = 0;
          } else if (v == 100) {
            cu = (cu == 0 ? 1 : cu) * 100;
          } else {
            cu += v;
          }
        }
        continue;
      }
    }
    words.add(tk);
  }
  if (amt == 0) amt = (tot + cu).toDouble();
  const curw = ['forint', 'forintot', 'forintért', 'ft', 'huf', 'euró', 'euro', 'dollár', 'font', 'fontot'];
  const inw = ['fizetés', 'fizetést', 'bevétel', 'bevételt', 'kaptam', 'jött', 'prémium', 'prémiumot'];
  final type = words.any((w) => inw.contains(w)) ? 'in' : 'out';
  final ws = words.where((w) => !curw.contains(w)).toList();
  bool mt(String tk, String name) {
    final n = name.toLowerCase();
    return tk == n || (n.length >= 4 && tk.startsWith(n.substring(0, n.length - 2 > 4 ? n.length - 2 : 4)));
  }

  var cat = '', item = '';
  if (type == 'out') {
    var best = 0;
    for (final c in cats) {
      for (final it in c.items) {
        if (ws.any((w) => mt(w, it.name)) && it.name.length > best) {
          best = it.name.length;
          cat = c.id;
          item = it.id;
        }
      }
    }
    if (cat.isEmpty) {
      for (final c in cats) {
        if (cat.isEmpty && ws.any((w) => mt(w, c.name))) cat = c.id;
      }
    }
  } else {
    for (final c in icats) {
      if (cat.isEmpty && ws.any((w) => mt(w, c.name))) cat = c.id;
    }
  }
  return VoiceRes(type, (amt * 100).round() / 100, cat, item, (cat.isNotEmpty || item.isNotEmpty) ? '' : ws.join(' '));
}

