part of '../main.dart';

class Text extends StatelessWidget {
  final String data;
  final InlineSpan? span;
  final TextStyle? style;
  final TextAlign? textAlign;
  final TextOverflow? overflow;
  final int? maxLines;
  const Text(this.data, {super.key, this.style, this.textAlign, this.overflow, this.maxLines}) : span = null;
  const Text.rich(this.span, {super.key, this.style, this.textAlign, this.overflow, this.maxLines}) : data = '';
  @override
  Widget build(BuildContext context) {
    final l = Localizations.localeOf(context).languageCode;
    if (span != null) return m.Text.rich(span!, style: style, textAlign: textAlign, overflow: overflow, maxLines: maxLines);
    return m.Text(tr(data, l), style: style, textAlign: textAlign, overflow: overflow, maxLines: maxLines);
  }
}

String ftc(num n, String code) {
  if (code == 'HUF' || code.isEmpty) return '${NumberFormat.decimalPattern(st.lang).format(n.round())} Ft';
  final d = code == 'JPY' ? 0 : 2;
  final v = (n * 100).round() / 100;
  return '${NumberFormat.currency(locale: st.lang, symbol: '', decimalDigits: d).format(v == 0 ? 0 : v).trim()} $code';
}

String ft(num n) => ftc(n, st.cur);
double r2c(double n, String c) => (c == 'JPY' || c == 'HUF') ? n.roundToDouble() : (n * 100).round() / 100;
String amtStr(num v) {
  final r = (v * 100).round() / 100;
  return r == r.roundToDouble() ? r.round().toString() : r.toStringAsFixed(2);
}
const popCur = [
  ['EUR', 'Euró'], ['USD', 'Amerikai dollár'], ['GBP', 'Angol font'], ['CHF', 'Svájci frank'], ['PLN', 'Lengyel zloty'],
  ['CZK', 'Cseh korona'], ['RON', 'Román lej'], ['JPY', 'Japán jen'], ['CAD', 'Kanadai dollár'], ['AUD', 'Ausztrál dollár'],
  ['SEK', 'Svéd korona'], ['NOK', 'Norvég korona'], ['DKK', 'Dán korona'], ['RSD', 'Szerb dinár'], ['UAH', 'Ukrán hrivnya'],
  ['TRY', 'Török líra'], ['CNY', 'Kínai jüan'], ['AED', 'Emírségekbeli dirham'], ['BGN', 'Bolgár leva'],
];
String uid() => DateTime.now().microsecondsSinceEpoch.toRadixString(36);
int daysBetween(DateTime a, DateTime b) => DateTime.utc(b.year, b.month, b.day).difference(DateTime.utc(a.year, a.month, a.day)).inDays;
String accName(String a) => tr(a == 'cash' ? 'Készpénz' : 'Bankkártya');
String hashPin(String s) {
  var h = 5381;
  for (final c in 'kv|$s'.codeUnits) {
    h = ((h << 5) + h + c) & 0x7fffffff;
  }
  return '$h';
}
bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

class Item {
  String id, name;
  int color;
  Item(this.id, this.name, [this.color = 0]);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'color': color};
  factory Item.fromJson(Map j) => Item(j['id'], j['name'], (j['color'] as num?)?.toInt() ?? 0);
}

class Cat {
  String id, name;
  List<Item> items;
  int color;
  Cat(this.id, this.name, this.items, [this.color = 0]);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'items': items.map((e) => e.toJson()).toList(), 'color': color};
  factory Cat.fromJson(Map j) => Cat(j['id'], j['name'], (j['items'] as List).map((e) => Item.fromJson(e)).toList(), (j['color'] as num?)?.toInt() ?? 0);
}

const lnTypes = ['Áruhitel', 'Személyi kölcsön', 'Lakáshitel', 'Autótörlesztő', 'Babaváró hitel', 'Diákhitel', 'Folyószámlahitel', 'Hitelkártya', 'Szabad felhasználású jelzáloghitel', 'Lakásfelújítási hitel', 'Lízing', 'Munkáltatói kölcsön', 'Magánkölcsön', 'Egyéb'];

class Recv {
  String id, name, date, due; // date, due: 'yyyy-MM-dd'
  double total, inst;
  bool closed;
  Recv(this.id, this.name, this.total, this.date, this.due, [this.closed = false, this.inst = 0]);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'total': total, 'date': date, 'due': due, 'closed': closed, 'inst': inst};
  factory Recv.fromJson(Map j) => Recv(j['id'], j['name'], (j['total'] as num).toDouble(), j['date'], j['due'] ?? '', j['closed'] ?? false, (j['inst'] as num?)?.toDouble() ?? 0);
}

class Loan {
  String id, name, end, since; // end, since: 'yyyy-MM'
  double total, pay;
  int day;
  Loan(this.id, this.name, this.total, this.pay, this.day, this.end, [this.since = '']);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'total': total, 'pay': pay, 'day': day, 'end': end, 'since': since};
  factory Loan.fromJson(Map j) => Loan(j['id'], j['name'], (j['total'] as num).toDouble(), (j['pay'] as num).toDouble(), j['day'], j['end'], j['since'] ?? '');
}

class LoanSt {
  final double rem;
  final List<String> missed;
  final bool done, curOver;
  final int d;
  LoanSt(this.rem, this.missed, this.done, this.d, this.curOver);
}

class UpItem {
  final DateTime d;
  final String n;
  final double a;
  UpItem(this.d, this.n, this.a);
}

class Tx {
  String id, type, acc, cat, item, note, to, sg, ln, lm, rc, xid, xc;
  double amt, xr, xo;
  List<String> tags;
  bool ph;
  List<Map<String, dynamic>> rl;
  String rs;
  DateTime date;
  Tx({this.to = '', this.sg = '', this.ln = '', this.lm = '', this.rc = '', this.xid = '', this.xc = '', this.xr = 0, this.xo = 0, this.tags = const [], this.ph = false, this.rl = const [], this.rs = '', required this.id, required this.type, required this.acc, required this.cat, required this.item, required this.amt, required this.date, required this.note});
  bool get linked => sg.isNotEmpty || ln.isNotEmpty || rc.isNotEmpty || xid.isNotEmpty;
  double get signed => (type == 'in' || type == 'back' || type == 'xin') ? amt : ((type == 'out' || type == 'lend' || type == 'xout') ? -amt : 0);
  Map<String, dynamic> toJson() => {'id': id, 'type': type, 'acc': acc, 'cat': cat, 'item': item, 'amt': amt, 'date': date.toIso8601String(), 'note': note, 'to': to, 'sg': sg, 'ln': ln, 'lm': lm, 'rc': rc, 'xid': xid, 'xc': xc, 'xr': xr, 'xo': xo, if (tags.isNotEmpty) 'tags': tags, if (ph) 'ph': true, if (rl.isNotEmpty) 'rl': rl, if (rs.isNotEmpty) 'rs': rs};
  factory Tx.fromJson(Map j) => Tx(id: j['id'], type: j['type'] == 'xout' ? 'out' : (j['type'] == 'xin' ? 'in' : j['type']), acc: j['acc'], cat: (j['type'] == 'xout' || j['type'] == 'xin') ? 'xch' : j['cat'], item: j['item'], amt: (j['amt'] as num).toDouble(), date: DateTime.parse(j['date']), note: j['note'] ?? '', to: j['to'] ?? '', sg: j['sg'] ?? '', ln: j['ln'] ?? '', lm: j['lm'] ?? '', rc: j['rc'] ?? '', xid: j['xid'] ?? '', xc: j['xc'] ?? '', xr: ((j['xr'] ?? 0) as num).toDouble(), xo: ((j['xo'] ?? 0) as num).toDouble(), tags: ((j['tags'] ?? []) as List).map((e) => e.toString()).toList(), ph: j['ph'] == true, rl: ((j['rl'] ?? []) as List).map((e) => Map<String, dynamic>.from(e as Map)).toList(), rs: (j['rs'] ?? '').toString());
}

class Tpl {
  String id, name, type, acc, cat, item, note;
  double amt;
  List<String> tags;
  Tpl(this.id, this.name, this.type, this.acc, this.cat, this.item, this.amt, this.note, this.tags);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'type': type, 'acc': acc, 'cat': cat, 'item': item, 'amt': amt, 'note': note, 'tags': tags};
  factory Tpl.fromJson(Map j) => Tpl(j['id'], j['name'], j['type'], j['acc'], j['cat'], j['item'], (j['amt'] as num).toDouble(), j['note'] ?? '', ((j['tags'] ?? []) as List).map((e) => e.toString()).toList());
}

class Rec {
  String id, type, acc, to, cat, item, note, last;
  double amt;
  int day;
  Rec(this.id, this.type, this.acc, this.to, this.cat, this.item, this.note, this.last, this.amt, this.day);
  Map<String, dynamic> toJson() => {'id': id, 'type': type, 'acc': acc, 'to': to, 'cat': cat, 'item': item, 'note': note, 'last': last, 'amt': amt, 'day': day};
  factory Rec.fromJson(Map j) => Rec(j['id'], j['type'], j['acc'], j['to'] ?? '', j['cat'], j['item'], j['note'] ?? '', j['last'], (j['amt'] as num).toDouble(), j['day']);
}

class SG {
  String id, name;
  double target, saved;
  double? base;
  String due;
  SG(this.id, this.name, this.target, this.saved, [this.base, this.due = '']);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'target': target, 'saved': saved, 'base': base, 'due': due};
  factory SG.fromJson(Map j) => SG(j['id'], j['name'], (j['target'] as num).toDouble(), (j['saved'] as num).toDouble(), (j['base'] as num?)?.toDouble(), j['due'] ?? '');
}

class SGL {
  String id, goal, acc;
  double amt;
  DateTime date;
  SGL(this.id, this.goal, this.acc, this.amt, this.date);
  Map<String, dynamic> toJson() => {'id': id, 'goal': goal, 'acc': acc, 'amt': amt, 'date': date.toIso8601String()};
  factory SGL.fromJson(Map j) => SGL(j['id'], j['goal'], j['acc'], (j['amt'] as num).toDouble(), DateTime.parse(j['date']));
}

