import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' show Random;
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:flutter/services.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:image_picker/image_picker.dart';
import 'package:home_widget/home_widget.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart' as mlk;
import 'package:local_auth/local_auth.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart' show launchUrl, LaunchMode;
import 'package:quick_actions/quick_actions.dart';
import 'package:cryptography/cryptography.dart' as cr;
import 'package:printing/printing.dart' show Printing;
import 'package:archive/archive.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

part 'src/i18n.dart';
part 'src/core.dart';
part 'src/state.dart';
part 'src/services.dart';
part 'src/reports.dart';
part 'src/voice.dart';
part 'src/receipt.dart';

const cOut = Color(0xFFF2703A), cIn = Color(0xFF12B981), cCash = Color(0xFF34D399), cCard = Color(0xFF3B82F6);
String hv(String s) => st.hide ? '••••' : s;
String fmtK(double n) {
  final a = n.abs();
  if (a >= 1e6) return '${(n / 1e6).toStringAsFixed(1).replaceAll('.0', '')}M';
  if (a >= 1000) return '${(n / 1000).round()}k';
  if (a < 10) return ((n * 10).round() / 10).toString();
  return n.round().toString();
}

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final cs = ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB), brightness: b).copyWith(
      primary: dark ? const Color(0xFF3B82F6) : const Color(0xFF2563EB),
      surface: dark ? const Color(0xFF0D1A3D) : Colors.white,
      surfaceContainerLow: dark ? const Color(0xFF0F1F4A) : Colors.white,
      surfaceContainerHigh: dark ? const Color(0xFF13275A) : Colors.white);
  return ThemeData(
      useMaterial3: true,
      colorScheme: cs,
      scaffoldBackgroundColor: dark ? const Color(0xFF060D22) : const Color(0xFFEEF3FF),
      cardTheme: CardThemeData(color: dark ? const Color(0xFF0F1F4A) : Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: dark ? const Color(0xFF1D3466) : const Color(0xFFD9E3F7)))),
      navigationBarTheme: NavigationBarThemeData(backgroundColor: dark ? const Color(0xFF0B1636) : Colors.white, indicatorColor: const Color(0x333B82F6)),
      drawerTheme: DrawerThemeData(backgroundColor: dark ? const Color(0xFF0D1A3D) : Colors.white),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: Color(0xFF2563EB), foregroundColor: Colors.white));
}
const palCols = [Color(0xFF1D6F6A), Color(0xFFC2410C), Color(0xFF3949AB), Color(0xFFB7791F), Color(0xFF8E4585), Color(0xFF2E7D32), Color(0xFF546E7A), Color(0xFFD32F2F), Color(0xFF0288D1), Color(0xFFF9A825), Color(0xFF6D4C41), Color(0xFF00897B), Color(0xFF7B1FA2), Color(0xFFE64A19), Color(0xFF5D4037), Color(0xFF455A64)];
const palette = [Color(0xFF1D6F6A), Color(0xFFC2410C), Color(0xFF3949AB), Color(0xFFB7791F), Color(0xFF8E4585), Color(0xFF2E7D32), Color(0xFF546E7A)];

const kVer = '2.2.0';
const kSchema = 3;

String backupChecksum(String s) {
  var h = 0x811c9dc5;
  for (final c in s.codeUnits) {
    h ^= c;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h.toRadixString(16);
}

/// null: rendben, különben 'invalid' | 'newer' | 'chk'
String? backupProblem(String s) {
  try {
    final j = jsonDecode(s);
    if (j is! Map) return 'invalid';
    final sc = j['schema'];
    if (sc is num && sc > kSchema) return 'newer';
    final huf = j.containsKey('huf') ? j['huf'] : j;
    if (huf is! Map || huf['cats'] is! List || huf['txs'] is! List) return 'invalid';
    for (final t in huf['txs'] as List) {
      if (t is! Map || t['id'] == null || t['amt'] is! num) return 'invalid';
    }
    if (j['chk'] != null) {
      final m = Map<String, dynamic>.from(j)..remove('chk');
      if (backupChecksum(jsonEncode(m)) != j['chk']) return 'chk';
    }
    return null;
  } catch (_) {
    return 'invalid';
  }
}

Future<void> logErr(String m) async {
  try {
    final p = await SharedPreferences.getInstance();
    final l = p.getStringList('errlog') ?? <String>[];
    l.add('${DateTime.now().toIso8601String()} ${m.length > 300 ? m.substring(0, 300) : m}');
    await p.setStringList('errlog', l.length > 20 ? l.sublist(l.length - 20) : l);
  } catch (_) {}
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (d) {
    FlutterError.presentError(d);
    unawaited(logErr(d.exceptionAsString()));
  };
  WidgetsBinding.instance.platformDispatcher.onError = (e, s) {
    unawaited(logErr('$e'));
    return true;
  };
  await initializeDateFormatting();
  try {
    recDir = '${(await getApplicationDocumentsDirectory()).path}/receipts';
    Directory(recDir).createSync(recursive: true);
  } catch (_) {}
  await st.load();
  st.applyRec();
  unawaited(st.pushWidget());
  try {
    HomeWidget.widgetClicked.listen((u) {
      if (u != null) launchAdd.value++;
    });
    final u0 = await HomeWidget.initiallyLaunchedFromHomeWidget();
    if (u0 != null) WidgetsBinding.instance.addPostFrameCallback((_) => launchAdd.value++);
  } catch (_) {}
  unawaited(snapNow());
  await initNotif();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: st,
      builder: (context, _) => MaterialApp(
        title: 'Költségvetés',
        debugShowCheckedModeBanner: false,
        locale: Locale(st.lang),
        supportedLocales: const [Locale('hu'), Locale('en')],
        localizationsDelegates: const [GlobalMaterialLocalizations.delegate, GlobalWidgetsLocalizations.delegate, GlobalCupertinoLocalizations.delegate],
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: st.theme == 'dark' ? ThemeMode.dark : (st.theme == 'light' ? ThemeMode.light : ThemeMode.system),
        builder: (ctx, child) => MediaQuery(data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(MediaQuery.of(ctx).textScaler.scale(1) * st.fs)), child: child ?? const SizedBox()),
        home: const Home(),
      ));
}

class AddField extends StatefulWidget {
  final String hint;
  final void Function(String) onAdd;
  const AddField(this.hint, this.onAdd, {super.key});
  @override
  State<AddField> createState() => _AddFieldState();
}

class _AddFieldState extends State<AddField> {
  final c = TextEditingController();
  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(child: TextField(controller: c, decoration: InputDecoration(hintText: widget.hint, isDense: true))),
        const SizedBox(width: 8),
        FilledButton(
            onPressed: () {
              final v = c.text.trim();
              if (v.isNotEmpty) {
                widget.onAdd(v);
                c.clear();
              }
            },
            child: const Text('Hozzáad')),
      ]);
}

class LockScreen extends StatefulWidget {
  final VoidCallback onOk;
  const LockScreen(this.onOk, {super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  String input = '';
  String err = '';
  Timer? timer;

  int get left {
    final l = ((st.pinUntil - DateTime.now().millisecondsSinceEpoch) / 1000).ceil();
    return l < 0 ? 0 : l;
  }

  void startTimer() {
    timer?.cancel();
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      setState(() {});
      if (left <= 0) t.cancel();
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    if (left > 0) startTimer();
    if (st.bio) WidgetsBinding.instance.addPostFrameCallback((_) => bioTry());
  }

  Future<void> bioTry() async {
    try {
      final ok = await LocalAuthentication().authenticate(localizedReason: tr('Oldd fel az alkalmazást'), options: const AuthenticationOptions(biometricOnly: true));
      if (ok) widget.onOk();
    } catch (_) {}
  }

  void press(String d) {
    if (left > 0 || input.length >= 4) return;
    setState(() {
      input += d;
      err = '';
    });
    if (input.length == 4) {
      if (hashPin(input) == st.pin) {
        st.pinOk();
        widget.onOk();
      } else {
        st.pinFail();
        setState(() {
          input = '';
          err = 'Hibás PIN';
        });
        if (left > 0) startTimer();
      }
    }
  }

  Widget key(String d) => Padding(padding: const EdgeInsets.all(6), child: SizedBox(width: 80, height: 64, child: OutlinedButton(onPressed: left > 0 ? null : () => press(d), child: Text(d, style: const TextStyle(fontSize: 22)))));
  Widget cell(Widget w) => SizedBox(width: 92, height: 76, child: Center(child: w));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: Center(
                child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 320),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Text('Költségvetés', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      const Text('Add meg a PIN kódot'),
                      const SizedBox(height: 18),
                      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        for (var i = 0; i < 4; i++)
                          Container(margin: const EdgeInsets.symmetric(horizontal: 6), width: 14, height: 14, decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.grey, width: 2), color: i < input.length ? Theme.of(context).colorScheme.primary : null)),
                      ]),
                      SizedBox(height: 48, child: Center(child: Text(left > 0 ? trf('Túl sok hibás próbálkozás. Próbáld újra {0} másodperc múlva.', [left]) : err, textAlign: TextAlign.center, style: const TextStyle(color: cOut)))),
                      for (final row in [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']]) Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (final d in row) key(d)]),
                      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        cell(st.bio ? IconButton(icon: const Icon(Icons.fingerprint, size: 32), onPressed: bioTry) : const SizedBox()),
                        key('0'),
                        cell(IconButton(icon: const Icon(Icons.backspace_outlined), onPressed: left > 0 ? null : () => setState(() => input = input.isEmpty ? '' : input.substring(0, input.length - 1)))),
                      ]),
                    ])))));
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  int tab = 0;
  int listLim = 80;

  void onLaunchAdd() {
    if (!mounted) return;
    if (st.pin.isNotEmpty && !unlocked) {
      pendingQa = 'out';
      return;
    }
    runQa('out');
  }

  @override
  void dispose() {
    launchAdd.removeListener(onLaunchAdd);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) st.flush();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    launchAdd.addListener(onLaunchAdd);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _np.getNotificationAppLaunchDetails().then((dts) {
        final r = dts?.notificationResponse;
        if ((dts?.didNotificationLaunchApp ?? false) && r != null && (r.actionId == 'add' || r.payload == 'add')) launchAdd.value++;
      }).catchError((_) {});
      if (st.pin.isEmpty) {
        firstRun();
        notifPermOnce();
      }
      const qa = QuickActions();
      qa.initialize((type) {
        if (!mounted) return;
        if (st.pin.isNotEmpty && !unlocked) {
          pendingQa = type;
          return;
        }
        runQa(type);
      });
      qa.setShortcutItems([
        ShortcutItem(type: 'out', localizedTitle: tr('Új kiadás')),
        ShortcutItem(type: 'in', localizedTitle: tr('Új bevétel')),
        ShortcutItem(type: 'tr', localizedTitle: tr('Átvezetés')),
      ]);
    });
  }

  bool unlocked = false;
  String? pendingQa;
  int snapTick = 0;

  void runQa(String type) {
    if (type == 'out' || type == 'in') {
      openSheet(newType: type, lock: true);
    } else if (type == 'tr') {
      openSheet(newType: 'tr');
    }
  }


  static const List<List<String>> _tut = [
    ['Üdv a Költségvetésben!', 'Egyszerű pénzkövető: látod, mennyi pénzed van, mire költesz és mennyit keresel. Minden adatod csak a saját telefonodon marad. A bemutató pár perc, és bármikor újra megnyithatod: Beállítások → Súgó.'],
    ['Így néz ki az app', 'Fent balra a menü (☰), középen a hónap, jobbra a beállítások (⚙). A kerek + gombbal veszel fel új tételt. Az Áttekintésen mindig látod az egyenlegedet, külön a készpénzt és a bankkártyát.'],
    ['Kategóriák', 'A kiadásokat kategóriákba rendezed, például Élelmiszer vagy Közlekedés. Mindegyiknek saját színt adhatsz. A menüben (☰) a Kategóriák pontnál állítod be. Ezzel érdemes kezdeni.'],
    ['Kiadás és bevétel rögzítése', 'Koppints a + gombra, és add meg az összeget. Válaszd ki, hogy készpénzzel vagy kártyával fizettél, és melyik kategóriába tartozik. Ha szeretnéd, írj megjegyzést vagy címkét, és fotózd le a bizonylatot.'],
    ['Gyorsabb rögzítés', 'Amit gyakran rögzítesz, mentsd el sablonként: egy koppintással kész. A leggyakoribb kiadásaid „Gyors kiadás” gombként is megjelennek. Androidon a főképernyőre widgetet is tehetsz, és a napi emlékeztetőről is rögzíthetsz.'],
    ['Hangos bevitel (opcionális)', 'Mondd ki a kiadást, például „kávé ezerkétszáz forint”, és az app kitölti az összeget és a tételt. A mikrofon gomb az összeg mellett jelenik meg. Bekapcsolni a Beállítások → Funkciók alatt lehet.'],
    ['Nyugta beolvasása (opcionális)', 'Fotózd le a nyugtát: az app felismeri az üzletet, a dátumot és a tételeket. Te átnézed, és egy kiadásként rögzül. Ha később rányomsz a kiadásra, látod a nyugta tételeit. Bekapcsolni a Beállítások → Funkciók alatt lehet.'],
    ['Rendszeres kifizetések', 'A havonta ismétlődő kiadások (például egy előfizetés) maguktól felkerülnek. Új tételnél jelöld be a „Rendszeres kifizetés” négyzetet. Ha az app észreveszi, hogy valami minden hónapban ismétlődik, magától is javasolja.'],
    ['Célok, hitel, kintlévőség', 'A megtakarítási célnál összeget és határidőt adsz meg, az app kiszámolja a havi félretételt. A hitelnél a törlesztést követed, a kintlévőségnél azt, ha valakinek kölcsönadtál. Mind a menüben (☰) található.'],
    ['Áttekintés és összefoglalók', 'Az Áttekintés mutatja a havi kiadást és bevételt, a hónap végére várható egyenleget és a közelgő fizetéseket. Hónap végén havi összefoglalót kapsz. A kimutatásokból PDF és Excel jelentés is készíthető, a Naptárban napokra bontva látod a tételeket.'],
    ['Devizaszámla (opcionális)', 'Ha külföldi pénzt is kezelsz, kapcsold be a Beállítások → Funkciók alatt. A devizaszámla külön van a forinttól. A menü Pénzváltás pontjánál váltasz forint és deviza között: megadod az árfolyamot, az app kiszámolja az összeget.'],
    ['Biztonság és mentés', 'PIN kóddal és ujjlenyomattal zárolhatod az appot. Az adataid csak a telefonodon vannak, ezért időnként készíts mentést: fájlba, kérésre jelszóval védve. Az app naponta automatikus másolatot is készít. Telefoncsere előtt mindig mentsd el az adatokat.'],
    ['Te döntesz', 'Az opcionális funkciókat (devizaszámla, hangos bevitel, nyugta beolvasása) a Beállítások → Funkciók alatt bármikor ki- és bekapcsolhatod. Ha valami nem működik, a Beállítások → Súgó → Hiba jelentése gombbal jelezheted.'],
    ['Kezdjük!', 'A következő lépésben megadhatod a kezdő értékeket: mennyi készpénzed és mennyi pénzed van most a bankkártyádon. Utána használatra kész az app. Jó gazdálkodást!'],
  ];

  Future<void> firstRun() async {
    if (!st.langSet) await pickLanguage();
    if (!st.tutDone && mounted) await showTutorial();
    if (!st.initDone && mounted) await initDialog();
    if (!st.fxDecided && mounted) await fxAskDialog();
  }

  Future<void> fxAskDialog() async {
    var fx = false, vc = false, sc = false;
    await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (d) => StatefulBuilder(
            builder: (d, setD) => AlertDialog(
                  scrollable: true,
                  title: const Text('Opcionális funkciók'),
                  content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Válaszd ki, mit szeretnél használni. Ami nincs bekapcsolva, az nem jelenik meg az appban. Később a Beállítások → Funkciók alatt bármikor megváltoztathatod.'),
                    SwitchListTile(contentPadding: EdgeInsets.zero, value: fx, onChanged: (v) => setD(() => fx = v), title: const Text('Devizaszámla'), subtitle: const Text('Külföldi pénz kezelése a forinttól függetlenül, pénzváltással.')),
                    SwitchListTile(contentPadding: EdgeInsets.zero, value: vc, onChanged: (v) => setD(() => vc = v), title: const Text('Hangos bevitel'), subtitle: const Text('Kimondod a kiadást, az app kitölti.')),
                    SwitchListTile(contentPadding: EdgeInsets.zero, value: sc, onChanged: (v) => setD(() => sc = v), title: const Text('Nyugta beolvasása'), subtitle: const Text('Lefotózod a nyugtát, az app felismeri a tételeket.')),
                  ]),
                  actions: [
                    FilledButton(
                        onPressed: () {
                          st.setVoiceOn(vc);
                          st.setScanOn(sc);
                          st.setFxOn(fx);
                          Navigator.pop(d);
                        },
                        child: const Text('Kész')),
                  ],
                )));
  }

  Future<void> initDialog() async {
    final c = TextEditingController(), k = TextEditingController();
    double pv(String s) => double.tryParse(s.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
    void done(bool save) {
      st.change(() {
        st.openCash = save ? pv(c.text) : 0;
        st.openCard = save ? pv(k.text) : 0;
        st.initDone = true;
      });
    }

    await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (d) => AlertDialog(
              scrollable: true,
              title: Row(children: [const Text('Kezdő értékek'), if (st.cur != 'HUF' && st.cur.isNotEmpty) ...[const SizedBox(width: 8), m.Text('· ${st.cur}')]]),
              content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Add meg, mennyi pénzed van most. Az app ettől az összegtől számolja tovább az egyenlegedet, minden későbbi bevétel és kiadás ehhez adódik hozzá. Ezt később nem kell megadnod újra.'),
                const SizedBox(height: 12),
                TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Készpénz'), suffixText: st.csym, border: const OutlineInputBorder())),
                const SizedBox(height: 8),
                TextField(controller: k, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Bankkártya'), suffixText: st.csym, border: const OutlineInputBorder())),
              ]),
              actions: [
                TextButton(
                    onPressed: () {
                      done(false);
                      Navigator.pop(d);
                    },
                    child: const Text('Kihagyás')),
                FilledButton(
                    onPressed: () {
                      done(true);
                      Navigator.pop(d);
                    },
                    child: const Text('Mentés')),
              ],
            ));
  }

  Future<void> pickLanguage() async {
    await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (d) => AlertDialog(
              title: const m.Text('Nyelv / Language'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                        onPressed: () {
                          st.setLang('hu');
                          Navigator.pop(d);
                        },
                        child: const m.Text('Magyar'))),
                const SizedBox(height: 8),
                SizedBox(
                    width: double.infinity,
                    child: FilledButton.tonal(
                        onPressed: () {
                          st.setLang('en');
                          Navigator.pop(d);
                        },
                        child: const m.Text('English'))),
              ]),
            ));
  }

  Future<void> showTutorial() async {
    var i = 0;
    await showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (d) => StatefulBuilder(builder: (d, setD) {
              final last = i == _tut.length - 1;
              return AlertDialog(
                scrollable: true,
                title: Text(_tut[i][0]),
                content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    for (var k = 0; k < _tut.length; k++)
                      Container(margin: const EdgeInsets.symmetric(horizontal: 3), width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: k == i ? Theme.of(context).colorScheme.primary : Colors.grey.shade400)),
                  ]),
                  const SizedBox(height: 16),
                  Text(_tut[i][1]),
                ]),
                actions: [
                  if (!last) TextButton(onPressed: () => Navigator.pop(d), child: const Text('Kihagyás')),
                  if (i > 0) TextButton(onPressed: () => setD(() => i--), child: const Text('Vissza')),
                  FilledButton(
                      onPressed: () {
                        if (last) {
                          Navigator.pop(d);
                        } else {
                          setD(() => i++);
                        }
                      },
                      child: Text(last ? 'Kezdjük' : 'Tovább')),
                ],
              );
            }));
    if (!st.tutDone) st.change(() => st.tutDone = true);
  }
  String lt = 'out';
  bool dv = false;
  bool selMode = false;
  Set<String> selIds = {};
  List<String> visIds = [];
  DateTime sel = DateTime.now();

  void shift(int d) {
    final m = DateTime(st.month.year, st.month.month + d);
    sel = DateTime(m.year, m.month, 1);
    listLim = 80;
    st.change(() => st.month = m);
  }

  void ask(String msg, VoidCallback ok) => showDialog(
      context: context,
      builder: (d) => AlertDialog(content: Text(msg), actions: [
            TextButton(onPressed: () => Navigator.pop(d), child: const Text('Nem')),
            FilledButton(
                onPressed: () {
                  Navigator.pop(d);
                  ok();
                },
                child: const Text('Igen')),
          ]));

  @override
  Widget build(BuildContext context) => ListenableBuilder(
      listenable: st,
      builder: (context, _) {
        if (st.pin.isNotEmpty && !unlocked) {
          return LockScreen(() {
            setState(() => unlocked = true);
            WidgetsBinding.instance.addPostFrameCallback((_) {
              firstRun();
              notifPermOnce();
              final q = pendingQa;
              pendingQa = null;
              if (q != null) runQa(q);
            });
          });
        }
        if (tab == 1) lt = 'in';
        if (tab == 2) lt = 'out';
        final pages = <Widget Function()>[home, list, list, trPage, cal, stats, cats, yearPage, sgSection, catEditor, loanPage, recvPage];
        final dark = Theme.of(context).brightness == Brightness.dark;
        return Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: dark ? const [0, 0.45, 1] : const [0, 1],
                    colors: dark ? const [Color(0xFF13306B), Color(0xFF0A1431), Color(0xFF060D22)] : const [Color(0xFFE3ECFF), Color(0xFFF5F8FF)])),
            child: Scaffold(
          backgroundColor: Colors.transparent,
          drawer: Drawer(
            child: SafeArea(
              child: ListView(padding: EdgeInsets.zero, children: [
                dProfile(),
                dItem(Icons.account_balance_wallet_outlined, 'Áttekintés', 0),
                dSec('Pénzmozgások'),
                dItem(Icons.calendar_month_outlined, 'Naptár', 4),
                dItem(Icons.swap_horiz, st.fxOn ? 'Átvezetések és váltások' : 'Átvezetések', 3),
                if (st.fxOn && st.fxCodes.isNotEmpty)
                  ListTile(
                      dense: true,
                      leading: const Icon(Icons.currency_exchange),
                      title: const Text('Pénzváltás'),
                      onTap: () {
                        Navigator.pop(context);
                        xchDialog();
                      }),
                dSec('Tervek és tartozások'),
                dItem(Icons.savings_outlined, 'Megtakarítási célok', 8),
                dItem(Icons.account_balance_outlined, 'Hitel', 10),
                dItem(Icons.handshake_outlined, 'Kintlévőség', 11),
                dSec('Kimutatások'),
                dItem(Icons.pie_chart_outline, 'Havi kimutatás', 5),
                dItem(Icons.bar_chart, 'Éves kimutatás', 7, onSel: () => yv = st.month.year),
                dSec('Kezelés'),
                dItem(Icons.category_outlined, 'Kategóriák', 9),
                if (st.ws == 'fx' && st.cur.isNotEmpty)
                  ListTile(
                      dense: true,
                      leading: const Icon(Icons.add_circle_outline),
                      title: const Text('Deviza hozzáadása'),
                      onTap: () {
                        Navigator.pop(context);
                        addCurrencyDialog();
                      }),
                dFooter(),
              ]),
            ),
          ),
          appBar: AppBar(
            centerTitle: true,
            backgroundColor: Colors.transparent,
            surfaceTintColor: Colors.transparent,
            elevation: 0,
            scrolledUnderElevation: 0,
            leading: tab == 6 ? IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => setState(() => tab = 0)) : null,
            actions: [
              if (tab != 0)
                IconButton(
                    icon: const Icon(Icons.home_outlined),
                    tooltip: tr('Áttekintés'),
                    onPressed: () => setState(() {
                          tab = 0;
                          selMode = false;
                          selIds = {};
                          dv = false;
                        })),
              IconButton(icon: Icon(tab == 6 ? Icons.settings : Icons.settings_outlined), tooltip: tr('Beállítások'), onPressed: () => setState(() => tab = 6)),
            ],
            title: Row(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 32, minHeight: 36), onPressed: () => shift(-1), icon: const Icon(Icons.chevron_left)),
              Flexible(
                  child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: pickMonth,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(['Pénzügyi áttekintés', 'Bevételek', 'Kiadások', 'Átvezetések', 'Naptár', 'Havi kimutatás', 'Beállítások', 'Éves kimutatás', 'Megtakarítási célok', 'Kategóriák', 'Hitel', 'Kintlévőség'][tab], style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis, maxLines: 1),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Flexible(child: m.Text(dfm('yyyy. MMMM', st.month), style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor), overflow: TextOverflow.ellipsis, maxLines: 1)),
                          Icon(Icons.keyboard_arrow_down, size: 16, color: Theme.of(context).hintColor),
                        ]),
                      ]))),
              IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints(minWidth: 32, minHeight: 36), onPressed: () => shift(1), icon: const Icon(Icons.chevron_right)),
            ]),
          ),
          body: Column(children: [wsBar(), overdueBanner(), Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 96), children: [AnimatedSwitcher(duration: const Duration(milliseconds: 160), child: KeyedSubtree(key: ValueKey(tab), child: (st.ws == 'fx' && st.cur.isEmpty) ? fxStart() : pages[tab]()))]))]),
          floatingActionButton: (tab >= 5 || (st.ws == 'fx' && st.cur.isEmpty))
              ? null
              : SizedBox(
                  width: 68,
                  height: 68,
                  child: FloatingActionButton(
                      shape: const CircleBorder(),
                      tooltip: tr(tab == 3 ? 'Számlák közötti átvezetés' : (tab == 1 ? 'Új bevétel' : (tab == 2 ? 'Új kiadás' : 'Új tétel'))),
                      onPressed: () {
                        HapticFeedback.lightImpact();
                        if (tab == 0 || tab == 4) {
                          addChooser();
                        } else {
                          openSheet(newType: tab == 3 ? 'tr' : (tab == 1 ? 'in' : 'out'), lock: tab == 1 || tab == 2);
                        }
                      },
                      child: const Icon(Icons.add, size: 38))),
          bottomNavigationBar: (st.ws == 'fx' && st.cur.isEmpty) ? null : NavigationBar(
            selectedIndex: (tab == 1 || tab == 2) ? tab - 1 : 0,
            indicatorColor: (tab == 1 || tab == 2) ? null : Colors.transparent,
            onDestinationSelected: (i) => setState(() {
              tab = i + 1;
              dv = false;
              listLim = 80;
              HapticFeedback.selectionClick();
              fc = '';
              ftag = '';
              selMode = false;
              selIds = {};
            }),
            destinations: [
              NavigationDestination(icon: Icon(Icons.trending_up), label: tr('Bevételek')),
              NavigationDestination(icon: Icon(Icons.trending_down), label: tr('Kiadások')),
            ],
          ),
        ));
      });

  Widget box(String label, double v, Color c, [String? code]) => Card(
      margin: EdgeInsets.zero,
      child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: Theme.of(context).textTheme.bodySmall), Text(ftc(v, code ?? st.cur), style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: c))])));

  Widget fxSumRow(String code) {
    final txs = code == st.cur ? st.txs : (st.fxTxs[code] ?? <Tx>[]);
    double sumT(String type) => txs.where((t) => t.type == type && t.date.year == st.month.year && t.date.month == st.month.month).fold(0.0, (a, t) => a + t.amt);
    return Padding(padding: const EdgeInsets.only(bottom: 16), child: Row(children: [Expanded(child: box('Bevétel', sumT('in'), cIn, code)), const SizedBox(width: 12), Expanded(child: box('Kiadás', sumT('out'), cOut, code))]));
  }

  Future<void> selectCur(String code) async {
    await st.switchTo('fx', code);
    if (!mounted) return;
    setState(() {
      tab = 0;
      selMode = false;
      selIds = {};
    });
  }

  Widget dSec(String t) => Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 4), child: m.Text(tr(t).toUpperCase(), style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 0.5, color: Theme.of(context).hintColor)));

  Widget dItem(IconData ic, String title, int t, {VoidCallback? onSel}) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 1),
      child: ListTile(
          dense: true,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          leading: Icon(ic),
          title: Text(title),
          trailing: const Icon(Icons.chevron_right, size: 20),
          selected: tab == t,
          selectedColor: Colors.white,
          selectedTileColor: const Color(0xFF2563EB),
          onTap: () {
            setState(() {
              tab = t;
              dv = false;
              listLim = 80;
              HapticFeedback.selectionClick();
              if (onSel != null) onSel();
            });
            Navigator.pop(context);
          }));

  Widget dProfile() => Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
      child: Row(children: [
        Container(width: 48, height: 48, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(center: Alignment(-0.4, -0.5), colors: [Color(0xFF6BB0FF), Color(0xFF1D4ED8)])), child: const Icon(Icons.account_balance_wallet_outlined, color: Colors.white)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Költségvetés', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), Text('Személyes pénzügyek', style: TextStyle(fontSize: 13, color: Theme.of(context).hintColor))])),
      ]));

  Widget dFooter() {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
        child: Column(children: [
          Row(children: [
            Icon(dark ? Icons.dark_mode_outlined : Icons.light_mode_outlined, size: 20),
            const SizedBox(width: 10),
            const Expanded(child: Text('Világos mód')),
            Switch(value: !dark, onChanged: (v) => st.change(() => st.theme = v ? 'light' : 'dark')),
          ]),
          m.Text('v$kVer', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
        ]));
  }

  Widget heroCard(String code, double c, double b, double rv, {double inc = 0, VoidCallback? onTap, VoidCallback? onDelete, bool dim = false}) {
    final t = c + b;
    Widget acc(String l, double v, Color col, {bool first = false}) => Expanded(
        child: Container(
            padding: EdgeInsets.only(left: first ? 0 : 10),
            decoration: first ? null : const BoxDecoration(border: Border(left: BorderSide(color: Colors.white24))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [CircleAvatar(radius: 4, backgroundColor: col), const SizedBox(width: 6), Flexible(child: Text(l, style: const TextStyle(color: Colors.white70, fontSize: 12), overflow: TextOverflow.ellipsis, maxLines: 1))]),
              FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: m.Text(hv(ftc(v, code)), style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700))),
            ])));
    return Opacity(
        opacity: dim ? 0.85 : 1,
        child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(24),
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF2563EB), Color(0xFF1E3A8A), Color(0xFF16286B)]),
                  border: Border.all(color: const Color(0x6693C5FD)),
                  boxShadow: const [BoxShadow(color: Color(0x661E40AF), blurRadius: 30, offset: Offset(0, 12))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Container(width: 58, height: 58, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(center: Alignment(-0.4, -0.5), colors: [Color(0xFF6BB0FF), Color(0xFF1D4ED8)])), child: const Icon(Icons.account_balance_wallet_outlined, color: Colors.white, size: 30)),
                  const SizedBox(width: 14),
                  Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Text('Teljes egyenleg', style: TextStyle(color: Colors.white70, fontSize: 15)),
                      if (code != 'HUF') ...[const SizedBox(width: 8), m.Text(code, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13))],
                      const SizedBox(width: 8),
                      Semantics(button: true, label: tr('Egyenleg elrejtése'), child: InkWell(onTap: () => st.setHide(!st.hide), child: Icon(st.hide ? Icons.visibility_off_outlined : Icons.visibility_outlined, color: Colors.white70, size: 20))),
                      const Spacer(),
                      if (onDelete != null) InkWell(onTap: onDelete, child: const Icon(Icons.delete_outline, color: Colors.white70, size: 20)),
                    ]),
                    FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: m.Text(hv(ftc(t, code)), style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800))),
                    Row(children: [
                      const Icon(Icons.arrow_upward, size: 15, color: Color(0xFF6EE7B7)),
                      const SizedBox(width: 4),
                      Flexible(child: m.Text(hv(ftc(inc, code)), style: const TextStyle(color: Color(0xFF6EE7B7), fontWeight: FontWeight.w700), overflow: TextOverflow.ellipsis)),
                      const SizedBox(width: 4),
                      const Text('bevétel', style: TextStyle(color: Color(0xFF6EE7B7))),
                    ]),
                  ])),
                ]),
                const SizedBox(height: 16),
                const Divider(color: Colors.white24, height: 1),
                const SizedBox(height: 14),
                Row(children: [acc('Készpénz', c, cCash, first: true), acc('Bankkártya', b, cCard), if (rv > 0) acc('Kintlévőség', rv, const Color(0xFFC084FC))]),
              ]),
            )));
  }

  bool tplEdit = false;

  Widget tplRow() {
    if (st.tpl.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 8, bottom: 6), child: Row(children: [Expanded(child: Text('Sablonok', style: Theme.of(context).textTheme.titleMedium)), TextButton(onPressed: () => setState(() => tplEdit = !tplEdit), child: Text(tplEdit ? 'Kész' : 'Szerkesztés'))])),
      Wrap(spacing: 8, runSpacing: 4, children: [
        for (final t in st.tpl)
          tplEdit ? InputChip(label: m.Text('${t.name} · ${ft(t.amt)}'), onDeleted: () => st.change(() => st.tpl.removeWhere((x) => x.id == t.id))) : ActionChip(label: m.Text('${t.name} · ${ft(t.amt)}'), onPressed: () => recordTpl(t)),
      ]),
      const SizedBox(height: 8),
    ]);
  }

  void recordTpl(Tpl t) {
    void go() {
      final id = uid();
      final n = DateTime.now();
      st.change(() => st.txs.add(Tx(id: id, type: t.type, acc: t.acc, cat: t.cat, item: t.item, amt: t.amt, date: DateTime(n.year, n.month, n.day), note: t.note, tags: List<String>.from(t.tags))));
      HapticFeedback.lightImpact();
      snackUndo(trf('Rögzítve: {0}', ['${t.name} ${ft(t.amt)}']), () => st.change(() => st.txs.removeWhere((x) => x.id == id)));
    }

    if (t.type == 'out' && st.bal(t.acc) < t.amt) {
      ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a tétel összege {2}. Biztosan rögzíted?', [accName(t.acc), ft(st.bal(t.acc) < 0 ? 0 : st.bal(t.acc)), ft(t.amt)]), go);
    } else {
      go();
    }
  }

  Future<void> scanReceipt(ImageSource src) async {
    try {
      final x = await ImagePicker().pickImage(source: src, maxWidth: 2400, imageQuality: 90);
      if (x == null || !mounted) return;
      final text = await busy(() => ocrReceipt(x.path));
      await reviewReceipt(text, x.path);
    } catch (e) {
      unawaited(logErr('ocr: $e'));
      snack('A nyugta felismerése nem sikerült.');
    }
  }

  void showReceipt(Tx t) {
    final hint = Theme.of(context).hintColor;
    showDialog<void>(
        context: context,
        builder: (d) => AlertDialog(
              scrollable: true,
              title: m.Text('🧾 ${t.rs.isEmpty ? tr('Nyugta') : t.rs}'),
              content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                m.Text('${dfm('yyyy. MMMM d.', t.date)} · ${accName(t.acc)} · ${st.catName(t.cat)}', style: TextStyle(fontSize: 13, color: hint)),
                const SizedBox(height: 10),
                for (final x in t.rl)
                  Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: m.Text('${x['n']}')), const SizedBox(width: 8), m.Text(ft((x['a'] as num).toDouble()), style: const TextStyle(fontWeight: FontWeight.w700))])),
                const Divider(),
                Row(children: [const Expanded(child: Text('Összesen', style: TextStyle(fontWeight: FontWeight.w800))), m.Text(ft(t.amt), style: const TextStyle(fontWeight: FontWeight.w800))]),
                Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                        onPressed: () {
                          Navigator.pop(d);
                          editReceiptLines(t);
                        },
                        child: const Text('Tételek szerkesztése'))),
                if (t.tags.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: m.Text(t.tags.map((x) => '#$x').join(' '), style: TextStyle(color: hint))),
                if (t.ph)
                  Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: GestureDetector(
                          onTap: () => showDialog<void>(context: d, builder: (dd) => Dialog(child: InteractiveViewer(child: Image.file(File('$recDir/${t.id}.jpg'))))),
                          child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File('$recDir/${t.id}.jpg'), height: 160, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink())))),
              ]),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.pop(d);
                      final id = t.id;
                      st.change(() {
                        st.trash.add(t);
                        st.txs.removeWhere((x) => x.id == id);
                      });
                      snackUndo('Tétel törölve.', () => undelTx([id]));
                    },
                    child: const Text('Törlés')),
                TextButton(
                    onPressed: () {
                      Navigator.pop(d);
                      openSheet(edit: t, lock: tab == 1 || tab == 2);
                    },
                    child: const Text('Szerkesztés')),
                FilledButton(onPressed: () => Navigator.pop(d), child: const Text('Bezárás')),
              ],
            ));
  }

  Future<void> editReceiptLines(Tx t) async {
    double num0(TextEditingController c) => double.tryParse(c.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
    final ns = <TextEditingController>[for (final x in t.rl) TextEditingController(text: '${x['n']}')];
    final ams = <TextEditingController>[for (final x in t.rl) TextEditingController(text: amtStr((x['a'] as num).toDouble()))];
    final ok = await showDialog<bool>(
        context: context,
        builder: (d) => StatefulBuilder(builder: (d, setD) {
              final sum = ams.fold(0.0, (a, c) => a + num0(c));
              return AlertDialog(
                  scrollable: true,
                  title: const Text('Tételek szerkesztése'),
                  content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Az összeg a tételek összege lesz.'),
                    const SizedBox(height: 8),
                    for (var i = 0; i < ns.length; i++)
                      Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Row(children: [
                            Expanded(child: TextField(controller: ns[i], decoration: InputDecoration(isDense: true, hintText: tr('Tétel neve'), border: const OutlineInputBorder()))),
                            const SizedBox(width: 6),
                            SizedBox(width: 84, child: TextField(controller: ams[i], keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setD(() {}), decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()))),
                            IconButton(
                                icon: const Icon(Icons.close),
                                onPressed: () => setD(() {
                                      ns.removeAt(i);
                                      ams.removeAt(i);
                                    })),
                          ])),
                    Align(
                        alignment: Alignment.centerLeft,
                        child: TextButton.icon(
                            onPressed: () => setD(() {
                                  ns.add(TextEditingController());
                                  ams.add(TextEditingController());
                                }),
                            icon: const Icon(Icons.add),
                            label: const Text('+ Új sor'))),
                    Row(children: [const Expanded(child: Text('Összesen', style: TextStyle(fontWeight: FontWeight.w800))), m.Text(ft(sum), style: const TextStyle(fontWeight: FontWeight.w800))]),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Mégse')),
                    FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Mentés')),
                  ]);
            }));
    if (ok != true || !mounted) return;
    final lines = <Map<String, dynamic>>[];
    for (var i = 0; i < ns.length; i++) {
      final a = num0(ams[i]);
      if (a > 0) lines.add({'n': ns[i].text.trim().isEmpty ? tr('Tétel') : ns[i].text.trim(), 'a': a});
    }
    if (lines.isEmpty) {
      snack('Legalább egy tétel kell.');
      return;
    }
    st.change(() {
      t.rl = lines;
      t.amt = (lines.fold(0.0, (a, x) => a + (x['a'] as double)) * 100).round() / 100;
    });
    snack('A nyugta tételei mentve.');
    showReceipt(t);
  }

  Future<void> reviewReceipt(String text, String? photo) async {
    final p = parseReceipt(text, DateTime.now());
    if (p.items.isEmpty) {
      snack('Nem sikerült tételeket felismerni, javítsd a szöveget.');
      await receiptPaste(text, photo);
      return;
    }
    if (!mounted) return;
    final ids = await Navigator.of(context).push<List<String>>(MaterialPageRoute(fullscreenDialog: true, builder: (_) => ReceiptReview(p, photo)));
    if (ids == null || ids.isEmpty || !mounted) return;
    HapticFeedback.mediumImpact();
    final tot = st.txs.where((t) => ids.contains(t.id)).fold(0.0, (a, t) => a + t.amt);
    final one = st.txs.any((t) => ids.contains(t.id) && t.rl.isNotEmpty);
    snackUndo(one ? trf('Nyugta elkönyvelve: {0}', [ft(tot)]) : trf('{0} kiadás elkönyvelve a nyugtáról: {1}', [ids.length, ft(tot)]), () => st.change(() => st.txs.removeWhere((t) => ids.contains(t.id))));
  }

  Future<void> receiptPaste(String initial, String? photo) async {
    final c = TextEditingController(text: initial);
    final r = await showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
              title: const Text('Nyugta szövegének beillesztése'),
              scrollable: true,
              content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Illeszd be a nyugta szövegét (soronként egy tétel, az ár a sor végén).'),
                const SizedBox(height: 8),
                TextField(controller: c, minLines: 6, maxLines: 12, style: const TextStyle(fontFamily: 'monospace', fontSize: 13), decoration: const InputDecoration(border: OutlineInputBorder())),
              ]),
              actions: [
                TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse')),
                FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('Feldolgozás')),
              ],
            ));
    if (r == null || r.trim().isEmpty) return;
    await reviewReceipt(r, photo);
  }

  Future<String?> listenVoice() async {
    final sp = stt.SpeechToText();
    var err = false;
    final ok = await sp.initialize(onError: (e) => err = true);
    if (!ok) {
      snack('A hangfelismerés nem érhető el ezen az eszközön.');
      return null;
    }
    snack('Hallgatlak…');
    final c = Completer<String?>();
    await sp.listen(
        localeId: st.lang == 'en' ? 'en_US' : 'hu_HU',
        listenFor: const Duration(seconds: 12),
        pauseFor: const Duration(seconds: 3),
        onResult: (r) {
          if (r.finalResult && !c.isCompleted) c.complete(r.recognizedWords);
        });
    Future.delayed(const Duration(seconds: 15), () {
      if (!c.isCompleted) {
        sp.stop();
        c.complete(null);
      }
    });
    final r = await c.future;
    if (r == null || r.trim().isEmpty) {
      if (err) snack('A hangfelismerés nem sikerült.');
      return null;
    }
    return r;
  }

  Map<String, dynamic> monthReport(int y, int mo) {
    final pd = DateTime(y, mo - 1);
    final tx = st.txs.where((t) => t.date.year == y && t.date.month == mo).toList();
    final ptx = st.txs.where((t) => t.date.year == pd.year && t.date.month == pd.month).toList();
    final inc = st.sum(tx, 'in'), out = st.sum(tx, 'out'), pout = st.sum(ptx, 'out');
    final ex = tx.where((t) => t.type == 'out' && t.xid.isEmpty).toList();
    final by = <String, double>{};
    for (final t in ex) {
      by[t.cat] = (by[t.cat] ?? 0) + t.amt;
    }
    final ent = by.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    ex.sort((a, b) => b.amt.compareTo(a.amt));
    return {'inc': inc, 'out': out, 'saved': inc - out, 'rate': inc > 0 ? (inc - out) / inc * 100 : 0.0, 'top': ent.take(3).toList(), 'big': ex.isEmpty ? null : ex.first, 'delta': pout > 0 ? (out - pout) / pout * 100 : null, 'count': tx.length};
  }

  String rptKey() {
    final n = DateTime.now();
    final dim = DateUtils.getDaysInMonth(n.year, n.month);
    if (n.day >= dim - 2) return '${n.year}-${n.month.toString().padLeft(2, '0')}';
    if (n.day <= 7) {
      final p = DateTime(n.year, n.month - 1);
      return '${p.year}-${p.month.toString().padLeft(2, '0')}';
    }
    return '';
  }

  Widget rptCard() {
    final k = rptKey();
    if (k.isEmpty || st.rptDismiss == k) return const SizedBox.shrink();
    final p = k.split('-');
    final y = int.parse(p[0]), mo = int.parse(p[1]);
    if ((monthReport(y, mo)['count'] as int) == 0) return const SizedBox.shrink();
    return Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: m.Text('${tr('Havi összefoglaló')} · ${dfm('yyyy. MMMM', DateTime(y, mo))}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
                IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.close, size: 18), onPressed: () => st.change(() => st.rptDismiss = k)),
              ]),
              const Text('Nézd meg, mire költöttél és mennyit tettél félre.'),
              const SizedBox(height: 10),
              FilledButton(onPressed: () => rptShow(k), child: const Text('Megnyitás')),
            ])));
  }

  void rptShow(String key) {
    final p = key.split('-');
    final y = int.parse(p[0]), mo = int.parse(p[1]);
    final r = monthReport(y, mo);
    final top = (r['top'] as List).cast<MapEntry<String, double>>();
    final big = r['big'] as Tx?;
    final delta = r['delta'] as double?;
    final saved = r['saved'] as double, rate = r['rate'] as double, inc = r['inc'] as double;
    String nm(String id) => st.catName(id).isEmpty ? 'Egyéb' : st.catName(id);
    showDialog<void>(
        context: context,
        builder: (d) => AlertDialog(
              scrollable: true,
              title: m.Text('${tr('Havi összefoglaló')} · ${dfm('yyyy. MMMM', DateTime(y, mo))}'),
              content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Expanded(child: box('Bevétel', inc, cIn)), const SizedBox(width: 8), Expanded(child: box('Kiadás', r['out'] as double, cOut))]),
                const SizedBox(height: 10),
                Wrap(children: [const Text('Félretett összeg'), m.Text(': ${ft(saved)}${inc > 0 ? ' (${rate.round()}%)' : ''}', style: TextStyle(fontWeight: FontWeight.w700, color: saved >= 0 ? cIn : cOut))]),
                if (top.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(trf('A legnagyobb kiadási kategóriád: {0}', ['${nm(top.first.key)} (${ft(top.first.value)})']))),
                if (big != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(trf('A legnagyobb egyedi kiadásod: {0}', ['${st.itemName(big.cat, big.item).isEmpty ? (st.catName(big.cat).isEmpty ? 'Kiadás' : st.catName(big.cat)) : st.itemName(big.cat, big.item)}, ${ft(big.amt)}']))),
                Padding(padding: const EdgeInsets.only(top: 8), child: delta == null ? const Text('Nincs előző havi adat az összehasonlításhoz.') : Text(trf(delta <= 0 ? 'Az előző hónaphoz képest {0}%-kal kevesebbet költöttél.' : 'Az előző hónaphoz képest {0}%-kal többet költöttél.', [delta.abs().round()]))),
                if (top.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Text('Fő kategóriák', style: Theme.of(context).textTheme.labelLarge),
                  for (final e in top)
                    Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Row(children: [CircleAvatar(radius: 4, backgroundColor: st.catColorById(e.key)), const SizedBox(width: 8), Expanded(child: Text(nm(e.key))), m.Text(ft(e.value), style: const TextStyle(fontWeight: FontWeight.w700))])),
                ],
              ]),
              actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Bezárás'))],
            ));
  }

  List<Map<String, dynamic>> recCand() {
    final n = DateTime.now();
    final lim = DateTime(n.year, n.month - 6, 1);
    final g = <String, List<Tx>>{};
    for (final t in st.txs) {
      if (t.type != 'out' || t.date.isBefore(lim) || t.cat.isEmpty || t.cat == 'sav' || t.cat == 'loan' || t.linked) continue;
      if (!st.cats.any((c) => c.id == t.cat)) continue;
      g.putIfAbsent('${t.cat}|${t.item}', () => []).add(t);
    }
    int idx(String mk) {
      final q = mk.split('-');
      return int.parse(q[0]) * 12 + int.parse(q[1]);
    }

    final nm = n.year * 12 + n.month;
    final out = <Map<String, dynamic>>[];
    g.forEach((k, l) {
      if (st.recDismiss.contains(k)) return;
      final bym = <String, List<Tx>>{};
      for (final t in l) {
        bym.putIfAbsent(st.ym(t.date), () => []).add(t);
      }
      final ms = bym.keys.toList()..sort();
      if (ms.length < 3) return;
      final l3 = ms.sublist(ms.length - 3);
      if (!(idx(l3[2]) - idx(l3[1]) == 1 && idx(l3[1]) - idx(l3[0]) == 1 && nm - idx(l3[2]) <= 1)) return;
      final pick = [for (final mk in l3) bym[mk]!.first];
      final am = [for (final t in pick) t.amt];
      final avg = am.fold(0.0, (a, b) => a + b) / 3;
      if (am.any((a) => (a - avg).abs() > avg * 0.12)) return;
      final ds = [for (final t in pick) t.date.day];
      final mxd = ds.reduce((a, b) => a > b ? a : b), mnd = ds.reduce((a, b) => a < b ? a : b);
      if (mxd - mnd > 4) return;
      final q = k.split('|');
      if (st.rec.any((r) => r.cat == q[0] && r.item == q[1])) return;
      out.add({'k': k, 'cat': q[0], 'item': q[1], 'acc': pick[2].acc, 'amt': avg.roundToDouble(), 'day': (ds.fold(0, (a, b) => a + b) / 3).round(), 'note': pick[2].note, 'last': l3[2]});
    });
    return out;
  }

  Widget recSugCard() {
    final cs = recCand();
    if (cs.isEmpty) return const SizedBox.shrink();
    final c = cs.first;
    final nm = st.itemName(c['cat'] as String, c['item'] as String).isEmpty ? st.catName(c['cat'] as String) : st.itemName(c['cat'] as String, c['item'] as String);
    return Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(trf('A(z) {0} havonta ismétlődik (kb. {1}). Legyen rendszeres kifizetés?', [nm, ft(c['amt'] as double)])),
              const SizedBox(height: 10),
              Row(children: [
                FilledButton(
                    onPressed: () {
                      st.change(() => st.rec.add(Rec(uid(), 'out', c['acc'] as String, '', c['cat'] as String, c['item'] as String, c['note'] as String, c['last'] as String, c['amt'] as double, c['day'] as int)));
                      rescheduleAll();
                      snack('Rendszeres kifizetés létrehozva.');
                    },
                    child: const Text('Igen, legyen')),
                const SizedBox(width: 8),
                OutlinedButton(onPressed: () => st.change(() => st.recDismiss.add(c['k'] as String)), child: const Text('Nem')),
              ]),
            ])));
  }

  Widget startCard() => Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Kezdjük el!', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Állítsd be a kategóriákat, majd rögzítsd az első tételt. Utána az Áttekintés megtelik adatokkal.'),
            const SizedBox(height: 12),
            Row(children: [
              OutlinedButton(onPressed: () => setState(() => tab = 9), child: const Text('Kategóriák')),
              const SizedBox(width: 8),
              FilledButton(onPressed: () => openSheet(newType: 'out'), child: const Text('Első tétel')),
            ]),
          ])));

  Widget pctLine(double v, double p, bool goodDown) {
    if (p <= 0) return Text('Nincs előző havi adat', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor));
    final d = ((v - p) / p * 100).round();
    final up = d > 0;
    final col = d == 0 ? Theme.of(context).hintColor : ((up != goodDown) ? cIn : cOut);
    return Row(children: [
      Icon(d == 0 ? Icons.remove : (up ? Icons.arrow_upward : Icons.arrow_downward), size: 13, color: col),
      const SizedBox(width: 2),
      Expanded(child: Text(trf('{0}% az előző hónaphoz', [d.abs()]), style: TextStyle(fontSize: 12, color: col))),
    ]);
  }

  Widget tile2(String label, double v, double p, Color col, bool goodDown, String code) => Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [col.withOpacity(0.28), col.withOpacity(0.06)]), border: Border.all(color: col.withOpacity(0.5))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 14)),
        FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft, child: m.Text(hv(ftc(v, code)), style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: col))),
        pctLine(v, p, goodDown),
      ]));

  Widget panel(IconData ic, String title, Widget child, {VoidCallback? onTap}) => Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [Icon(ic, size: 18, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 6), Expanded(child: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)))]),
                const SizedBox(height: 8),
                child,
              ]))));

  List<UpItem> fcEvents() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final end = DateTime(now.year, now.month + 1, 0);
    final tm = today.add(const Duration(days: 1));
    final ev = <UpItem>[];
    for (final r in st.rec) {
      if (r.type == 'tr') continue;
      final d = nextDue(r);
      if (!d.isAfter(end)) ev.add(UpItem(d, '', r.type == 'in' ? r.amt : -r.amt));
    }
    for (final l in st.loans) {
      final s = st.loanState(l, now);
      if (s.rem <= 0) continue;
      final one = l.pay < s.rem ? l.pay : s.rem;
      if (!s.done) {
        var d = st.loanDue(l, now);
        if (!d.isAfter(today)) d = tm;
        if (!d.isAfter(end)) ev.add(UpItem(d, '', -one));
      }
      if (s.missed.isNotEmpty && !tm.isAfter(end)) ev.add(UpItem(tm, '', -s.missed.length * l.pay));
    }
    return ev;
  }

  Widget forecastCard() {
    final now = DateTime.now();
    final y = st.month.year, mo = st.month.month;
    if (y > now.year || (y == now.year && mo > now.month)) return const SizedBox.shrink();
    final isCur = y == now.year && mo == now.month;
    final dim = DateUtils.getDaysInMonth(y, mo);
    final td = isCur ? now.day : dim;
    final tot = st.bal(null);
    final delta = List<double>.filled(dim + 2, 0);
    var afterM = 0.0;
    final mEnd = DateTime(y, mo, dim, 23, 59, 59);
    for (final t in st.txs) {
      if (t.date.isAfter(mEnd)) {
        afterM += t.signed;
      } else if (t.date.year == y && t.date.month == mo) {
        delta[t.date.day] += t.signed;
      }
    }
    double balAt(int d) {
      var r = tot - afterM;
      for (var k = d + 1; k <= dim; k++) {
        r -= delta[k];
      }
      return r;
    }

    final pts = <double>[for (var d = 1; d <= td; d++) balAt(d)];
    var chg = 0.0;
    if (isCur) {
      final ev = fcEvents();
      for (var d = td + 1; d <= dim; d++) {
        pts.add(pts.last + ev.where((e) => e.d.day == d).fold(0.0, (a, e) => a + e.a));
      }
      chg = ev.fold(0.0, (a, e) => a + e.a);
    }
    var mn = pts.first, mx = pts.first;
    for (final v in pts) {
      if (v < mn) mn = v;
      if (v > mx) mx = v;
    }
    final rng = mx - mn;
    final pd = rng > 0 ? rng * 0.15 : (mx.abs() * 0.02 < 1 ? 1.0 : mx.abs() * 0.02);
    final lo = mn - pd, hi = mx + pd;
    final blue = Theme.of(context).colorScheme.primary;
    final hint = Theme.of(context).hintColor;
    final line = Theme.of(context).brightness == Brightness.dark ? const Color(0xFF1D3466) : const Color(0xFFD9E3F7);
    final small = TextStyle(fontSize: 9, color: hint);
    final spots = [for (var i = 0; i < pts.length; i++) FlSpot((i + 1).toDouble(), pts[i])];
    final ms = DateFormat('MMM', st.lang).format(DateTime(y, mo));
    final title = isCur ? trf('Várható egyenleg · {0}', [dfm('MMMM d.', DateTime(y, mo, dim))]) : trf('Egyenleg alakulása · {0}', [dfm('yyyy. MMMM', st.month)]);
    final chip = isCur
        ? Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(999), color: (chg >= 0 ? cIn : cOut).withOpacity(0.12), border: Border.all(color: chg >= 0 ? cIn : cOut)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              m.Text('${chg >= 0 ? '↗ +' : '↘ −'}${hv(ftc(chg.abs(), st.cur))} ', style: TextStyle(fontSize: 12.5, color: chg >= 0 ? cIn : cOut)),
              Text('várható változás', style: TextStyle(fontSize: 12.5, color: chg >= 0 ? cIn : cOut)),
            ]))
        : const SizedBox.shrink();
    return panel(
        Icons.bar_chart,
        title,
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Wrap(spacing: 10, runSpacing: 6, crossAxisAlignment: WrapCrossAlignment.center, children: [m.Text(hv(ftc(pts.last, st.cur)), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)), chip]),
          const SizedBox(height: 10),
          SizedBox(
              height: 150,
              child: LineChart(LineChartData(
                  minX: 1,
                  maxX: dim.toDouble(),
                  minY: lo,
                  maxY: hi,
                  lineTouchData: const LineTouchData(enabled: false),
                  borderData: FlBorderData(show: false),
                  gridData: FlGridData(show: true, drawVerticalLine: false, horizontalInterval: (hi - lo) / 3, getDrawingHorizontalLine: (v) => FlLine(color: line, strokeWidth: 1)),
                  titlesData: FlTitlesData(
                      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 38, interval: (hi - lo) / 3, getTitlesWidget: (v, meta) => m.Text(st.hide ? '' : fmtK(v), style: small))),
                      bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                              showTitles: true,
                              reservedSize: 22,
                              interval: 1,
                              getTitlesWidget: (v, meta) {
                                final d = v.round();
                                if ((v - d).abs() > 0.001 || !(d == 1 || d == dim || d == (dim * 0.25).round() || d == (dim * 0.5).round() || d == (dim * 0.75).round())) return const SizedBox.shrink();
                                return Padding(padding: const EdgeInsets.only(top: 4), child: m.Text('$ms. $d', style: small));
                              }))),
                  lineBarsData: [
                    LineChartBarData(
                        spots: spots.take(td).toList(),
                        color: blue,
                        barWidth: 3,
                        isCurved: false,
                        dotData: FlDotData(show: true, checkToShowDot: (sp, bd) => sp.x == td.toDouble() && !(isCur && td < dim)),
                        belowBarData: BarAreaData(show: true, gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [blue.withOpacity(0.35), blue.withOpacity(0)]))),
                    if (isCur && td < dim) LineChartBarData(spots: spots.skip(td - 1).toList(), color: blue, barWidth: 3, isCurved: false, dashArray: [6, 4], dotData: FlDotData(show: true, checkToShowDot: (sp, bd) => sp.x == dim.toDouble())),
                  ]))),
        ]));
  }

  Widget donutCard() {
    final tx = st.mtx.where((t) => t.type == 'out').toList();
    final tot = st.sum(tx, 'out');
    if (tot <= 0) return panel(Icons.pie_chart_outline, 'Kiadások kategóriánként', Text('Nincs kiadás ebben a hónapban.', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)));
    final by = <String, double>{};
    for (final t in tx) {
      by[t.cat] = (by[t.cat] ?? 0) + t.amt;
    }
    final ent = by.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final top = ent.take(3).toList();
    final rest = ent.skip(3).fold(0.0, (a, e) => a + e.value);
    final cols = <Color>[for (final e in top) st.catColorById(e.key), if (rest > 0) Colors.blueGrey];
    final vals = <double>[for (final e in top) e.value, if (rest > 0) rest];
    final names = <String>[for (final e in top) (st.catName(e.key).isEmpty ? 'Egyéb' : st.catName(e.key)), if (rest > 0) 'Egyéb'];
    return panel(
        Icons.pie_chart_outline,
        'Kiadások kategóriánként',
        Row(children: [
          SizedBox(
              width: 62,
              height: 62,
              child: Stack(alignment: Alignment.center, children: [
                PieChart(PieChartData(centerSpaceRadius: 19, sectionsSpace: 1, sections: [for (var i = 0; i < vals.length; i++) PieChartSectionData(value: vals[i], color: cols[i], title: '', radius: 9)])),
                m.Text(st.hide ? '••' : fmtK(tot), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800)),
              ])),
          const SizedBox(width: 8),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            for (var i = 0; i < vals.length; i++)
              Padding(
                  padding: const EdgeInsets.symmetric(vertical: 1.5),
                  child: Row(children: [
                    CircleAvatar(radius: 3.5, backgroundColor: cols[i]),
                    const SizedBox(width: 4),
                    Expanded(child: Text(names[i], style: const TextStyle(fontSize: 11), overflow: TextOverflow.ellipsis, maxLines: 1)),
                    m.Text('${(vals[i] / tot * 100).round()}%', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                  ])),
          ])),
        ]));
  }

  List<UpItem> upList() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final lim = today.add(const Duration(days: 14));
    final items = <UpItem>[];
    for (final r in st.rec) {
      if (r.type == 'tr') continue;
      final d = nextDue(r);
      if (!d.isAfter(lim)) items.add(UpItem(d, st.recName(r), r.type != 'in' ? -r.amt : r.amt));
    }
    for (final l in st.loans) {
      final s = st.loanState(l, now);
      if (s.rem <= 0) continue;
      final one = l.pay < s.rem ? l.pay : s.rem;
      if (!s.done) {
        final d = st.loanDue(l, now);
        if (!d.isAfter(lim) || s.curOver) items.add(UpItem(d, trf('Hitel: {0}', [l.name]), -one));
      } else {
        final nx = DateTime(now.year, now.month + 1, 1);
        if (st.ym(nx).compareTo(l.end) <= 0) {
          final nd = st.loanDue(l, nx);
          if (!nd.isAfter(lim)) items.add(UpItem(nd, trf('Hitel: {0}', [l.name]), -one));
        }
      }
    }
    for (final r in st.recvs) {
      if (st.recvRem(r) > 0 && r.due.isNotEmpty) {
        final d = DateTime.parse(r.due);
        if (!d.isAfter(lim)) items.add(UpItem(d, trf('Visszafizetési határidő: {0}', [r.name]), st.recvRem(r)));
      }
    }
    items.sort((a, b) => a.d.compareTo(b.d));
    return items;
  }

  bool upOpen = false;

  final fxCtl = ScrollController();

  Widget fxCarousel(Widget Function(String code) mk) {
    final codes = st.fxCodes;
    if (codes.length < 2) return mk(codes.isEmpty ? st.cur : codes.first);
    final idx = codes.indexOf(st.cur) < 0 ? 0 : codes.indexOf(st.cur);
    final primary = Theme.of(context).colorScheme.primary, hint = Theme.of(context).hintColor;
    return LayoutBuilder(builder: (ctx, cons) {
      final w = cons.maxWidth;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (fxCtl.hasClients && (fxCtl.offset / w).round() != idx) fxCtl.jumpTo(idx * w);
      });
      return Column(children: [
        AnimatedBuilder(
            animation: fxCtl,
            builder: (c, _) {
              var cur = idx;
              if (fxCtl.hasClients) {
                cur = (fxCtl.offset / w).round();
                if (cur < 0) cur = 0;
                if (cur > codes.length - 1) cur = codes.length - 1;
              }
              return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    for (var i = 0; i < codes.length; i++) AnimatedContainer(duration: const Duration(milliseconds: 200), width: i == cur ? 20 : 7, height: 7, margin: const EdgeInsets.symmetric(horizontal: 3), decoration: BoxDecoration(borderRadius: BorderRadius.circular(4), color: i == cur ? primary : hint.withOpacity(0.4))),
                  ]));
            }),
        NotificationListener<ScrollEndNotification>(
            onNotification: (n) {
              if (!fxCtl.hasClients) return false;
              var i = (fxCtl.offset / w).round();
              if (i < 0) i = 0;
              if (i > codes.length - 1) i = codes.length - 1;
              if (codes[i] != st.cur) selectCur(codes[i]);
              return false;
            },
            child: SingleChildScrollView(controller: fxCtl, scrollDirection: Axis.horizontal, physics: const PageScrollPhysics(), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final c in codes) SizedBox(width: w, child: mk(c))]))),
      ]);
    });
  }

  Widget upMini() {
    final it = upList();
    if (it.isEmpty) return panel(Icons.calendar_month_outlined, 'Közelgő fizetések', Text('Nincs közelgő fizetés a következő 14 napban.', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)), onTap: () => setState(() => upOpen = !upOpen));
    final f = it.first;
    return panel(
        Icons.calendar_month_outlined,
        'Közelgő fizetések',
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
                width: 42,
                height: 48,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Theme.of(context).colorScheme.primary.withOpacity(0.14), border: Border.all(color: Theme.of(context).dividerColor)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  m.Text(DateFormat('MMM', st.lang).format(f.d).toUpperCase().replaceAll('.', ''), style: TextStyle(fontSize: 9, fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)),
                  m.Text('${f.d.day}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                ])),
            const SizedBox(width: 8),
            Expanded(child: Text(f.n, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis)),
          ]),
          const SizedBox(height: 6),
          m.Text('${f.a < 0 ? '−' : '+'}${hv(ft(f.a.abs()))}', style: TextStyle(fontWeight: FontWeight.w800, color: f.a < 0 ? cOut : cIn)),
          if (it.length > 1) Text(trf('+{0} további', [it.length - 1]), style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
        ]),
        onTap: () => setState(() => upOpen = !upOpen));
  }

  Widget tipCard() {
    final pm = DateTime(st.month.year, st.month.month - 1);
    Map<String, double> by(int y, int mo) {
      final o = <String, double>{};
      for (final t in st.txs) {
        if (t.type == 'out' && t.xid.isEmpty && t.cat != 'sav' && t.cat != 'loan' && t.date.year == y && t.date.month == mo) o[t.cat] = (o[t.cat] ?? 0) + t.amt;
      }
      return o;
    }

    final a = by(st.month.year, st.month.month), b = by(pm.year, pm.month);
    final tot = a.values.fold(0.0, (x, y) => x + y);
    String? bk;
    var bd = 0.0;
    a.forEach((k, v) {
      final pv = b[k] ?? 0;
      if (pv > 0 && v > 0 && v >= tot * 0.05) {
        final d = (v - pv) / pv;
        if (bk == null || d.abs() > bd.abs()) {
          bk = k;
          bd = d;
        }
      }
    });
    if (bk == null || (bd.abs() * 100).round() < 1) return const SizedBox.shrink();
    final p = (bd.abs() * 100).round();
    final nm = st.catName(bk!).isEmpty ? 'Egyéb' : st.catName(bk!);
    final blue = Theme.of(context).colorScheme.primary;
    return Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [blue.withOpacity(0.24), blue.withOpacity(0.06)]), border: Border.all(color: blue.withOpacity(0.38))),
        child: Row(children: [
          const m.Text('💡', style: TextStyle(fontSize: 26)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Tipp', style: TextStyle(fontWeight: FontWeight.w800)),
            Text(trf(bd < 0 ? 'Az előző hónaphoz képest {0}%-kal kevesebbet költöttél a(z) {1} kategóriában.' : 'Az előző hónaphoz képest {0}%-kal többet költöttél a(z) {1} kategóriában.', [p, nm]), style: const TextStyle(fontSize: 13.5)),
          ])),
        ]));
  }

  Widget txIcon(Tx t) {
    final col = st.colorFor(t) ?? (t.acc == 'cash' ? cCash : cCard);
    final n = t.type == 'in' ? st.icName(t.cat) : st.catName(t.cat);
    final s0 = t.xid.isNotEmpty ? '⇄' : (n.isEmpty ? st.title(t) : n).trim();
    final ch = s0.isEmpty ? '?' : String.fromCharCode(s0.runes.first).toUpperCase();
    return Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(color: col.withOpacity(0.22), borderRadius: BorderRadius.circular(12)),
        alignment: Alignment.center,
        child: m.Text(ch, style: TextStyle(color: Color.lerp(col, Theme.of(context).colorScheme.onSurface, 0.28), fontWeight: FontWeight.w800, fontSize: 17)));
  }

  void addChooser() => showModalBottomSheet<void>(
      context: context,
      builder: (d) => SafeArea(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
                leading: const Icon(Icons.trending_down),
                title: const Text('Új kiadás'),
                onTap: () {
                  Navigator.pop(d);
                  openSheet(date: tab == 4 ? sel : null, newType: 'out', lock: false);
                }),
            ListTile(
                leading: const Icon(Icons.trending_up),
                title: const Text('Új bevétel'),
                onTap: () {
                  Navigator.pop(d);
                  openSheet(date: tab == 4 ? sel : null, newType: 'in', lock: false);
                }),
            ListTile(
                leading: const Icon(Icons.swap_horiz),
                title: const Text('Számlák közötti átvezetés'),
                onTap: () {
                  Navigator.pop(d);
                  openSheet(date: tab == 4 ? sel : null, newType: 'tr', lock: false);
                }),
            if (st.voiceOn)
              ListTile(
                leading: const Icon(Icons.mic_none),
                title: const Text('Hangos rögzítés'),
                onTap: () async {
                  Navigator.pop(d);
                  final r = await listenVoice();
                  if (r == null || !mounted) return;
                  final p = parseVoice(r, st.cats, st.icats);
                  openSheet(date: tab == 4 ? sel : null, newType: p.type, lock: false, pre: p);
                }),
            if (st.scanOn)
              ListTile(
                leading: const Icon(Icons.receipt_long_outlined),
                title: const Text('Nyugta fotózása'),
                onTap: () {
                  Navigator.pop(d);
                  scanReceipt(ImageSource.camera);
                }),
            if (st.scanOn)
              ListTile(
                leading: const Icon(Icons.photo_library_outlined),
                title: const Text('Nyugta a galériából'),
                onTap: () {
                  Navigator.pop(d);
                  scanReceipt(ImageSource.gallery);
                }),
            if (st.scanOn)
              ListTile(
                leading: const Icon(Icons.content_paste),
                title: const Text('Nyugta szövegének beillesztése'),
                onTap: () {
                  Navigator.pop(d);
                  receiptPaste('', null);
                }),
          ])));

  Future<void> pickMonth() async {
    var y = st.month.year;
    await showDialog<void>(
        context: context,
        builder: (d) => StatefulBuilder(
            builder: (d, setD) => AlertDialog(
                  title: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    IconButton(icon: const Icon(Icons.chevron_left), onPressed: () => setD(() => y--)),
                    m.Text('$y'),
                    IconButton(icon: const Icon(Icons.chevron_right), onPressed: () => setD(() => y++)),
                  ]),
                  content: Wrap(spacing: 8, runSpacing: 8, children: [
                    for (var i = 1; i <= 12; i++)
                      ChoiceChip(
                          label: m.Text(DateFormat('MMM', st.lang).format(DateTime(2000, i))),
                          selected: y == st.month.year && i == st.month.month,
                          onSelected: (_) {
                            Navigator.pop(d);
                            final mm = DateTime(y, i);
                            sel = DateTime(mm.year, mm.month, 1);
                            st.change(() => st.month = mm);
                          }),
                  ]),
                  actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse'))],
                )));
  }

  bool fxPick = false;

  Widget wsBar() {
    if (!st.fxOn) return const SizedBox.shrink();
    final empty = st.ws == 'fx' && st.cur.isEmpty;
    final showPick = st.ws == 'fx' && (empty || fxPick);
    final onHome = tab == 0 || empty;
    final pill = st.ws == 'fx' && st.fxCodes.length > 1 && !onHome;
    if (!onHome && !pill) return const SizedBox.shrink();
    return Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          if (onHome)
            SegmentedButton<String>(
              emptySelectionAllowed: true,
              segments: [
                const ButtonSegment(value: 'huf', label: Text('Forint')),
                ButtonSegment(value: 'fx', label: (st.ws == 'fx' && st.cur.isNotEmpty) ? m.Text('${tr('Deviza')} · ${st.cur}') : const Text('Deviza')),
              ],
              selected: {st.ws},
              onSelectionChanged: (v) async {
                if (v.isEmpty) {
                  if (st.ws == 'fx' && st.fxCodes.length > 1) setState(() => fxPick = !fxPick);
                  return;
                }
                final tapped = v.first;
                if (tapped == st.ws) return;
                fxPick = false;
                await st.switchTo(tapped);
                if (!mounted) return;
                setState(() {
                  tab = 0;
                  selMode = false;
                  selIds = {};
                  dv = false;
                });
                await rescheduleAll();
              }),
          if (onHome && showPick)
            Padding(
                padding: const EdgeInsets.only(top: 8),
                child: DropdownButtonFormField<String>(
                  key: ValueKey('${st.ws}|${st.cur}|${st.fxCodes.length}|$fxPick'),
                  value: null,
                  isExpanded: true,
                  decoration: InputDecoration(labelText: tr('Deviza'), isDense: true, border: const OutlineInputBorder()),
                  hint: Text(empty ? 'Válassz devizát…' : 'Deviza váltása…'),
                  items: empty
                      ? [
                          for (final p in popCur) DropdownMenuItem(value: 'add:${p[0]}', child: m.Text('${p[0]} · ${tr(p[1])}', overflow: TextOverflow.ellipsis)),
                          const DropdownMenuItem(value: 'custom', child: Text('+ Egyéb deviza…')),
                        ]
                      : [for (final c in st.fxCodes) DropdownMenuItem(value: 'cur:$c', child: m.Text(curLabel(c), overflow: TextOverflow.ellipsis))],
                  onChanged: (v) {
                    if (v == null) return;
                    setState(() => fxPick = false);
                    if (v.startsWith('cur:')) {
                      selectCur(v.substring(4));
                    } else if (v.startsWith('add:')) {
                      addCur(v.substring(4));
                    } else if (v == 'custom') {
                      addCurrencyDialog();
                    }
                  },
                )),
          if (pill)
            Align(
                alignment: Alignment.centerRight,
                child: Container(
                    margin: const EdgeInsets.only(top: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.outline), borderRadius: BorderRadius.circular(24)),
                    child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                            value: st.fxCodes.contains(st.cur) ? st.cur : null,
                            isDense: true,
                            items: [for (final c in st.fxCodes) DropdownMenuItem(value: c, child: m.Text(c, style: const TextStyle(fontWeight: FontWeight.w700)))],
                            onChanged: (v) async {
                              if (v == null || v == st.cur) return;
                              await st.switchTo('fx', v);
                              if (!mounted) return;
                              setState(() {
                                selMode = false;
                                selIds = {};
                              });
                            })))),
        ]));
  }

  String curLabel(String c) {
    final p = popCur.where((x) => x[0] == c);
    return p.isEmpty ? c : '$c · ${tr(p.first[1])}';
  }

  void confirmDelCur(String code) => ask(trf('Biztosan törlöd a(z) {0} devizaszámlát? A hozzá tartozó összes adat törlődik.', [code]), () async {
        await st.deleteCurrency(code);
        if (!mounted) return;
        setState(() {
          tab = 0;
          selMode = false;
          selIds = {};
          fxPick = false;
        });
      });

  Future<void> addCur(String code) async {
    await st.addCurrency(code);
    if (!mounted) return;
    setState(() {
      tab = 0;
      selMode = false;
      selIds = {};
    });
    if (!st.initDone && mounted) await initDialog();
  }

  Widget fxPicker(void Function(String) onPick) => Wrap(spacing: 8, children: [
        for (final p in popCur)
          if (!st.fxCodes.contains(p[0])) ActionChip(label: m.Text('${p[0]} · ${tr(p[1])}'), onPressed: () => onPick(p[0])),
      ]);

  Widget fxStart() => Padding(
      padding: const EdgeInsets.only(top: 16),
      child: const Text('Válaszd ki a devizát a fenti menüből. A devizaszámla teljesen független a forint számlától, később az oldalsó menüben további devizát adhatsz hozzá.'));

  Future<void> addCurrencyDialog() async {
    final code = TextEditingController();
    var sel = '';
    String? err;
    final rest = popCur.where((p) => !st.fxCodes.contains(p[0])).toList();
    await showDialog<void>(
        context: context,
        builder: (d0) => StatefulBuilder(
            builder: (d0, setD) => AlertDialog(
                  title: const Text('Deviza hozzáadása'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    DropdownButtonFormField<String>(
                      value: sel.isEmpty ? null : sel,
                      isExpanded: true,
                      decoration: InputDecoration(labelText: tr('Deviza')),
                      hint: const Text('Válassz devizát…'),
                      items: [for (final p in rest) DropdownMenuItem(value: p[0], child: m.Text('${p[0]} · ${tr(p[1])}', overflow: TextOverflow.ellipsis))],
                      onChanged: (v) => setD(() => sel = v ?? ''),
                    ),
                    TextField(controller: code, maxLength: 3, textCapitalization: TextCapitalization.characters, decoration: InputDecoration(labelText: tr('Egyéb deviza kódja (3 betű)'))),
                    if (err != null) Text(err!, style: const TextStyle(color: cOut)),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d0), child: const Text('Mégse')),
                    FilledButton(
                        onPressed: () {
                          final c = sel.isNotEmpty ? sel : code.text.trim().toUpperCase();
                          if (!RegExp(r'^[A-Z]{3}$').hasMatch(c) || c == 'HUF') {
                            setD(() => err = tr('Add meg a deviza 3 betűs kódját (pl. EUR).'));
                            return;
                          }
                          Navigator.pop(d0);
                          addCur(c);
                        },
                        child: const Text('Hozzáadás')),
                  ],
                )));
  }

  Future<void> xchDialog() async {
    if (!st.fxOn || st.fxCodes.isEmpty) {
      snack('Előbb vegyél fel egy devizaszámlát (Deviza gomb).');
      return;
    }
    var dir = 'h2f';
    var code = (st.ws == 'fx' && st.cur.isNotEmpty) ? st.cur : st.fxCodes.first;
    var src = 'cash', dst = 'card';
    var d = DateTime.now();
    final amt = TextEditingController(), rate = TextEditingController(), note = TextEditingController();
    String? err;
    double pv(String s) => double.tryParse(s.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
    await showDialog<void>(
        context: context,
        builder: (d0) => StatefulBuilder(builder: (d0, setD) {
              double calc() {
                final a = pv(amt.text), r = pv(rate.text);
                if (a <= 0 || r <= 0) return 0;
                return dir == 'h2f' ? r2c(a / r, code) : r2c(a * r, 'HUF');
              }

              final got = calc();
              final sc = dir == 'h2f' ? 'HUF' : code, dc = dir == 'h2f' ? code : 'HUF';
              return AlertDialog(
                title: const Text('Pénzváltás'),
                content: SingleChildScrollView(
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SegmentedButton<String>(segments: const [ButtonSegment(value: 'h2f', label: Text('Forint → Deviza')), ButtonSegment(value: 'f2h', label: Text('Deviza → Forint'))], selected: {dir}, onSelectionChanged: (s) => setD(() => dir = s.first)),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<String>(
                      value: code,
                      isExpanded: true,
                      decoration: InputDecoration(labelText: tr('Deviza')),
                      items: [for (final c in st.fxCodes) DropdownMenuItem(value: c, child: m.Text(curLabel(c), overflow: TextOverflow.ellipsis))],
                      onChanged: (v) => setD(() => code = v ?? code)),
                  const SizedBox(height: 8),
                  const Text('Honnan', style: TextStyle(fontSize: 12)),
                  SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {src}, onSelectionChanged: (s) => setD(() => src = s.first)),
                  const SizedBox(height: 8),
                  const Text('Hová', style: TextStyle(fontSize: 12)),
                  SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {dst}, onSelectionChanged: (s) => setD(() => dst = s.first)),
                  TextField(controller: amt, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setD(() {}), decoration: InputDecoration(labelText: trf('Összeg ({0})', [sc == 'HUF' ? 'Ft' : sc]))),
                  TextField(controller: rate, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setD(() {}), decoration: InputDecoration(labelText: trf('Árfolyam (1 {0} = … Ft)', [code]))),
                  if (got > 0) Padding(padding: const EdgeInsets.only(top: 8), child: Text(trf('Megkapod: {0}', [ftc(got, dc)]), style: const TextStyle(fontWeight: FontWeight.w700))),
                  TextButton.icon(
                      onPressed: () async {
                        final x = await showDatePicker(context: d0, initialDate: d, firstDate: DateTime(2000), lastDate: DateTime(2100));
                        if (x != null) setD(() => d = x);
                      },
                      icon: const Icon(Icons.event),
                      label: m.Text(dfm('yyyy. MMMM d.', d))),
                  TextField(controller: note, decoration: InputDecoration(labelText: tr('Megjegyzés'))),
                  if (err != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err!, style: const TextStyle(color: cOut))),
                ])),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(d0), child: const Text('Mégse')),
                  FilledButton(
                      onPressed: () async {
                        final a = pv(amt.text), r = pv(rate.text), g = calc();
                        if (a <= 0 || r <= 0 || g <= 0) {
                          setD(() => err = tr('Add meg az összeget és az árfolyamot.'));
                          return;
                        }
                        Navigator.pop(d0);
                        final srcKey = dir == 'h2f' ? 'kv1' : 'fx_$code';
                        final av = await st.balOfKey(srcKey, src);
                        Future<void> go() async {
                          final id = await st.exchange(dir: dir, code: code, src: src, dst: dst, amt: a, rate: r, got: g, date: d, note: note.text.trim());
                          snackUndo(trf('Átváltás rögzítve: {0} → {1}', [ftc(a, sc), ftc(g, dc)]), () => st.deleteXch(id));
                        }

                        if (av < a) {
                          ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a tétel összege {2}. Biztosan rögzíted?', [accName(src), ftc(av < 0 ? 0 : av, sc), ftc(a, sc)]), () {
                            go();
                          });
                        } else {
                          await go();
                        }
                      },
                      child: const Text('Átváltás')),
                ],
              );
            }));
  }

  Widget home() {
    final pmD = DateTime(st.month.year, st.month.month - 1);
    double sm(List<Tx> l, String ty, int y, int mo) => l.where((t) => t.type == ty && t.date.year == y && t.date.month == mo).fold(0.0, (a, t) => a + t.amt);
    Widget block(String code, List<Tx> txs, double c, double b, double rv, {VoidCallback? onTap, VoidCallback? onDelete, bool dim = false}) {
      final inc = sm(txs, 'in', st.month.year, st.month.month), out = sm(txs, 'out', st.month.year, st.month.month);
      final pi = sm(txs, 'in', pmD.year, pmD.month), po = sm(txs, 'out', pmD.year, pmD.month);
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        heroCard(code, c, b, rv, inc: inc, onTap: onTap, onDelete: onDelete, dim: dim),
        Padding(padding: const EdgeInsets.only(bottom: 14), child: Row(children: [Expanded(child: tile2('Havi kiadás', out, po, cOut, true, code)), const SizedBox(width: 12), Expanded(child: tile2('Havi bevétel', inc, pi, cIn, false, code))])),
      ]);
    }

    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      ...(st.ws == 'fx'
          ? [
              fxCarousel((code) => block(code, code == st.cur ? st.txs : (st.fxTxs[code] ?? <Tx>[]), code == st.cur ? st.bal('cash') : (st.fxSum[code] ?? [0.0, 0.0, 0.0])[0], code == st.cur ? st.bal('card') : (st.fxSum[code] ?? [0.0, 0.0, 0.0])[1],
                  code == st.cur ? st.recvSum() : (st.fxSum[code] ?? [0.0, 0.0, 0.0])[2],
                  onDelete: () => confirmDelCur(code))),
            ]
          : [block('HUF', st.txs, st.bal('cash'), st.bal('card'), st.recvSum())]),
      if (st.txs.isEmpty) startCard(),
      rptCard(),
      recSugCard(),
      forecastCard(),
      Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 6, child: donutCard()), const SizedBox(width: 12), Expanded(flex: 5, child: upMini())]),
      if (upOpen) upcomingCard(),
      tipCard(),
      tplRow(),
      quickRow(),
      bkNotice(),
      loanHome(),
      recvHome(),
      sgSummary(),
      recSection(),
    ]);
  }

  String fmtMonth(String ym) {
    final p = ym.split('-');
    return dfm('yyyy. MMMM', DateTime(int.parse(p[0]), int.parse(p[1])));
  }

  Widget overdueBanner() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final o = st.overdueLoans(now), q = st.overdueRecvs(now);
    if (o.isEmpty && q.isEmpty) return const SizedBox.shrink();
    Widget line(String msg, int target) => InkWell(
        onTap: () => setState(() => tab = target),
        child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 20),
              const SizedBox(width: 8),
              Expanded(child: Text(msg, style: const TextStyle(color: Colors.white, fontSize: 14))),
            ])));
    String loanMsg(Loan l) {
      final s = st.loanState(l, now);
      final n = s.missed.length + (s.curOver ? 1 : 0);
      if (n == 1 && s.curOver) return trf('Elmaradt a(z) {0} törlesztése: {1}, {2} napja volt esedékes.', [l.name, ft(l.pay), -s.d]);
      return trf('Elmaradt a(z) {0} törlesztése {1} hónapra: {2}.', [l.name, n, ft(n * l.pay)]);
    }

    return Material(
        color: const Color(0xFFC62828),
        child: Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (final l in o) line(loanMsg(l), 10),
              for (final r in q) line(trf('Lejárt a visszafizetési határidő: {0} tartozása ({1}), {2} napja.', [r.name, ft(st.recvRem(r)), daysBetween(DateTime.parse(r.due), today)]), 11),
            ])));
  }

  Widget payRow(Tx t, String undoMsg) => Padding(
      padding: const EdgeInsets.only(top: 2),
      child: Wrap(spacing: 10, crossAxisAlignment: WrapCrossAlignment.center, children: [
        Text(dfm('yyyy. MM. dd.', t.date)),
        Text(ft(t.amt), style: const TextStyle(fontWeight: FontWeight.w600)),
        Text(accName(t.acc)),
        TextButton(
            style: TextButton.styleFrom(visualDensity: VisualDensity.compact),
            onPressed: () => ask(undoMsg, () {
                  st.change(() => st.txs.removeWhere((x) => x.id == t.id));
                  rescheduleAll();
                }),
            child: const Text('Visszavonás')),
      ]));

  Widget bkNotice() {
    final now = DateTime.now();
    final today = st.ymd(now);
    if (st.txs.isEmpty && st.recvs.isEmpty && st.loans.isEmpty && st.sg.isEmpty) return const SizedBox.shrink();
    if (st.bkSnooze.compareTo(today) > 0) return const SizedBox.shrink();
    final has = st.lastBackup.isNotEmpty;
    final base = has ? st.lastBackup : (st.firstUse.isEmpty ? today : st.firstUse);
    final days = daysBetween(DateTime.parse(base), now);
    if (has ? days < 30 : days < 7) return const SizedBox.shrink();
    return Card(
        child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Mentés ajánlott', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(has ? trf('Utolsó mentés: {0} napja.', [days]) : tr('Még nem készítettél mentést.')),
              const Text('Az adataid csak ezen a készüléken vannak, készíts mentést.'),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                FilledButton(onPressed: () => setState(() => tab = 6), child: const Text('Mentés készítése')),
                TextButton(onPressed: () => st.snoozeBackup(), child: const Text('Később')),
              ]),
            ])));
  }

  Widget upcomingCard() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final end = DateTime(now.year, now.month + 1, 0);
    final lim = today.add(const Duration(days: 14));
    final items = <UpItem>[];
    var ob = 0.0;
    for (final r in st.rec) {
      if (r.type == 'tr') continue;
      final d = nextDue(r);
      final out = r.type != 'in';
      if (!d.isAfter(lim)) items.add(UpItem(d, st.recName(r), out ? -r.amt : r.amt));
      if (out && !d.isAfter(end)) ob += r.amt;
    }
    for (final l in st.loans) {
      final s = st.loanState(l, now);
      if (s.rem <= 0) continue;
      final cap = s.rem;
      final one = l.pay < cap ? l.pay : cap;
      if (!s.done) {
        final d = st.loanDue(l, now);
        if (!d.isAfter(lim) || s.curOver) items.add(UpItem(d, trf('Hitel: {0}', [l.name]), -one));
        ob += one;
      } else {
        final nx = DateTime(now.year, now.month + 1, 1);
        if (st.ym(nx).compareTo(l.end) <= 0) {
          final nd = st.loanDue(l, nx);
          if (!nd.isAfter(lim)) items.add(UpItem(nd, trf('Hitel: {0}', [l.name]), -one));
        }
      }
      ob += s.missed.length * l.pay;
    }
    for (final r in st.recvs) {
      if (st.recvRem(r) > 0 && r.due.isNotEmpty) {
        final d = DateTime.parse(r.due);
        if (!d.isAfter(lim)) items.add(UpItem(d, trf('Visszafizetési határidő: {0}', [r.name]), st.recvRem(r)));
      }
    }
    if (items.isEmpty && ob <= 0) return const SizedBox.shrink();
    items.sort((a, b) => a.d.compareTo(b.d));
    final total = st.bal('cash') + st.bal('card');
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Közelgő fizetések', style: Theme.of(context).textTheme.titleMedium)),
      Card(
          child: Column(children: [
        for (final x in items) ListTile(dense: true, title: Text(x.n), subtitle: Text(dfm('yyyy. MMMM d.', x.d)), trailing: Text('${x.a < 0 ? '−' : '+'}${ft(x.a.abs())}', style: TextStyle(fontWeight: FontWeight.w700, color: x.a < 0 ? cOut : cIn))),
      ])),
      if (ob > 0)
        Padding(
            padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(trf('Várható kötelezettségek a hónap végéig: {0}', [ft(ob)])),
              Text(trf('Becsült összes pénz a hónap végén: {0}', [ft(total - ob)]), style: const TextStyle(fontWeight: FontWeight.w700)),
              const Text('A kintlévőségek visszafizetése nincs beleszámítva.', style: TextStyle(fontSize: 12)),
            ])),
    ]);
  }

  Widget recvCard(Recv r, {bool full = false}) {
    final now = DateTime.now();
    final rem = st.recvRem(r), dd = st.recvDays(r, now);
    String status;
    var good = false, bad = false;
    if (r.closed) {
      status = tr('Lezárva');
    } else if (rem <= 0) {
      status = tr('Visszafizetve');
      good = true;
    } else if (dd == null) {
      status = tr('Nincs határidő megadva');
    } else if (dd < 0) {
      status = trf('Lejárt a határidő: {0} napja', [-dd]);
      bad = true;
    } else if (dd == 0) {
      status = tr('Ma esedékes');
      bad = true;
    } else if (dd <= 3) {
      status = trf('Hamarosan esedékes: {0}', [dfm('yyyy. MMMM d.', DateTime.parse(r.due))]);
      bad = true;
    } else {
      status = trf('Határidő: {0}', [dfm('yyyy. MMMM d.', DateTime.parse(r.due))]);
    }
    final Color? tint = good ? cIn : (bad ? cOut : null);
    final pct = r.total <= 0 ? 0.0 : ((r.total - rem) / r.total).clamp(0.0, 1.0);
    final pays = full ? (st.txs.where((t) => t.rc == r.id && t.type == 'back').toList()..sort((a, b) => b.date.compareTo(a.date))).take(8).toList() : <Tx>[];
    return Card(
        clipBehavior: Clip.antiAlias,
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(border: Border(left: BorderSide(color: tint ?? Theme.of(context).colorScheme.outline, width: 6))),
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(r.name, style: Theme.of(context).textTheme.titleSmall)),
              if (full) ...[
                IconButton(icon: const Icon(Icons.edit_outlined), tooltip: tr('Szerkesztés'), onPressed: () => recvDialog(r)),
                IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => ask(trf('Biztosan törlöd a(z) {0} kintlévőséget? A hozzá tartozó mozgások is törlődnek, a számlák egyenlege visszaáll.', [r.name]), () {
                          st.change(() {
                            st.recvs.remove(r);
                            st.txs.removeWhere((t) => t.rc == r.id);
                          });
                          rescheduleAll();
                        })),
              ],
            ]),
            Text.rich(TextSpan(text: ft(rem), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: tint), children: [TextSpan(text: '  /  ${ft(r.total)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400))])),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: pct, minHeight: 8, borderRadius: BorderRadius.circular(4)),
            const SizedBox(height: 8),
            Text(status, style: TextStyle(fontWeight: FontWeight.w600, color: tint)),
            if (r.inst > 0 && rem > 0) Text(trf('Havi részlet: {0}', [ft(r.inst)])),
            if (full) Text(trf('Kölcsönadva: {0}', [dfm('yyyy. MMMM d.', DateTime.parse(r.date))])),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              if (rem > 0) FilledButton(onPressed: () => backDialog(r), child: const Text('Visszakaptam')),
              if (full && rem > 0)
                TextButton(
                    onPressed: () => ask(trf('Biztosan lezárod a(z) {0} kintlévőséget? A hátralévő összeg nem számít többé kintlévőségnek, pénzmozgás nem történik.', [r.name]), () {
                          st.change(() => r.closed = true);
                          rescheduleAll();
                        }),
                    child: const Text('Lezárás')),
            ]),
            if (pays.isNotEmpty) ...[
              const SizedBox(height: 10),
              const Text('Befizetések', style: TextStyle(fontWeight: FontWeight.w600)),
              for (final t in pays) payRow(t, 'Biztosan visszavonod ezt a visszatérítést? A pénz kikerül az egyenlegedből, a kintlévőség újra nő.'),
            ],
          ]),
        ));
  }

  Widget recvHome() {
    final act = st.recvs.where((r) => st.recvRem(r) > 0).toList();
    if (act.isEmpty) return const SizedBox();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Kintlévőség', style: Theme.of(context).textTheme.titleMedium)),
      for (final r in act) recvCard(r),
    ]);
  }

  Widget recvPage() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (st.recvs.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Még nincs kintlévőség.'))),
        for (final r in st.recvs) recvCard(r, full: true),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => recvDialog(), icon: const Icon(Icons.add), label: const Text('Új kintlévőség')),
      ]);

  Future<void> recvDialog([Recv? e]) async {
    final n = TextEditingController(text: e?.name ?? '');
    final t = TextEditingController();
    final inst = TextEditingController(text: (e == null || e.inst <= 0) ? '' : amtStr(e.inst));
    var acc = 'cash';
    var lent = DateTime.now();
    DateTime? due = (e == null || e.due.isEmpty) ? null : DateTime.parse(e.due);
    String? err;
    await showDialog<void>(
        context: context,
        builder: (d0) => StatefulBuilder(
            builder: (d0, setD) => AlertDialog(
                  title: Text(e == null ? 'Új kintlévőség' : 'Kintlévőség szerkesztése'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    TextField(controller: n, decoration: InputDecoration(labelText: tr('Kinek adtad kölcsön?'), hintText: tr('Pl. Péter'))),
                    if (e == null) ...[
                      TextField(controller: t, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Kölcsönadott összeg'), suffixText: st.csym)),
                      const SizedBox(height: 12),
                      const Text('Honnan adtad?', style: TextStyle(fontSize: 12)),
                      SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {acc}, onSelectionChanged: (s) => setD(() => acc = s.first)),
                      TextButton.icon(
                          onPressed: () async {
                            final x = await showDatePicker(context: d0, initialDate: lent, firstDate: DateTime(2000), lastDate: DateTime(2100), helpText: tr('Kölcsönadás dátuma'));
                            if (x != null) setD(() => lent = x);
                          },
                          icon: const Icon(Icons.event),
                          label: Text(trf('Kölcsönadva: {0}', [dfm('yyyy. MMMM d.', lent)]))),
                    ],
                    TextButton.icon(
                        onPressed: () async {
                          final x = await showDatePicker(context: d0, initialDate: due ?? DateTime.now().add(const Duration(days: 30)), firstDate: DateTime(2000), lastDate: DateTime(2100), helpText: tr('Visszafizetési határidő'));
                          if (x != null) setD(() => due = x);
                        },
                        icon: const Icon(Icons.event_available),
                        label: Text(due == null ? 'Visszafizetési határidő (nem kötelező)' : trf('Visszafizetési határidő: {0}', [dfm('yyyy. MMMM d.', due!)]))),
                    if (due != null) TextButton(onPressed: () => setD(() => due = null), child: const Text('Határidő törlése')),
                    TextField(controller: inst, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Havi részlet (nem kötelező)'), suffixText: st.csym)),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err!, style: const TextStyle(color: cOut))),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d0), child: const Text('Mégse')),
                    FilledButton(
                        onPressed: () {
                          final name = n.text.trim();
                          final dueS = due == null ? '' : st.ymd(due!);
                          final ins = double.tryParse(inst.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
                          if (e != null) {
                            if (name.isEmpty) {
                              setD(() => err = tr('Add meg az összes mezőt helyesen.'));
                              return;
                            }
                            st.change(() {
                              e.name = name;
                              e.due = dueS;
                              e.inst = ins;
                            });
                            Navigator.pop(d0);
                            rescheduleAll();
                            return;
                          }
                          final amt = double.tryParse(t.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
                          if (name.isEmpty || amt <= 0) {
                            setD(() => err = tr('Add meg az összes mezőt helyesen.'));
                            return;
                          }
                          void go() {
                            final id = uid();
                            st.change(() {
                              st.recvs.add(Recv(id, name, amt, st.ymd(lent), dueS, false, ins));
                              st.txs.add(Tx(id: uid(), type: 'lend', acc: acc, cat: '', item: '', amt: amt, date: lent, note: '', rc: id));
                            });
                            rescheduleAll();
                          }

                          Navigator.pop(d0);
                          final av = st.bal(acc);
                          if (av < amt) {
                            ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a kölcsön összege {2}. Biztosan rögzíted?', [accName(acc), ft(av < 0 ? 0 : av), ft(amt)]), go);
                          } else {
                            go();
                          }
                        },
                        child: const Text('Mentés')),
                  ],
                )));
  }

  Future<void> backDialog(Recv r) async {
    final rem = st.recvRem(r);
    final first = (r.inst > 0 && r.inst < rem) ? r.inst : rem;
    final a = TextEditingController(text: amtStr(first));
    var acc = 'cash';
    await showDialog<void>(
        context: context,
        builder: (d0) => StatefulBuilder(
            builder: (d0, setD) => AlertDialog(
                  title: Text(trf('Visszatérítés: {0}', [r.name])),
                  content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Hova érkezett?', style: TextStyle(fontSize: 12)),
                    SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {acc}, onSelectionChanged: (s) => setD(() => acc = s.first)),
                    const SizedBox(height: 12),
                    TextField(controller: a, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Összeg'), suffixText: st.csym)),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d0), child: const Text('Mégse')),
                    FilledButton(
                        onPressed: () {
                          final v = double.tryParse(a.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
                          if (v <= 0) return;
                          final amt = v > rem ? rem : v;
                          Navigator.pop(d0);
                          st.change(() => st.txs.add(Tx(id: uid(), type: 'back', acc: acc, cat: '', item: '', amt: amt, date: DateTime.now(), note: '', rc: r.id)));
                          rescheduleAll();
                        },
                        child: const Text('Visszatérítés rögzítése')),
                  ],
                )));
  }

  Widget loanCard(Loan l, {bool full = false}) {
    final now = DateTime.now();
    final s = st.loanState(l, now);
    final rem = s.rem, off = rem <= 0, diff = s.d, due = st.loanDue(l, now);
    final n = s.missed.length + (s.curOver ? 1 : 0);
    String status;
    var good = false, bad = false;
    if (off) {
      status = tr('Kifizetve');
      good = true;
    } else if (s.missed.isNotEmpty) {
      status = trf('Hátralék: {0} hónap ({1})', [n, ft(n * l.pay)]);
      bad = true;
    } else if (s.done) {
      status = tr('Ebben a hónapban befizetve ✓');
      good = true;
    } else if (diff < 0) {
      status = trf('Késik: {0} napja esedékes', [-diff]);
      bad = true;
    } else if (diff == 0) {
      status = tr('Ma esedékes');
      bad = true;
    } else if (diff <= 3) {
      status = trf('Hamarosan esedékes: {0}', [dfm('yyyy. MMMM d.', due)]);
      bad = true;
    } else {
      status = trf('Következő törlesztés: {0}', [dfm('yyyy. MMMM d.', due)]);
    }
    final Color? tint = good ? cIn : (bad ? cOut : null);
    final pct = l.total <= 0 ? 0.0 : ((l.total - rem) / l.total).clamp(0.0, 1.0);
    final unpaid = s.missed.length + (s.done ? 0 : 1);
    final pays = full ? st.loanPays(l).reversed.take(8).toList() : <Tx>[];
    return Card(
        clipBehavior: Clip.antiAlias,
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration(border: Border(left: BorderSide(color: tint ?? Theme.of(context).colorScheme.outline, width: 6))),
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text(l.name, style: Theme.of(context).textTheme.titleSmall)),
              if (full) ...[
                IconButton(icon: const Icon(Icons.edit_outlined), tooltip: tr('Szerkesztés'), onPressed: () => loanDialog(l)),
                IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => ask(trf('Biztosan törlöd a(z) {0} hitelt? A korábbi befizetések a kiadások között maradnak.', [l.name]), () {
                          st.change(() => st.loans.remove(l));
                          rescheduleAll();
                        })),
              ],
            ]),
            Text.rich(TextSpan(text: ft(rem), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: tint), children: [TextSpan(text: '  /  ${ft(l.total)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400))])),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: pct, minHeight: 8, borderRadius: BorderRadius.circular(4)),
            const SizedBox(height: 8),
            Text(trf('Havi törlesztőrészlet: {0}', [ft(l.pay)])),
            Text(status, style: TextStyle(fontWeight: FontWeight.w600, color: tint)),
            if (full) ...[
              Text(trf('Esedékesség: minden hónap {0}. napján', [l.day])),
              Text(trf('Lejárat: {0}, hátralévő hónapok: {1}', [fmtMonth(l.end), st.loanMonthsLeft(l, now)])),
            ],
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              if (!off && unpaid > 0) FilledButton(onPressed: () => payLoanDialog(l), child: const Text('Befizettem')),
            ]),
            if (pays.isNotEmpty) ...[
              const SizedBox(height: 10),
              const Text('Befizetések', style: TextStyle(fontWeight: FontWeight.w600)),
              for (final t in pays) payRow(t, 'Biztosan visszavonod ezt a befizetést? A pénz visszakerül az egyenlegedre.'),
            ],
          ]),
        ));
  }

  Widget loanHome() {
    final act = st.loans.where((l) => st.loanRem(l) > 0).toList();
    if (act.isEmpty) return const SizedBox();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Hitel', style: Theme.of(context).textTheme.titleMedium)),
      for (final l in act) loanCard(l),
    ]);
  }

  Widget loanPage() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (st.loans.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Még nincs hitel felvéve.'))),
        for (final l in st.loans) loanCard(l, full: true),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => loanDialog(), icon: const Icon(Icons.add), label: const Text('Új hitel')),
      ]);

  Future<void> loanDialog([Loan? e]) async {
    var kind = e?.name ?? lnTypes.first;
    final kinds = [if (!lnTypes.contains(kind)) kind, ...lnTypes];
    final t = TextEditingController(text: e == null ? '' : amtStr(e.total));
    final p = TextEditingController(text: e == null ? '' : amtStr(e.pay));
    DateTime? dueDay;
    if (e != null) {
      final nw = DateTime.now();
      final dim = DateUtils.getDaysInMonth(nw.year, nw.month);
      dueDay = DateTime(nw.year, nw.month, e.day < dim ? e.day : dim);
    }
    var end = e?.end ?? '';
    String? err;
    await showDialog<void>(
        context: context,
        builder: (d0) => StatefulBuilder(
            builder: (d0, setD) => AlertDialog(
                  title: Text(e == null ? 'Új hitel' : 'Hitel szerkesztése'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    DropdownButtonFormField<String>(
                        value: kind,
                        isExpanded: true,
                        decoration: InputDecoration(labelText: tr('Hitel típusa')),
                        items: [for (final k in kinds) DropdownMenuItem(value: k, child: Text(k, overflow: TextOverflow.ellipsis))],
                        onChanged: (v) => setD(() => kind = v ?? kind)),
                    TextField(controller: t, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Hitel összege'), suffixText: st.csym, helperText: tr('A hátralévő tartozás a befizetésekkel csökken.'), helperMaxLines: 2)),
                    TextField(controller: p, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Havi törlesztőrészlet'), suffixText: st.csym)),
                    const SizedBox(height: 8),
                    TextButton.icon(
                        onPressed: () async {
                          final x = await showDatePicker(context: d0, initialDate: dueDay ?? DateTime.now(), firstDate: DateTime(2000), lastDate: DateTime(2100), helpText: tr('Törlesztés napja'));
                          if (x != null) setD(() => dueDay = x);
                        },
                        icon: const Icon(Icons.event_available),
                        label: Text(dueDay == null ? 'Törlesztés napja' : trf('Törlesztés napja: {0}', [dfm('yyyy. MMMM d.', dueDay!)]))),
                    const Text('A hiteltörlesztő esedékességének napja. A naptárban válaszd ki ezt a napot, minden hónapban erre a napra esik majd a törlesztés.', style: TextStyle(fontSize: 12)),
                    TextButton.icon(
                        onPressed: () async {
                          final init = end.isEmpty ? DateTime.now().add(const Duration(days: 365)) : DateTime(int.parse(end.split('-')[0]), int.parse(end.split('-')[1]));
                          final x = await showDatePicker(context: d0, initialDate: init, firstDate: DateTime(2000), lastDate: DateTime(2100), helpText: tr('Lejárati dátum'));
                          if (x != null) setD(() => end = st.ym(x));
                        },
                        icon: const Icon(Icons.event),
                        label: Text(end.isEmpty ? 'Lejárati dátum' : trf('Lejárat: {0}', [fmtMonth(end)]))),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err!, style: const TextStyle(color: cOut))),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d0), child: const Text('Mégse')),
                    FilledButton(
                        onPressed: () {
                          final tv = double.tryParse(t.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
                          final pv = double.tryParse(p.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
                          final dn = dueDay?.day ?? 0;
                          if (tv <= 0 || pv <= 0 || dn < 1 || dn > 31 || end.isEmpty) {
                            setD(() => err = tr('Add meg az összes mezőt helyesen.'));
                            return;
                          }
                          final name = kind;
                          st.change(() {
                            if (e == null) {
                              st.loans.add(Loan(uid(), name, tv, pv, dn, end, st.ym(DateTime.now())));
                            } else {
                              e.name = name;
                              e.total = tv;
                              e.pay = pv;
                              e.day = dn;
                              e.end = end;
                            }
                          });
                          Navigator.pop(d0);
                          rescheduleAll();
                        },
                        child: const Text('Mentés')),
                  ],
                )));
  }

  Future<void> payLoanDialog(Loan l) async {
    final now = DateTime.now();
    final s = st.loanState(l, now);
    final unpaid = [...s.missed, if (!s.done) st.ym(now)];
    if (unpaid.isEmpty) return;
    var month = unpaid.first;
    final rem = s.rem, cap = rem;
    final a = TextEditingController(text: amtStr(l.pay < cap ? l.pay : cap));
    var acc = 'card';
    await showDialog<void>(
        context: context,
        builder: (d0) => StatefulBuilder(
            builder: (d0, setD) => AlertDialog(
                  title: Text(trf('Hitel törlesztése: {0}', [l.name])),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {acc}, onSelectionChanged: (x) => setD(() => acc = x.first)),
                    if (unpaid.length > 1) ...[
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                          value: month,
                          isExpanded: true,
                          decoration: InputDecoration(labelText: tr('Melyik hónapra?')),
                          items: [for (final m in unpaid) DropdownMenuItem(value: m, child: Text(fmtMonth(m)))],
                          onChanged: (v) => setD(() => month = v ?? month)),
                    ],
                    const SizedBox(height: 12),
                    TextField(controller: a, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Összeg'), suffixText: st.csym, helperText: trf('Elérhető: {0}', [ft(st.bal(acc))]))),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d0), child: const Text('Mégse')),
                    FilledButton(
                        onPressed: () {
                          final v = double.tryParse(a.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
                          if (v <= 0) return;
                          final amt = v > cap ? cap : v;
                          final lm = month;
                          void go() {
                            st.change(() => st.txs.add(Tx(id: uid(), type: 'out', acc: acc, cat: 'loan', item: '', amt: amt, date: DateTime.now(), note: '', ln: l.id, lm: lm)));
                            rescheduleAll();
                          }

                          Navigator.pop(d0);
                          final av = st.bal(acc);
                          if (av < amt) {
                            ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a törlesztés {2}. Biztosan befizeted?', [accName(acc), ft(av < 0 ? 0 : av), ft(amt)]), go);
                          } else {
                            go();
                          }
                        },
                        child: const Text('Befizetés rögzítése')),
                  ],
                )));
  }

  Widget sgStatusCard(SG g) {
    final ok = g.saved >= g.target, col = ok ? cIn : cOut;
    return Card(
        clipBehavior: Clip.antiAlias,
        child: Container(
          decoration: BoxDecoration(border: Border(left: BorderSide(color: col, width: 6))),
          padding: const EdgeInsets.all(16),
          width: double.infinity,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(g.name),
            Text.rich(TextSpan(text: ft(g.saved), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: col), children: [TextSpan(text: '  /  ${ft(g.target)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400))])),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: (g.saved / g.target).clamp(0.0, 1.0), color: col, minHeight: 8, borderRadius: BorderRadius.circular(4)),
            const SizedBox(height: 8),
            Text(ok ? 'Sikerült, elérted a célt.' : trf('Még {0} hiányzik.', [ft(g.target - g.saved)])),
            if (!ok && g.due.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(dueInfo(g))),
          ]),
        ));
  }

  Widget sgSummary() {
    if (st.sg.isEmpty) return const SizedBox();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Megtakarítási célok', style: Theme.of(context).textTheme.titleMedium)),
      for (final g in st.sg) sgStatusCard(g),
      TextButton(onPressed: () => setState(() => tab = 8), child: const Text('Célok kezelése')),
    ]);
  }

  Future<void> newGoalDialog() async {
    final n = TextEditingController(), t = TextEditingController();
    var due = '';
    final ok = await showDialog<bool>(
        context: context,
        builder: (d) => StatefulBuilder(
            builder: (d, setD) => AlertDialog(
                  title: const Text('Új megtakarítási cél'),
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: n, autofocus: true, decoration: InputDecoration(labelText: tr('Név'), hintText: tr('Pl. Nyaralás'))),
                    TextField(controller: t, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Cél összeg'), suffixText: st.csym)),
                    const SizedBox(height: 8),
                    TextButton.icon(
                        onPressed: () async {
                          final p = await showDatePicker(context: d, initialDate: DateTime.now().add(const Duration(days: 90)), firstDate: DateTime.now(), lastDate: DateTime(2100), helpText: tr('Határidő (hónap)'));
                          if (p != null) setD(() => due = '${p.year}-${p.month.toString().padLeft(2, '0')}');
                        },
                        icon: const Icon(Icons.event),
                        label: Text(due.isEmpty ? 'Határidő (nem kötelező)' : trf('Határidő: {0}', [due]))),
                  ])),
                  actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Mégse')), FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Létrehozás'))],
                )));
    final target = double.tryParse(t.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0;
    if (ok == true && n.text.trim().isNotEmpty && target > 0) st.change(() => st.sg.add(SG(uid(), n.text.trim(), target, 0, 0, due)));
  }

  Future<void> depositDialog(SG g) async {
    final c = TextEditingController();
    var acc = 'cash';
    final r = await showDialog<String>(
        context: context,
        builder: (d) => StatefulBuilder(
            builder: (d, setD) => AlertDialog(
                  title: Text(trf('Megtakarítás: {0}', [g.name])),
                  content: Column(mainAxisSize: MainAxisSize.min, children: [
                    SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {acc}, onSelectionChanged: (s) => setD(() => acc = s.first)),
                    const SizedBox(height: 12),
                    TextField(controller: c, autofocus: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(suffixText: st.csym, helperText: trf('Elérhető: {0}', [ft(st.bal(acc))]))),
                  ]),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse')),
                    TextButton(onPressed: () => Navigator.pop(d, 'sub'), child: const Text('Kivétel')),
                    FilledButton(onPressed: () => Navigator.pop(d, 'add'), child: const Text('Befizetés')),
                  ],
                )));
    final n = (double.tryParse(c.text.replaceAll(' ', '').replaceAll(',', '.')) ?? 0).abs();
    if (r == null || n <= 0) return;
    final dlt = r == 'add' ? n : -(n < g.saved ? n : g.saved);
    if (dlt == 0) return;
    void go() => st.change(() {
          st.txs.add(Tx(id: uid(), type: dlt > 0 ? 'out' : 'in', acc: acc, cat: dlt > 0 ? 'sav' : '', item: '', amt: dlt.abs(), date: DateTime.now(), note: '', sg: g.id));
        });
    if (dlt > 0 && st.bal(acc) < dlt) {
      ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a befizetés {2}. Biztosan befizeted?', [accName(acc), ft(st.bal(acc) < 0 ? 0 : st.bal(acc)), ft(dlt)]), go);
    } else {
      go();
    }
  }

  Widget sgSection() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Megtakarítási célok', style: Theme.of(context).textTheme.titleMedium)),
        for (final g in st.sg)
          Card(
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text(g.name, style: Theme.of(context).textTheme.titleSmall)),
                      IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => ask(trf('Biztosan törlöd a(z) {0} célt? A célhoz tartozó befizetések törlődnek a kiadások közül, az összeg visszakerül az egyenlegedre.', [g.name]), () => st.change(() {
                            st.txs.removeWhere((t) => t.sg == g.id);
                            st.sg.remove(g);
                          }))),
                    ]),
                    Text.rich(TextSpan(text: ft(g.saved), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: g.saved >= g.target ? cIn : null), children: [TextSpan(text: '  /  ${ft(g.target)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400))])),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: (g.saved / g.target).clamp(0.0, 1.0), minHeight: 8, borderRadius: BorderRadius.circular(4), color: g.saved >= g.target ? cIn : null),
                    const SizedBox(height: 8),
                    if (g.due.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(dueInfo(g))),
                    Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => pickDue(g), child: Text(g.due.isEmpty ? 'Határidő megadása' : 'Határidő módosítása'))),
                    Row(children: [
                      Expanded(child: Text(g.saved >= g.target ? 'Elérted a célt.' : trf('Még {0} hiányzik.', [ft(g.target - g.saved)]))),
                      FilledButton(onPressed: () => depositDialog(g), child: const Text('Befizetés / kivétel')),
                    ]),
                  ]))),
        OutlinedButton.icon(onPressed: newGoalDialog, icon: const Icon(Icons.add), label: const Text('Új cél')),
        const Padding(padding: EdgeInsets.only(top: 6), child: Text('A befizetés kiadásként jelenik meg (Megtakarítás kategória), és levonódik a kiválasztott számláról. A kivétel bevételként kerül vissza.', style: TextStyle(fontSize: 12))),
      ]);

  Widget trSection() {
    final l = st.mtx.where((t) => t.type == 'tr').toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20), child: Text('Számlák közötti átvezetések', style: Theme.of(context).textTheme.titleMedium)),
      if (l.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: Center(child: Text('Ebben a hónapban nincs átvezetés.'))) else dayList(l),
      if (st.trash.any((t) => t.type == 'tr')) trashList('tr'),
    ]);
  }

  Future<void> goalDialog() async {
    final g0 = st.goalFor(st.month);
    final ctl = TextEditingController(text: g0 > 0 ? amtStr(g0) : '');
    final r = await showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
              title: const Text('Havi megtakarítási cél'),
              content: TextField(controller: ctl, keyboardType: const TextInputType.numberWithOptions(decimal: true), autofocus: true, decoration: InputDecoration(suffixText: st.csym, hintText: 'Pl. 100000', helperText: tr('Erre a hónapra és a következőkre érvényes.'), helperMaxLines: 2)),
              actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse')), FilledButton(onPressed: () => Navigator.pop(d, ctl.text), child: const Text('Mentés'))],
            ));
    if (r != null) {
      final k = '${st.month.year}-${st.month.month.toString().padLeft(2, '0')}';
      st.change(() => st.goalM[k] = double.tryParse(r.replaceAll(' ', '').replaceAll(',', '.')) ?? 0);
    }
  }

  Widget goalCard(double net) {
    final g = st.goalFor(st.month);
    if (g <= 0) {
      return Card(margin: EdgeInsets.zero, child: ListTile(title: const Text('Havi megtakarítási cél'), subtitle: const Text('Add meg, mennyit szeretnél havonta félretenni.'), trailing: FilledButton(onPressed: goalDialog, child: const Text('Beállítás'))));
    }
    final ok = net >= g, col = ok ? cIn : cOut, diff = net - g;
    final msg = ok ? (diff > 0 ? trf('Teljesítve, {0} a cél felett vagy.', [ft(diff)]) : 'Teljesítve, pont elérted a célt.') : trf('Még {0} hiányzik a célig.', [ft(-diff)]);
    return Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: Container(
          decoration: BoxDecoration(border: Border(left: BorderSide(color: col, width: 6))),
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Expanded(child: Text('Havi megtakarítási cél')), TextButton(onPressed: goalDialog, child: const Text('Módosítás'))]),
            Text.rich(TextSpan(text: ft(net), style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: col), children: [TextSpan(text: '  /  ${ft(g)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w400))])),
            const SizedBox(height: 8),
            LinearProgressIndicator(value: (net / g).clamp(0.0, 1.0), color: col, minHeight: 8, borderRadius: BorderRadius.circular(4)),
            const SizedBox(height: 8),
            Text(msg),
          ]),
        ));
  }

  List<String> xchDetail(Tx t) {
    final fc = t.xc == 'HUF' ? st.cur : t.xc;
    final l1 = t.type == 'out' ? (t.xc == 'HUF' ? trf('Kapott: {0}', [ftc(t.xo, 'HUF')]) : trf('Vásárolt: {0}', [ftc(t.xo, t.xc)])) : trf('Átváltva ennyiből: {0}', [ftc(t.xo, t.xc)]);
    return [l1, trf('Árfolyam: 1 {0} = {1} Ft', [fc, NumberFormat('#,##0.####', st.lang).format(t.xr)])];
  }

  Future<int?> pickColor(int current) => showDialog<int>(
      context: context,
      builder: (d) => AlertDialog(
            title: const Text('Szín választása'),
            content: Wrap(spacing: 10, runSpacing: 10, children: [
              for (final c in palCols)
                GestureDetector(
                    onTap: () => Navigator.pop(d, c.value),
                    child: Container(width: 44, height: 44, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(12), border: Border.all(color: c.value == current ? Colors.black : Colors.transparent, width: 3)))),
            ]),
            actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse'))],
          ));

  Widget tile(Tx t) {
    final sub = [if (t.type == 'out' && st.itemName(t.cat, t.item).isNotEmpty) st.catName(t.cat), if (t.type == 'tr') '${accName(t.acc)} → ${accName(t.to)}', if (t.xid.isNotEmpty) ...xchDetail(t), if (t.rl.isNotEmpty) trf('🧾 {0} tétel', [t.rl.length]) + (t.rs.isEmpty ? '' : ' · ${t.rs}'), if (t.tags.isNotEmpty) t.tags.map((x) => '#$x').join(' '), if (t.note.isNotEmpty) t.note].join('\n');
    final card = Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          onTap: () => (selMode && (tab == 1 || tab == 2) && !t.linked)
              ? setState(() => selIds.contains(t.id) ? selIds.remove(t.id) : selIds.add(t.id))
              : (t.sg.isNotEmpty ? snack('Ez egy megtakarítási befizetés. A Megtakarítási célok oldalon tudsz befizetni vagy kivenni.') : (t.ln.isNotEmpty ? snack('Ez egy hitel törlesztése. A Hitel oldalon vonhatod vissza.') : (t.rc.isNotEmpty ? snack('Ez egy kölcsönadáshoz tartozó mozgás. A Kintlévőség oldalon kezelheted.') : (t.xid.isNotEmpty ? ask('Biztosan törlöd ezt az átváltást? Mindkét számláról törlődik.', () => st.deleteXch(t.xid)) : (t.rl.isNotEmpty ? showReceipt(t) : openSheet(edit: t, lock: tab == 1 || tab == 2)))))),
          leading: (selMode && (tab == 1 || tab == 2) && !t.linked)
              ? Checkbox(value: selIds.contains(t.id), onChanged: (_) => setState(() => selIds.contains(t.id) ? selIds.remove(t.id) : selIds.add(t.id)))
              : txIcon(t),
          title: m.Text(tr(st.title(t)) + (t.ph ? ' 📎' : '')),
          subtitle: sub.isEmpty ? null : Text(sub),
          trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('${(t.type == 'in' || t.type == 'back' || t.type == 'xin') ? '+' : (t.type == 'tr' ? '' : '−')}${ft(t.amt)}', style: TextStyle(fontWeight: FontWeight.w700, color: (t.type == 'in' || t.type == 'back' || t.type == 'xin') ? cIn : (t.type == 'tr' ? Colors.grey : cOut))),
            Text(t.type == 'tr' ? '' : accName(t.acc), style: Theme.of(context).textTheme.bodySmall),
          ]),
        ));
    if (t.linked || selMode || !(tab == 1 || tab == 2 || tab == 4)) return card;
    return Dismissible(
        key: ValueKey('tx_${t.id}'),
        direction: DismissDirection.endToStart,
        background: Container(
            margin: const EdgeInsets.only(bottom: 8),
            decoration: BoxDecoration(color: cOut, borderRadius: BorderRadius.circular(20)),
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 24),
            child: const Icon(Icons.delete_outline, color: Colors.white, size: 28)),
        onDismissed: (_) {
          HapticFeedback.mediumImpact();
          final id = t.id;
          st.change(() {
            st.trash.add(t);
            st.txs.removeWhere((x) => x.id == id);
          });
          snackUndo('Tétel törölve.', () => undelTx([id]));
        },
        child: card);
  }

  Widget dayList(List<Tx> l, {bool heads = true}) {
    if (l.isEmpty) {
      return Padding(
          padding: const EdgeInsets.all(28),
          child: Column(children: [
            const Icon(Icons.receipt_long_outlined, size: 40),
            const SizedBox(height: 8),
            const Text('Még nincs tétel ebben az időszakban.', style: TextStyle(fontWeight: FontWeight.w700), textAlign: TextAlign.center),
            const SizedBox(height: 4),
            const Text('Rögzítsd az első tételt a + gombbal.', textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.tonal(onPressed: () => openSheet(date: tab == 4 ? sel : null, newType: tab == 1 ? 'in' : (tab == 3 ? 'tr' : 'out'), lock: tab == 1 || tab == 2), child: const Text('Új tétel')),
          ]));
    }
    final ch = <Widget>[];
    DateTime? last;
    for (final t in l.take(listLim)) {
      if (heads && (last == null || !sameDay(last, t.date))) {
        last = t.date;
        ch.add(Padding(padding: const EdgeInsets.only(top: 12, bottom: 6), child: Text(dfm('d. EEEE', t.date), style: Theme.of(context).textTheme.labelLarge)));
      }
      ch.add(tile(t));
    }
    if (l.length > listLim) ch.add(Padding(padding: const EdgeInsets.only(top: 8), child: OutlinedButton(onPressed: () => setState(() => listLim += 80), child: Text(trf('Továbbiak megjelenítése ({0})', [l.length - listLim])))));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: ch);
  }

  Widget trPage() {
    final l = st.mtx.where((t) => t.type == 'tr' || t.xid.isNotEmpty).toList();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(children: [
        Expanded(child: box('Elérhető készpénz', st.bal('cash'), cCash)),
        const SizedBox(width: 12),
        Expanded(child: box('Elérhető a bankkártyán', st.bal('card'), cCard)),
      ]),
      dayList(l),
      if (st.trash.any((t) => t.type == 'tr')) trashList('tr'),
    ]);
  }

  Widget list() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SegmentedButton<bool>(
            segments: [
              const ButtonSegment(value: false, label: Text('Tételek')),
              ButtonSegment(value: true, label: Text(trf('Törölt ({0})', [st.trash.where((t) => t.type == lt).length]))),
            ],
            selected: {dv},
            onSelectionChanged: (s) => setState(() => dv = s.first)),
        if (dv) trashList(lt) else ...filterView(),
      ]);

  final fqc = TextEditingController();
  String fa = '', ftp = '', fc = '', ftag = '';

  List<String> allTags() {
    final sset = <String>{};
    for (final t in st.txs) {
      sset.addAll(t.tags);
    }
    return sset.toList()..sort();
  }

  Map<String, String> catOpts() {
    final m = <String, String>{'': 'Mind'};
    if (lt == 'out') {
      for (final c in st.cats) {
        m[c.id] = c.name;
      }
      m['sav'] = 'Megtakarítás';
      m['loan'] = 'Hitel';
      m['xch'] = 'Pénzváltás';
    } else {
      for (final c in st.icats) {
        m[c.id] = c.name;
      }
      m['xch'] = 'Pénzváltás';
    }
    return m;
  }

  Widget dd(String label, String val, Map<String, String> opts, void Function(String) on) => DropdownButtonFormField<String>(
      value: opts.containsKey(val) ? val : '',
      isExpanded: true,
      decoration: InputDecoration(labelText: tr(label), isDense: true, border: const OutlineInputBorder()),
      items: [for (final e in opts.entries) DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))],
      onChanged: (v) => setState(() => on(v ?? '')));

  List<Widget> filterView() {
    final active = fqc.text.isNotEmpty || fa != '' || fc != '' || ftag != '';
    final q = fqc.text.toLowerCase();
    final base = active ? ([...st.txs]..sort((a, b) => b.date.compareTo(a.date))) : st.mtx;
    final l = base.where((t) {
      if (t.type != lt) return false;
      if (fa != '' && t.acc != fa) return false;
      if (fc != '' && t.cat != fc) return false;
      if (ftag != '' && !t.tags.contains(ftag)) return false;
      if (q.isEmpty) return true;
      return [st.title(t), st.catName(t.cat), t.note, t.tags.join(' '), t.rs, t.rl.map((x) => '${x['n']}').join(' '), t.amt.round().toString()].any((s) => s.toLowerCase().contains(q));
    }).toList();
    visIds = l.where((t) => !t.linked).map((t) => t.id).toList();
    return [
      Row(children: [
        TextButton(
            onPressed: () => setState(() {
                  selMode = !selMode;
                  selIds = {};
                }),
            child: Text(selMode ? 'Kijelölés vége' : 'Kijelölés')),
        if (selMode) ...[
          TextButton(onPressed: () => setState(() => selIds = {...visIds}), child: const Text('Mind kijelölése')),
          const Spacer(),
          FilledButton(
              onPressed: selIds.isEmpty
                  ? null
                  : () {
                      final ids = selIds.toList();
                      st.change(() {
                        st.trash.addAll(st.txs.where((t) => selIds.contains(t.id)));
                        st.txs.removeWhere((t) => selIds.contains(t.id));
                      });
                      setState(() {
                        selIds = {};
                        selMode = false;
                      });
                      snackUndo(trf('{0} tétel törölve.', [ids.length]), () => undelTx(ids));
                    },
              child: Text(trf('Törlés ({0})', [selIds.length]))),
        ],
      ]),
      const SizedBox(height: 4),
      TextField(controller: fqc, onChanged: (_) => setState(() {}), decoration: InputDecoration(hintText: tr('Keresés: tétel, megjegyzés, összeg'), prefixIcon: Icon(Icons.search), isDense: true, border: OutlineInputBorder())),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: dd('Számla', fa, {'': 'Mind', 'cash': 'Készpénz', 'card': 'Bankkártya'}, (v) => fa = v)),
        const SizedBox(width: 8),
        Expanded(child: dd('Kategória', fc, catOpts(), (v) => fc = v)),
      ]),
      if (allTags().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: dd('Címke', ftag, {'': 'Mind', for (final x in allTags()) x: '#$x'}, (v) => ftag = v)),
      if (active) Padding(padding: const EdgeInsets.only(top: 8), child: Text(trf('Találatok: {0} (minden hónapban)', [l.length]), style: Theme.of(context).textTheme.labelLarge)),
      Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(trf('{0} összesen: {1}', [lt == 'in' ? 'Bevételek' : 'Kiadások', ft(l.fold(0.0, (s, t) => s + t.amt))]), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: lt == 'in' ? cIn : cOut))),
      dayList(l),
    ];
  }

  Widget trashList(String type) {
    final items = st.trash.reversed.where((t) => t.type == type).toList();
    if (items.isEmpty) return const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Nincs törölt tétel.')));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 14), child: Text('Legutóbb törölt tételek', style: Theme.of(context).textTheme.labelLarge)),
      for (final t in items)
        Card(
            margin: const EdgeInsets.only(top: 8),
            child: Column(children: [
              ListTile(
                leading: txIcon(t),
                title: m.Text(tr(st.title(t)) + (t.ph ? ' 📎' : '')),
                subtitle: Text(dfm('yyyy. MMMM d.', t.date) + (t.note.isEmpty ? '' : '\n${t.note}')),
                trailing: Text('${(t.type == 'in' || t.type == 'back' || t.type == 'xin') ? '+' : (t.type == 'tr' ? '' : '−')}${ft(t.amt)}', style: TextStyle(fontWeight: FontWeight.w700, color: (t.type == 'in' || t.type == 'back' || t.type == 'xin') ? cIn : (t.type == 'tr' ? Colors.grey : cOut), decoration: TextDecoration.lineThrough)),
              ),
              Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                TextButton(
                    onPressed: () => st.change(() {
                          st.trash.remove(t);
                          st.txs.add(t);
                        }),
                    child: const Text('Visszaállítás')),
                TextButton(onPressed: () => ask('Véglegesen törlöd ezt a tételt? Ez nem vonható vissza.', () => st.change(() => st.trash.remove(t))), child: const Text('Végleges törlés')),
              ]),
            ])),
    ]);
  }

  Widget cal() {
    final m = st.month, off = (DateTime(m.year, m.month, 1).weekday + 6) % 7, n = DateUtils.getDaysInMonth(m.year, m.month), tx = st.mtx;
    final cells = <Widget>[
      for (final d in (st.lang == 'en' ? ['M', 'T', 'W', 'T', 'F', 'S', 'S'] : ['H', 'K', 'Sze', 'Cs', 'P', 'Szo', 'V'])) Center(child: Text(d, style: Theme.of(context).textTheme.bodySmall)),
      for (var i = 0; i < off; i++) const SizedBox(),
      for (var d = 1; d <= n; d++) dayCell(DateTime(m.year, m.month, d), tx),
    ];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      GridView.count(crossAxisCount: 7, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 4, crossAxisSpacing: 4, children: cells),
      Padding(padding: const EdgeInsets.only(top: 16), child: Text(dfm('d. EEEE', sel), style: Theme.of(context).textTheme.titleMedium)),
      const SizedBox(height: 8),
      dayList(st.txs.where((t) => sameDay(t.date, sel)).toList(), heads: false),
    ]);
  }

  Widget dayCell(DateTime d, List<Tx> tx) {
    final day = tx.where((t) => sameDay(t.date, d)).toList(), out = st.sum(day, 'out'), hasIn = day.any((t) => t.type == 'in');
    final isSel = sameDay(d, sel), cs = Theme.of(context).colorScheme;
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => setState(() => sel = d),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: sameDay(d, DateTime.now()) ? cs.primary.withOpacity(.12) : null,
            border: Border.all(color: isSel ? cs.primary : cs.outlineVariant, width: isSel ? 2 : 1)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text('${d.day}', style: TextStyle(fontWeight: isSel ? FontWeight.w700 : null)),
          if (out > 0) Text('−${out >= 1000 ? '${(out / 1000).round()}e' : out.round()}', style: const TextStyle(fontSize: 9, color: cOut)),
          if (hasIn) const CircleAvatar(radius: 2.5, backgroundColor: cIn),
        ]),
      ),
    );
  }

  Widget card(String t, Widget c) => Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: Theme.of(context).textTheme.titleSmall), const SizedBox(height: 12), c])));

  Widget stats() {
    final tx = st.mtx, outs = tx.where((t) => t.type == 'out').toList();
    if (tx.isEmpty) return const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Nincs tétel ebben a hónapban.')));
    final by = <String, double>{};
    for (final t in outs) {
      by[t.cat] = (by[t.cat] ?? 0) + t.amt;
    }
    final ent = by.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final total = st.sum(outs, 'out');
    final n = DateUtils.getDaysInMonth(st.month.year, st.month.month);
    final dd = [for (var d = 1; d <= n; d++) st.sum(outs.where((t) => t.date.day == d), 'out')];
    var run = st.openCash + st.openCard - st.sgl.where((x) => x.date.isBefore(st.month)).fold(0.0, (s, x) => s + x.amt) + st.txs.where((t) => t.date.isBefore(st.month)).fold(0.0, (s, t) => s + t.signed);
    final now = DateTime.now();
    final lim = (now.year == st.month.year && now.month == st.month.month) ? now.day : n;
    final spots = <FlSpot>[FlSpot(0, run)];
    for (var d = 1; d <= lim; d++) {
      run += st.txs.where((t) => sameDay(t.date, DateTime(st.month.year, st.month.month, d))).fold(0.0, (s, t) => s + t.signed) - st.sgl.where((x) => sameDay(x.date, DateTime(st.month.year, st.month.month, d))).fold(0.0, (s, x) => s + x.amt);
      spots.add(FlSpot(d.toDouble(), run));
    }
    const noTitles = FlTitlesData(show: false);
    return Column(children: [
      rptButtons(false),
      Padding(padding: const EdgeInsets.only(bottom: 10), child: OutlinedButton.icon(onPressed: () => rptShow(st.ym(st.month)), icon: const Icon(Icons.summarize_outlined), label: const Text('Havi összefoglaló'))),
      card(
          'Kiadások kategóriánként',
          total <= 0
              ? const Text('Nincs kiadás.')
              : Column(children: [
                  SizedBox(
                      height: 180,
                      child: PieChart(PieChartData(centerSpaceRadius: 50, sectionsSpace: 2, sections: [
                        for (var i = 0; i < ent.length; i++) PieChartSectionData(value: ent[i].value, color: st.catColorById(ent[i].key), title: '', radius: 34),
                      ]))),
                  const SizedBox(height: 8),
                  for (var i = 0; i < ent.length; i++)
                    Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(children: [
                          CircleAvatar(radius: 5, backgroundColor: st.catColorById(ent[i].key)),
                          const SizedBox(width: 8),
                          Expanded(child: Text(st.catName(ent[i].key).isEmpty ? 'Egyéb' : st.catName(ent[i].key))),
                          Text(ft(ent[i].value), style: const TextStyle(fontWeight: FontWeight.w700)),
                        ])),
                ])),
      card(
          'Napi kiadások',
          SizedBox(
              height: 140,
              child: BarChart(BarChartData(
                  titlesData: noTitles,
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  barGroups: [for (var d = 1; d <= n; d++) BarChartGroupData(x: d, barRods: [BarChartRodData(toY: dd[d - 1], color: cOut, width: 5)])])))),
      card(
          'Összes pénz alakulása a hónapban',
          SizedBox(
              height: 140,
              child: LineChart(LineChartData(
                  titlesData: noTitles,
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  lineBarsData: [LineChartBarData(spots: spots, color: Theme.of(context).colorScheme.primary, barWidth: 3, dotData: const FlDotData(show: false))])))),
      incomeCard(tx),
      compareCard(outs),
    ]);
  }

  Widget incomeCard(List<Tx> tx) {
    final by = <String, double>{};
    for (final t in tx.where((t) => t.type == 'in')) {
      by[t.cat] = (by[t.cat] ?? 0) + t.amt;
    }
    if (by.isEmpty) return const SizedBox();
    final ent = by.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    return card(
        'Bevételek kategóriánként',
        Column(children: [
          for (var i = 0; i < ent.length; i++)
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(children: [
                  CircleAvatar(radius: 5, backgroundColor: st.incColorById(ent[i].key)),
                  const SizedBox(width: 8),
                  Expanded(child: Text(st.icName(ent[i].key).isEmpty ? 'Egyéb' : st.icName(ent[i].key))),
                  Text(ft(ent[i].value), style: const TextStyle(fontWeight: FontWeight.w700)),
                ])),
        ]));
  }

  int yv = DateTime.now().year;

  Widget yearPage() {
    final ins = List<double>.filled(12, 0), outs = List<double>.filled(12, 0);
    for (final t in st.txs) {
      if (t.date.year != yv) continue;
      if (t.type == 'in') ins[t.date.month - 1] += t.amt;
      if (t.type == 'out') outs[t.date.month - 1] += t.amt;
    }
    final ti = ins.fold(0.0, (a, b) => a + b), te = outs.fold(0.0, (a, b) => a + b), net = ti - te;
    final mx = [...ins, ...outs].fold(1.0, (a, b) => b > a ? b : a);
    const hide = AxisTitles(sideTitles: SideTitles(showTitles: false));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      rptButtons(true),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(onPressed: () => setState(() => yv--), icon: const Icon(Icons.chevron_left)),
        Text('$yv', style: Theme.of(context).textTheme.titleLarge),
        IconButton(onPressed: () => setState(() => yv++), icon: const Icon(Icons.chevron_right)),
      ]),
      Row(children: [Expanded(child: box('Bevétel', ti, cIn)), const SizedBox(width: 12), Expanded(child: box('Kiadás', te, cOut))]),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: box('Megtakarítás', net, net >= 0 ? cIn : cOut)), const SizedBox(width: 12), Expanded(child: box('Havi átlag megtakarítás', net / 12, Theme.of(context).colorScheme.onSurface))]),
      const SizedBox(height: 12),
      card(
          'Bevétel és kiadás havonta',
          SizedBox(
              height: 160,
              child: BarChart(BarChartData(
                  maxY: mx * 1.05,
                  titlesData: FlTitlesData(
                    topTitles: hide,
                    rightTitles: hide,
                    leftTitles: hide,
                    bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, meta) => Text('${v.toInt() + 1}', style: const TextStyle(fontSize: 10)))),
                  ),
                  gridData: const FlGridData(show: false),
                  borderData: FlBorderData(show: false),
                  barGroups: [
                    for (var m = 0; m < 12; m++) BarChartGroupData(x: m, barRods: [BarChartRodData(toY: ins[m], color: cIn, width: 6), BarChartRodData(toY: outs[m], color: cOut, width: 6)]),
                  ])))),
      card(
          'Hónapok',
          Column(children: [
            for (var m = 0; m < 12; m++)
              Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [
                    Expanded(child: Text(dfm('MMMM', DateTime(yv, m + 1)))),
                    Text('${ins[m] - outs[m] >= 0 ? '+' : '−'}${ft((ins[m] - outs[m]).abs())}', style: TextStyle(fontWeight: FontWeight.w700, color: ins[m] - outs[m] > 0 ? cIn : (ins[m] - outs[m] < 0 ? cOut : null))),
                  ])),
          ])),
    ]);
  }

  Widget compareCard(List<Tx> outs) {
    final pm = DateTime(st.month.year, st.month.month - 1);
    final pouts = st.txs.where((t) => t.type == 'out' && t.date.year == pm.year && t.date.month == pm.month).toList();
    const title = 'Összehasonlítás az előző hónappal';
    if (pouts.isEmpty) return card(title, const Text('Az előző hónapra nincs adat.'));
    final cs = st.sum(outs, 'out'), ps = st.sum(pouts, 'out');
    final pct = ((cs - ps).abs() / ps * 100).round();
    final ids = {...outs.map((t) => t.cat), ...pouts.map((t) => t.cat)};
    Widget line(String l, double d) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(child: Text(l)),
          Text('${d >= 0 ? '+' : '−'}${ft(d.abs())}', style: TextStyle(fontWeight: FontWeight.w700, color: d > 0 ? cOut : (d < 0 ? cIn : null))),
        ]));
    return card(
        title,
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(cs == ps ? 'Ugyanannyit költöttél' : trf('{0}%-kal {1} költöttél', [pct, cs > ps ? 'többet' : 'kevesebbet']), style: TextStyle(fontWeight: FontWeight.w700, color: cs > ps ? cOut : cIn)),
          Text(trf('{0} ebben a hónapban, {1} az előzőben', [ft(cs), ft(ps)])),
          const SizedBox(height: 8),
          for (final id in ids) line(st.catName(id).isEmpty ? 'Egyéb' : st.catName(id), st.sum(outs.where((t) => t.cat == id), 'out') - st.sum(pouts.where((t) => t.cat == id), 'out')),
        ]));
  }

  Widget catEditor() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        for (final c in st.cats)
          Card(
              child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      GestureDetector(
                          onTap: () async {
                            final v = await pickColor(st.catColorById(c.id).value);
                            if (v != null) st.change(() => c.color = v);
                          },
                          child: CircleAvatar(radius: 12, backgroundColor: st.catColorById(c.id))),
                      const SizedBox(width: 10),
                      Expanded(child: Text(c.name, style: Theme.of(context).textTheme.titleMedium)),
                      IconButton(icon: const Icon(Icons.edit_outlined), tooltip: tr('Átnevezés'), onPressed: () => rename('Kategória új neve', c.name, (n) => st.change(() => c.name = n))),
                      TextButton(onPressed: () => ask(trf('Törlöd a(z) {0} kategóriát? A korábbi tételek megmaradnak.', [c.name]), () => st.change(() => st.cats.remove(c))), child: const Text('Törlés')),
                    ]),
                    Wrap(spacing: 8, children: [for (final i in c.items) InputChip(label: Text(i.name), onPressed: () => rename('Tétel új neve', i.name, (n) => st.change(() => i.name = n)), onDeleted: () => st.change(() => c.items.remove(i)))]),
                    const SizedBox(height: 10),
                    AddField('Új tétel, pl. Spotify', (v) => st.change(() => c.items.add(Item(uid(), v)))),
                  ]))),
        Card(
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Új kategória', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 10),
                  AddField('Pl. Utazás', (v) => st.change(() => st.cats.add(Cat(uid(), v, [], palCols[st.cats.length % palCols.length].value)))),
                ]))),
        Padding(padding: const EdgeInsets.only(top: 12, bottom: 6), child: Text('Bevételi kategóriák', style: Theme.of(context).textTheme.titleMedium)),
        Wrap(spacing: 8, children: [for (final c in st.icats)
            InputChip(
                avatar: GestureDetector(
                    onTap: () async {
                      final v = await pickColor(st.incColorById(c.id).value);
                      if (v != null) st.change(() => c.color = v);
                    },
                    child: CircleAvatar(backgroundColor: st.incColorById(c.id))),
                label: Text(c.name),
                onPressed: () => rename('Bevételi kategória új neve', c.name, (n) => st.change(() => c.name = n)), onDeleted: () => ask(trf('Biztosan törlöd a(z) {0} kategóriát? A korábbi bevételek megmaradnak.', [c.name]), () => st.change(() => st.icats.remove(c))))]),
        const SizedBox(height: 8),
        AddField('Pl. Prémium', (v) => st.change(() => st.icats.add(Item(uid(), v, palCols[(st.icats.length + 3) % palCols.length].value)))),
      ]);

  Widget cats() => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [...settingsExtra()]);

  final ocash = TextEditingController(text: st.openCash == 0 ? '' : amtStr(st.openCash));
  final ocard = TextEditingController(text: st.openCard == 0 ? '' : amtStr(st.openCard));

  Future<void> rename(String title, String cur, void Function(String) ok) async {
    final c = TextEditingController(text: cur);
    final r = await showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
              title: Text(title),
              content: TextField(controller: c, autofocus: true),
              actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse')), FilledButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Mentés'))],
            ));
    if (r != null && r.isNotEmpty) ok(r);
  }

  void snack(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> copy(String s, String msg) async {
    await Clipboard.setData(ClipboardData(text: s));
    snack(msg);
  }

  void confirmRestore(String data, String badMsg, [VoidCallback? after]) {
    final pr = backupProblem(data);
    if (pr == 'invalid') {
      snack(badMsg);
      return;
    }
    if (pr == 'newer') {
      snack('Ez a mentés az app újabb verziójából készült. Frissítsd az appot, majd próbáld újra.');
      return;
    }
    ask(pr == 'chk' ? 'A mentés ellenőrző összege nem egyezik, a fájl sérült lehet vagy módosították. Biztosan visszatöltöd? A jelenlegi adatok felülíródnak.' : 'Biztosan visszatöltöd a mentést? A jelenlegi adatok felülíródnak.', () async {
      try {
        await st.restoreAny(data);
        if (after != null) after();
        snack('A mentés visszatöltve.');
      } catch (_) {
        snack(badMsg);
      }
    });
  }

  Future<void> restoreBackup() async {
    final d = await Clipboard.getData('text/plain');
    final s = d?.text ?? '';
    confirmRestore(s, 'A vágólapon nincs érvényes mentés.', () {
      ocash.text = st.openCash == 0 ? '' : amtStr(st.openCash);
      ocard.text = st.openCard == 0 ? '' : amtStr(st.openCard);
    });
  }

  Future<void> saveBackupFile() async {
    try {
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/koltsegvetes-mentes-${st.ymd(DateTime.now())}.json');
      await f.writeAsString(await st.fullBackup());
      final r = await Share.shareXFiles([XFile(f.path)], subject: tr('Költségvetés mentés'));
      if (r.status != ShareResultStatus.dismissed) await st.markBackup();
    } catch (_) {
      snack('A fájl mentése nem sikerült.');
    }
  }

  void snackUndo(String m, VoidCallback undo) {
    if (!mounted) return;
    final sm = ScaffoldMessenger.of(context);
    sm.hideCurrentSnackBar();
    sm.showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 6), action: SnackBarAction(label: tr('Visszavonás'), onPressed: undo)));
  }

  void undelTx(List<String> ids) {
    st.change(() {
      for (final id in ids) {
        final i = st.trash.indexWhere((x) => x.id == id);
        if (i >= 0) {
          st.txs.add(st.trash[i]);
          st.trash.removeAt(i);
        }
      }
    });
  }

  Widget quickRow() {
    final lim = DateTime.now().subtract(const Duration(days: 120));
    final cnt = <String, int>{};
    for (final t in st.txs) {
      if (t.type != 'out' || t.date.isBefore(lim) || t.cat.isEmpty || t.cat == 'sav' || t.cat == 'loan' || t.linked) continue;
      if (!st.cats.any((c) => c.id == t.cat)) continue;
      final k = '${t.cat}|${t.item}|${t.acc}|${t.amt}';
      cnt[k] = (cnt[k] ?? 0) + 1;
    }
    final l = (cnt.entries.where((e) => e.value >= 2).toList()..sort((a, b) => b.value.compareTo(a.value))).take(6).map((e) => e.key).toList();
    if (l.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Gyors kiadás', style: Theme.of(context).textTheme.titleMedium)),
      Wrap(spacing: 8, runSpacing: 0, children: [
        for (final k in l)
          ActionChip(
              label: Text('${st.itemName(k.split('|')[0], k.split('|')[1]).isNotEmpty ? st.itemName(k.split('|')[0], k.split('|')[1]) : st.catName(k.split('|')[0])} · ${ft(double.parse(k.split('|')[3]))}'),
              onPressed: () => quickAdd(k.split('|')[0], k.split('|')[1], k.split('|')[2], double.parse(k.split('|')[3]))),
      ]),
    ]);
  }

  void quickAdd(String cat, String item, String acc, double amt) {
    void go() {
      final id = uid();
      final n = DateTime.now();
      st.change(() => st.txs.add(Tx(id: id, type: 'out', acc: acc, cat: cat, item: item, amt: amt, date: DateTime(n.year, n.month, n.day), note: '')));
      final nm = st.itemName(cat, item).isNotEmpty ? st.itemName(cat, item) : st.catName(cat);
      snackUndo(trf('Rögzítve: {0}', ['$nm ${ft(amt)}']), () => st.change(() => st.txs.removeWhere((x) => x.id == id)));
    }

    final av = st.bal(acc);
    if (av < amt) {
      ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a tétel összege {2}. Biztosan rögzíted?', [accName(acc), ft(av < 0 ? 0 : av), ft(amt)]), go);
    } else {
      go();
    }
  }

  Rpt buildRpt(bool year) {
    final y = year ? yv : st.month.year;
    final tx = st.txs.where((t) => t.date.year == y && (year || t.date.month == st.month.month)).toList()..sort((a, b) => a.date.compareTo(b.date));
    final ins = tx.where((t) => t.type == 'in').toList(), outs = tx.where((t) => t.type == 'out').toList();
    List<MapEntry<String, double>> grp(List<Tx> l, String Function(Tx) nf) {
      final m = <String, double>{};
      for (final t in l) {
        final k = nf(t).isEmpty ? '—' : nf(t);
        m[k] = (m[k] ?? 0) + t.amt;
      }
      return m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    }

    final months = <List<Object>>[];
    if (year) {
      for (var m = 1; m <= 12; m++) {
        final i = st.sum(tx.where((t) => t.date.month == m), 'in'), o = st.sum(tx.where((t) => t.date.month == m), 'out');
        months.add([dfm('MMMM', DateTime(y, m)), i, o, i - o]);
      }
    }
    return Rpt(year, year ? '$y' : dfm('yyyy. MMMM', st.month), tx, st.sum(tx, 'in'), st.sum(tx, 'out'), grp(outs, (t) => tr(st.catName(t.cat))), grp(ins, (t) => st.icName(t.cat).isEmpty ? tr('Bevétel') : st.icName(t.cat)), months);
  }

  Widget rptButtons(bool year) => Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Wrap(spacing: 8, children: [
        OutlinedButton.icon(onPressed: () => rptPdf(year), icon: const Icon(Icons.picture_as_pdf_outlined), label: const Text('PDF')),
        OutlinedButton.icon(onPressed: () => rptExcel(year), icon: const Icon(Icons.table_chart_outlined), label: const Text('Excel')),
      ]));

  Future<void> rptPdf(bool year) async {
    try {
      final html = rptHtml(buildRpt(year));
      await Printing.layoutPdf(name: 'koltsegvetes', onLayout: (format) => Printing.convertHtml(format: format, html: html));
    } catch (_) {
      snack('A jelentés készítése nem sikerült.');
    }
  }

  Future<void> rptExcel(bool year) async {
    try {
      final r = buildRpt(year);
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/koltsegvetes-${year ? '$yv' : '${st.month.year}-${st.month.month.toString().padLeft(2, '0')}'}.xlsx');
      await f.writeAsBytes(rptXlsx(r));
      await Share.shareXFiles([XFile(f.path)], subject: tr('Költségvetés'));
    } catch (_) {
      snack('A jelentés készítése nem sikerült.');
    }
  }

  void afterRestore() {
    ocash.text = st.openCash == 0 ? '' : amtStr(st.openCash);
    ocard.text = st.openCard == 0 ? '' : amtStr(st.openCard);
    setState(() => snapTick++);
  }

  Future<String?> askPassword(String msg, bool confirm) async {
    final p1 = TextEditingController(), p2 = TextEditingController();
    String? err;
    return showDialog<String>(
        context: context,
        builder: (d) => StatefulBuilder(
            builder: (d, setD) => AlertDialog(
                  content: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(msg),
                    const SizedBox(height: 8),
                    TextField(controller: p1, obscureText: true, decoration: InputDecoration(labelText: tr('Jelszó'))),
                    if (confirm) TextField(controller: p2, obscureText: true, decoration: InputDecoration(labelText: tr('Jelszó megerősítése'))),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(err!, style: const TextStyle(color: cOut))),
                  ])),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse')),
                    FilledButton(
                        onPressed: () {
                          if (confirm && p1.text.length < 6) {
                            setD(() => err = tr('A jelszó legalább 6 karakter legyen.'));
                            return;
                          }
                          if (confirm && p1.text != p2.text) {
                            setD(() => err = tr('A két jelszó nem egyezik.'));
                            return;
                          }
                          if (p1.text.isEmpty) return;
                          Navigator.pop(d, p1.text);
                        },
                        child: const Text('OK')),
                  ],
                )));
  }

  Future<T> busy<T>(Future<T> Function() f) async {
    showDialog<void>(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator()));
    try {
      return await f();
    } finally {
      if (mounted) Navigator.of(context, rootNavigator: true).pop();
    }
  }

  Future<void> saveEncFile() async {
    final pw = await askPassword('Adj meg egy jelszót a mentés titkosításához. Ha elfelejted, a mentés nem állítható vissza!', true);
    if (pw == null) return;
    try {
      final txt = await st.fullBackup();
      final enc = await busy(() => encText(txt, pw));
      final dir = await getTemporaryDirectory();
      final f = File('${dir.path}/koltsegvetes-titkositott-${st.ymd(DateTime.now())}.json');
      await f.writeAsString(enc);
      final r = await Share.shareXFiles([XFile(f.path)], subject: tr('Titkosított mentés'));
      if (r.status != ShareResultStatus.dismissed) await st.markBackup();
    } catch (_) {
      snack('A fájl mentése nem sikerült.');
    }
  }

  Widget snapSection() => FutureBuilder<List<File>>(
      key: ValueKey(snapTick),
      future: snapFiles(),
      builder: (c, sn) {
        final l = sn.data ?? <File>[];
        return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('A készülék naponta elmenti az adataid másolatát (az utolsó 7 napot). Ez véletlen törlés vagy hiba ellen véd, készülék elvesztése ellen nem, ahhoz használd a fájlmentést.', style: TextStyle(fontSize: 12)),
          if (l.isEmpty) const Padding(padding: EdgeInsets.only(top: 6), child: Text('Még nincs automatikus mentés.')),
          if (l.isNotEmpty)
            TextButton(
                style: TextButton.styleFrom(foregroundColor: cOut),
                onPressed: () => ask('Biztosan törlöd az összes automatikus mentést? Ez nem vonható vissza.', () async {
                      for (final f in await snapFiles()) {
                        await f.delete();
                      }
                      setState(() => snapTick++);
                    }),
                child: const Text('Automatikus mentések törlése')),
          for (final f in l)
            Row(children: [
              Expanded(child: Text(snapLabel(f))),
              TextButton(
                  onPressed: () => ask('Biztosan visszaállítod ezt a mentést? A jelenlegi adatok felülíródnak.', () async {
                        try {
                          await st.restoreAny(await f.readAsString());
                          afterRestore();
                          snack('A mentés visszatöltve.');
                        } catch (_) {
                          snack('A fájl nem érvényes mentés.');
                        }
                      }),
                  child: const Text('Visszaállítás')),
            ]),
        ]);
      });

  Future<void> reportError() async {
    final p = await SharedPreferences.getInstance();
    final l = p.getStringList('errlog') ?? <String>[];
    final txt = ['Költségvetés hibajelentés', 'Verzió: $kVer', 'Nyelv: ${st.lang}', 'Rendszer: ${Platform.operatingSystem} ${Platform.operatingSystemVersion}', 'Tételek száma: ${st.txs.length}', 'Hibanapló:', ...(l.isEmpty ? ['(üres)'] : l)].join('\n');
    await Share.share(txt, subject: 'Költségvetés hibajelentés');
  }

  Future<void> restoreFromFile() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = r?.files.single.path;
      if (path == null) return;
      var txt = await File(path).readAsString();
      Object? o;
      try {
        o = jsonDecode(txt);
      } catch (_) {}
      if (o is Map && o['kv'] == 'enc1') {
        final pw = await askPassword('Add meg a jelszót a titkosított mentés megnyitásához.', false);
        if (pw == null) return;
        try {
          txt = await busy(() => decText(o as Map, pw));
        } catch (_) {
          snack('Hibás jelszó vagy sérült fájl.');
          return;
        }
      }
      confirmRestore(txt, 'A fájl nem érvényes mentés.', afterRestore);
    } catch (_) {
      snack('A fájl nem érvényes mentés.');
    }
  }

  Future<void> notifCheck(String? err) async {
    if (err != null) {
      snack(trf('Az értesítés ütemezése nem sikerült: {0}', ['$err'.split('\n').first]));
      return;
    }
    if (!await notifEnabled()) snack('Az értesítések le vannak tiltva ehhez az apphoz. Engedélyezd a telefon Beállítások → Alkalmazások → Költségvetés → Értesítések menüben.');
  }

  Future<void> setRem(bool on) async {
    st.change(() => st.remOn = on);
    if (on) {
      await notifCheck(await scheduleReminder(TimeOfDay(hour: st.remH, minute: st.remM)));
    } else {
      await cancelReminder();
    }
  }

  Future<void> pickRemTime() async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: st.remH, minute: st.remM));
    if (t == null) return;
    st.change(() {
      st.remH = t.hour;
      st.remM = t.minute;
      st.remOn = true;
    });
    await notifCheck(await scheduleReminder(t));
  }

  Future<void> testNotif(bool delayed) async {
    final r = await notifTest(delayed);
    if (r == null) {
      snack(delayed ? 'Időzített teszt értesítés beállítva: pár percen belül meg kell érkeznie (az energiatakarékos mód késleltetheti).' : 'Teszt értesítés elküldve.');
    } else if (r == 'off') {
      snack('Az értesítések le vannak tiltva ehhez az apphoz. Engedélyezd a telefon Beállítások → Alkalmazások → Költségvetés → Értesítések menüben.');
    } else {
      snack(trf('Az értesítés ütemezése nem sikerült: {0}', [r.split('\n').first]));
    }
  }

  DateTime nextDue(Rec r) {
    final n = DateTime.now();
    final t = DateTime(n.year, n.month, n.day);
    for (var k = 0; k < 3; k++) {
      final m = DateTime(t.year, t.month + k);
      final dim = DateUtils.getDaysInMonth(m.year, m.month);
      final d = DateTime(m.year, m.month, r.day < dim ? r.day : dim);
      if (!d.isBefore(t)) return d;
    }
    return t;
  }

  Future<void> editRec(Rec r) async {
    final a = TextEditingController(text: amtStr(r.amt));
    final dd = TextEditingController(text: '${r.day}');
    final n = TextEditingController(text: r.note);
    final ok = await showDialog<bool>(
        context: context,
        builder: (d) => AlertDialog(
              title: const Text('Rendszeres kifizetés szerkesztése'),
              content: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(controller: a, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('Összeg'), suffixText: st.csym)),
                TextField(controller: dd, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(labelText: tr('A hónap napja (1-31)'))),
                TextField(controller: n, decoration: InputDecoration(labelText: tr('Megjegyzés'), helperText: tr('Csak a következő hónapoktól érvényes.'))),
              ])),
              actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Mégse')), FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Mentés'))],
            ));
    final am = double.tryParse(a.text.replaceAll(' ', '').replaceAll(',', '.')), dy = int.tryParse(dd.text);
    if (ok == true && am != null && am > 0 && dy != null && dy >= 1 && dy <= 31) {
      st.change(() {
        r.amt = am;
        r.day = dy;
        r.note = n.text.trim();
      });
      rescheduleAll();
    }
  }

  String dueInfo(SG g) {
    final p = g.due.split('-');
    final y = int.parse(p[0]), m = int.parse(p[1]);
    final now = DateTime.now();
    final left = (y * 12 + m) - (now.year * 12 + now.month) + 1;
    final label = trf('Határidő: {0}. {1}', [y, dfm('MMMM', DateTime(y, m))]);
    if (g.saved >= g.target) return label;
    if (left < 1) return trf('{0}. A határidő lejárt.', [label]);
    return trf('{0}. Havonta {1} félretételével érhető el a cél ({2} hónap van hátra).', [label, ft(((g.target - g.saved) / left).ceil()), left]);
  }

  Future<void> pickDue(SG g) async {
    final p = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 90)), firstDate: DateTime.now(), lastDate: DateTime(2100), helpText: tr('Határidő (hónap)'));
    if (p != null) st.change(() => g.due = '${p.year}-${p.month.toString().padLeft(2, '0')}');
  }

  Future<String?> pinDialog(String title) async {
    final c = TextEditingController();
    return showDialog<String>(
        context: context,
        builder: (d) => AlertDialog(
              title: Text(title),
              content: TextField(controller: c, autofocus: true, obscureText: true, keyboardType: const TextInputType.numberWithOptions(decimal: true), maxLength: 4, decoration: const InputDecoration(counterText: '')),
              actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Mégse')), FilledButton(onPressed: () => Navigator.pop(d, c.text), child: const Text('OK'))],
            ));
  }

  Future<void> setPinFlow() async {
    if (st.pin.isNotEmpty) {
      final cur = await pinDialog('Jelenlegi PIN');
      if (cur == null) return;
      if (hashPin(cur) != st.pin) {
        snack('Hibás PIN.');
        return;
      }
    }
    final n1 = await pinDialog('Új PIN (4 számjegy)');
    if (n1 == null) return;
    if (!RegExp(r'^\d{4}$').hasMatch(n1)) {
      snack('A PIN pontosan 4 számjegy legyen.');
      return;
    }
    final n2 = await pinDialog('PIN megerősítése');
    if (n2 == null) return;
    if (n1 != n2) {
      snack('A két PIN nem egyezik.');
      return;
    }
    unlocked = true;
    await st.setPin(hashPin(n1));
    snack('A PIN beállítva. Az app megnyitásakor kérni fogja.');
  }

  Future<void> delPinFlow() async {
    final cur = await pinDialog('Add meg a PIN-t a törléshez');
    if (cur == null) return;
    if (hashPin(cur) != st.pin) {
      snack('Hibás PIN.');
      return;
    }
    await st.setPin('');
    snack('A PIN törölve.');
  }

  Future<void> bioToggle(bool v) async {
    if (v) {
      try {
        final la = LocalAuthentication();
        final avail = await la.getAvailableBiometrics();
        if (!await la.isDeviceSupported() || avail.isEmpty) {
          snack('Ezen az eszközön nincs beállított biometrikus azonosítás (ujjlenyomat vagy arc). Állítsd be a telefon beállításaiban.');
          return;
        }
        final ok = await la.authenticate(localizedReason: tr('Biometrikus feloldás bekapcsolása'), options: const AuthenticationOptions(biometricOnly: true));
        if (!ok) return;
      } catch (_) {
        snack('A biometrikus azonosítás ezen az eszközön nem érhető el.');
        return;
      }
    }
    await st.setBio(v);
  }

  Widget recSection() {
    String name(Rec r) => r.type == 'tr' ? 'Átvezetés' : (st.itemName(r.cat, r.item).isNotEmpty ? st.itemName(r.cat, r.item) : (r.type == 'in' ? (st.icName(r.cat).isEmpty ? 'Bevétel' : st.icName(r.cat)) : (st.catName(r.cat).isEmpty ? 'Kiadás' : st.catName(r.cat))));
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Padding(padding: const EdgeInsets.only(top: 20, bottom: 6), child: Text('Rendszeres kifizetések', style: Theme.of(context).textTheme.titleMedium)),
      if (st.rec.isEmpty) const Text('Nincs rendszeres kifizetés. Új tételnél jelöld be a „Rendszeres kifizetés (havonta)” négyzetet.'),
      for (final r in st.rec)
        Card(
            child: ListTile(
          title: Text(name(r)),
          subtitle: Text(trf('Minden hónap {0}. napján, következő: {1}{2}', [r.day, dfm('yyyy. MMMM d.', nextDue(r)), r.note.isEmpty ? '' : '\n${r.note}']), style: daysBetween(DateTime.now(), nextDue(r)) <= 3 ? const TextStyle(color: cOut) : null),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(ft(r.amt)),
            IconButton(icon: const Icon(Icons.edit_outlined), tooltip: tr('Szerkesztés'), onPressed: () => editRec(r)),
            IconButton(
                icon: const Icon(Icons.delete_outline),
                onPressed: () => ask('Biztosan törlöd a rendszeres kifizetést? A már rögzített tételek megmaradnak.', () {
                      st.change(() => st.rec.remove(r));
                      rescheduleAll();
                    })),
          ]),
        )),
    ]);
  }

  List<Widget> settingsExtra() {
    final h = Theme.of(context).textTheme.titleSmall;
    Widget head(String s) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 6), child: Text(s, style: h));
    Widget group(String key, String title, IconData icon, List<Widget> kids) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ExpansionTile(
            key: PageStorageKey('set_$key'),
            leading: Icon(icon),
            title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            shape: const Border(),
            collapsedShape: const Border(),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: kids));
    return [
      group('acc', 'Funkciók', Icons.tune, [
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Devizaszámla használata'),
            subtitle: const Text('A devizaszámla opcionális funkció: külön számla idegen pénznemekben, a forint számlától teljesen függetlenül, pénzváltással. Kikapcsolt állapotban semmi nem jelenik meg belőle az appban, az adataid pedig megmaradnak.'),
            value: st.fxOn,
            onChanged: (v) {
              if (v) {
                st.setFxOn(true);
                snack('Devizaszámla bekapcsolva. Az Áttekintésen a Deviza gombbal érheted el.');
              } else {
                ask('Biztosan kikapcsolod a devizaszámlát? A funkció (Deviza gomb, pénzváltás) elrejtődik, de az adataid megmaradnak, és később újra bekapcsolhatod.', () async {
                  await st.setFxOn(false);
                  if (!mounted) return;
                  setState(() {});
                });
              }
            }),
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Hangos bevitel használata'),
            subtitle: const Text('Hangos bevitel (opcionális): az összeg mellett megjelenik egy mikrofon gomb, amellyel kimondhatod a kiadást. A hangfelismerést a telefon rendszere végzi.'),
            value: st.voiceOn,
            onChanged: (v) {
              st.setVoiceOn(v);
              snack(v ? 'Hangos bevitel bekapcsolva.' : 'Hangos bevitel kikapcsolva.');
            }),
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Nyugta beolvasása használata'),
            subtitle: const Text('Nyugta beolvasása (opcionális): fotóból felismeri a nyugta tételeit, és egy kiadásként rögzíti. A felismerés a készüléken történik.'),
            value: st.scanOn,
            onChanged: (v) {
              st.setScanOn(v);
              snack(v ? 'Nyugta beolvasása bekapcsolva.' : 'Nyugta beolvasása kikapcsolva.');
            }),
        if (st.fxOn && st.ws == 'fx' && st.cur.isNotEmpty) ...[
          head('Deviza'),
          Text(trf('Aktív deviza: {0}', [st.cur]), style: const TextStyle(fontWeight: FontWeight.w700)),
          const Text('Az itt megadott adatok csak ehhez a devizához tartoznak, a forint és a többi deviza adatait nem érintik.', style: TextStyle(fontSize: 12)),
          TextButton(onPressed: () => confirmDelCur(st.cur), child: const Text('Deviza törlése', style: TextStyle(color: cOut))),
        ],
      ]),
      group('look', 'Megjelenés és nyelv', Icons.palette_outlined, [
        head('Nyelv'),
        SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'hu', label: m.Text('Magyar')), ButtonSegment(value: 'en', label: m.Text('English'))],
            selected: {st.lang},
            onSelectionChanged: (v) async {
              await st.setLang(v.first);
              rescheduleAll();
            }),
        head('Téma'),
        SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'system', label: Text('Rendszer')), ButtonSegment(value: 'light', label: Text('Világos')), ButtonSegment(value: 'dark', label: Text('Sötét'))],
            selected: {st.theme},
            onSelectionChanged: (s) => st.change(() => st.theme = s.first)),
        head('Betűméret'),
        SegmentedButton<double>(
            segments: const [ButtonSegment(value: 1.0, label: Text('Normál')), ButtonSegment(value: 1.15, label: Text('Nagy')), ButtonSegment(value: 1.3, label: Text('Nagyobb'))],
            selected: {st.fs},
            onSelectionChanged: (v) => st.setFs(v.first)),
      ]),
      group('sec', 'Biztonság', Icons.lock_outline, [
        if (st.pin.isEmpty)
          OutlinedButton(onPressed: setPinFlow, child: const Text('PIN beállítása'))
        else
          Wrap(spacing: 8, children: [OutlinedButton(onPressed: setPinFlow, child: const Text('PIN módosítása')), OutlinedButton(onPressed: delPinFlow, child: const Text('PIN törlése'))]),
        SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Biometrikus feloldás (ujjlenyomat vagy arc)'),
            subtitle: st.pin.isEmpty ? const Text('Előbb állíts be PIN-t.') : null,
            value: st.bio && st.pin.isNotEmpty,
            onChanged: st.pin.isEmpty ? (_) => snack('Biometrikus feloldáshoz előbb állíts be PIN-t.') : bioToggle),
        const Padding(padding: EdgeInsets.only(top: 4), child: Text('A PIN nem titkosítja az adataidat, csak az app megnyitását védi.', style: TextStyle(fontSize: 12))),
      ]),
      group('notif', 'Értesítések', Icons.notifications_outlined, [
        head('Napi emlékeztető'),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: st.remOn, onChanged: setRem, title: const Text('Emlékeztető a költések rögzítésére'), subtitle: Text(trf('Minden nap {0}:{1}', [st.remH.toString().padLeft(2, '0'), st.remM.toString().padLeft(2, '0')]))),
        OutlinedButton(onPressed: pickRemTime, child: const Text('Időpont módosítása')),
        Wrap(spacing: 8, children: [
          OutlinedButton(onPressed: () => testNotif(false), child: const Text('Teszt értesítés most')),
          OutlinedButton(onPressed: () => testNotif(true), child: const Text('Teszt 1 perc múlva')),
        ]),
        const Padding(padding: EdgeInsets.only(top: 4), child: Text('Ha az értesítés nem érkezik meg: Beállítások → Alkalmazások → Költségvetés → Akkumulátor → Nincs korlátozás, és kapcsold be az automatikus indítást (Xiaomi).', style: TextStyle(fontSize: 12))),
        head('Fizetési emlékeztető'),
        DropdownButtonFormField<int>(
            value: st.payRem,
            decoration: InputDecoration(border: OutlineInputBorder(), helperText: tr('Értesítés a rendszeres kifizetések előtt, reggel 9 órakor.')),
            items: const [
              DropdownMenuItem(value: -1, child: Text('Ki')),
              DropdownMenuItem(value: 0, child: Text('Az esedékesség napján')),
              DropdownMenuItem(value: 1, child: Text('1 nappal előtte')),
              DropdownMenuItem(value: 3, child: Text('3 nappal előtte')),
            ],
            onChanged: (v) async {
              st.change(() => st.payRem = v ?? 1);
              if ((v ?? 1) >= 0) await notifPerm();
              await rescheduleAll();
            }),
      ]),
      group('data', 'Mentés és adatok', Icons.save_outlined, [
        head('Mentés készítése'),
        Wrap(spacing: 8, children: [
          OutlinedButton(onPressed: saveBackupFile, child: const Text('Mentés fájlként')),
          OutlinedButton(onPressed: saveEncFile, child: const Text('Titkosított mentés')),
          OutlinedButton(
              onPressed: () async {
                copy(await st.fullBackup(), 'A mentés a vágólapra másolva. Illeszd be egy jegyzetbe vagy küldd el magadnak.');
                st.markBackup();
              },
              child: const Text('Mentés másolása')),
          OutlinedButton(onPressed: () => copy(st.toCsv(), 'A CSV a vágólapra másolva.'), child: const Text('CSV másolása')),
        ]),
        head('Visszatöltés'),
        Wrap(spacing: 8, children: [
          OutlinedButton(onPressed: restoreFromFile, child: const Text('Visszatöltés fájlból')),
          OutlinedButton(onPressed: restoreBackup, child: const Text('Visszatöltés vágólapról')),
        ]),
        head('Automatikus mentések'),
        snapSection(),
        head('Adatok törlése'),
        OutlinedButton(
            style: OutlinedButton.styleFrom(foregroundColor: cOut),
            onPressed: () => ask('Biztosan törlöd az összes adatot? Ezt nem lehet visszavonni.', () {
                  st.wipe();
                  rescheduleAll();
                  setState(() => tab = 0);
                  Future.microtask(initDialog);
                }),
            child: const Text('Minden adat törlése')),
        const Padding(padding: EdgeInsets.only(top: 4), child: Text('Letörli a tételeket, kategóriákat, célokat és a kezdő egyenleget. A PIN és a megjelenés megmarad. Előbb készíts mentést.', style: TextStyle(fontSize: 12))),
      ]),
      group('help', 'Súgó', Icons.help_outline, [
        OutlinedButton(onPressed: showTutorial, child: const Text('Bemutató megnyitása')),
        OutlinedButton(onPressed: reportError, child: const Text('Hiba jelentése')),
        OutlinedButton(
            onPressed: () async {
              try {
                await launchUrl(Uri.parse('https://mano97.github.io/koltsegvetes-web/adatvedelem.html'), mode: LaunchMode.externalApplication);
              } catch (_) {
                snack('Nem sikerült megnyitni a böngészőt.');
              }
            },
            child: const Text('Adatvédelmi nyilatkozat')),
        Padding(padding: const EdgeInsets.only(top: 6), child: Text('A jelentés csak a hibanaplót, az app verzióját és a tételek számát tartalmazza, a tételeid tartalmát nem.', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))),
        Padding(padding: const EdgeInsets.only(top: 6), child: m.Text('${tr('Verzió')} $kVer', style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor))),
      ]),
    ];
  }

  void openSheet({Tx? edit, DateTime? date, String newType = 'out', bool lock = false, VoiceRes? pre}) {
    var type = edit?.type ?? pre?.type ?? newType, acc = edit?.acc ?? 'card', item = edit?.item ?? pre?.item ?? '';
    var cat = edit?.cat ?? ((pre != null && pre.cat.isNotEmpty) ? pre.cat : ((pre?.type ?? newType) == 'in' || st.cats.isEmpty ? '' : st.cats.first.id));
    var d = edit?.date ?? date ?? DateTime.now();
    var rep = false;
    var okFund = false;
    final amt = TextEditingController(text: edit != null ? amtStr(edit.amt) : ((pre != null && pre.amt > 0) ? amtStr(pre.amt) : ''));
    final note = TextEditingController(text: edit?.note ?? pre?.note ?? '');
    final tags = TextEditingController(text: edit?.tags.join(', ') ?? '');
    final txId = edit?.id ?? uid();
    var hasPh = edit?.ph ?? false, phDel = false, tplSave = false, phRev = 0, listening = false;
    final nn = TextEditingController();
    String? err;
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
              final cs = st.cats.where((c) => c.id == cat).toList();
              final items = cs.isEmpty ? <Item>[] : cs.first.items;
              if (item != '' && item != '__new' && !items.any((i) => i.id == item)) item = '';
              void save() {
                final a = double.tryParse(amt.text.replaceAll(' ', '').replaceAll(',', '.'));
                if (a == null || a <= 0) {
                  setS(() => err = 'Add meg az összeget.');
                  return;
                }
                if (type != 'in' && !okFund) {
                  final keep = st.txs;
                  st.txs = keep.where((x) => x.id != edit?.id).toList();
                  final av = st.bal(acc);
                  st.txs = keep;
                  if (av < a) {
                    ask(trf('Nincs elég fedezet ({0}): elérhető {1}, a tétel összege {2}. Biztosan rögzíted?', [accName(acc), ft(av < 0 ? 0 : av), ft(a)]), () {
                      okFund = true;
                      save();
                    });
                    return;
                  }
                }
                var c = '', i = '';
                Item? ni;
                if (type == 'out') {
                  if (cat.isEmpty) {
                    setS(() => err = 'Előbb hozz létre egy kategóriát a Kategóriák menüben (☰).');
                    return;
                  }
                  c = cat;
                  i = item;
                  if (item == '__new') {
                    i = '';
                    final nm = nn.text.trim();
                    if (nm.isNotEmpty) {
                      final ex = items.where((x) => x.name.toLowerCase() == nm.toLowerCase());
                      if (ex.isNotEmpty) {
                        i = ex.first.id;
                      } else {
                        ni = Item(uid(), nm);
                        i = ni.id;
                      }
                    }
                  }
                }
                if (type == 'in') c = st.icats.any((x) => x.id == cat) ? cat : '';
                final tg = tags.text.split(',').map((x) => x.trim().replaceFirst(RegExp(r'^#'), '')).where((x) => x.isNotEmpty).take(10).toList();
                st.change(() {
                  if (ni != null) st.cats.firstWhere((x) => x.id == cat).items.add(ni);
                  final t = Tx(id: txId, type: type, acc: acc, to: type == 'tr' ? (acc == 'cash' ? 'card' : 'cash') : '', cat: c, item: i, amt: a, date: DateTime(d.year, d.month, d.day), note: note.text.trim(), tags: type == 'tr' ? <String>[] : tg, ph: type != 'tr' && hasPh && !phDel, rl: edit?.rl ?? <Map<String, dynamic>>[], rs: edit?.rs ?? '');
                  if (edit != null) {
                    final idx = st.txs.indexWhere((x) => x.id == edit.id);
                    if (idx >= 0) st.txs[idx] = t;
                  } else {
                    st.txs.add(t);
                    if (tplSave && type != 'tr') st.tpl.add(Tpl(uid(), type == 'in' ? (st.icName(c).isEmpty ? 'Bevétel' : st.icName(c)) : (st.itemName(c, i).isEmpty ? st.catName(c) : st.itemName(c, i)), type, acc, c, i, a, t.note, tg));
                    if (rep && type != 'in') st.rec.add(Rec(uid(), type, acc, t.to, c, i, t.note, '${d.year}-${d.month.toString().padLeft(2, '0')}', a, d.day));
                  }
                  st.month = DateTime(d.year, d.month);
                });
                if (phDel && edit != null) {
                  try {
                    File('$recDir/$txId.jpg').deleteSync();
                  } catch (_) {}
                }
                sel = DateTime(d.year, d.month, d.day);
                if (rep && type != 'in') rescheduleAll();
                HapticFeedback.selectionClick();
                Navigator.pop(ctx);
              }

              return Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(ctx).viewInsets.bottom + 16),
                  child: SingleChildScrollView(
                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    if (type == 'tr' || lock)
                      Padding(padding: const EdgeInsets.only(bottom: 4), child: Text(type == 'tr' ? 'Átvezetés' : (type == 'in' ? 'Bevétel' : 'Kiadás'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)))
                    else
                      SegmentedButton<String>(segments: const [ButtonSegment(value: 'out', label: Text('Kiadás')), ButtonSegment(value: 'in', label: Text('Bevétel'))], selected: {type}, onSelectionChanged: (s) => setS(() {
                            type = s.first;
                            cat = type == 'in' || st.cats.isEmpty ? '' : st.cats.first.id;
                            item = '';
                          })),
                    if (st.ws == 'fx' && st.fxCodes.length > 1 && edit == null && type != 'tr') ...[
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                          value: st.cur,
                          decoration: InputDecoration(labelText: tr('Deviza'), border: const OutlineInputBorder()),
                          items: [for (final c in st.fxCodes) DropdownMenuItem(value: c, child: m.Text(curLabel(c), overflow: TextOverflow.ellipsis))],
                          onChanged: (v) async {
                            if (v == null || v == st.cur) return;
                            await st.switchTo('fx', v);
                            if (!mounted) return;
                            setState(() {});
                            setS(() {
                              cat = type == 'in' || st.cats.isEmpty ? '' : st.cats.first.id;
                              item = '';
                              okFund = false;
                            });
                          }),
                    ],
                    if (type == 'in') ...[
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                          value: st.icats.any((c) => c.id == cat) ? cat : '',
                          decoration: InputDecoration(labelText: tr('Bevételi kategória'), border: OutlineInputBorder()),
                          items: [const DropdownMenuItem(value: '', child: Text('Nincs megadva')), for (final c in st.icats) DropdownMenuItem(value: c.id, child: Text(c.name))],
                          onChanged: (v) => setS(() => cat = v ?? '')),
                    ],
                    const SizedBox(height: 12),
                    TextField(controller: amt, autofocus: edit == null, textInputAction: TextInputAction.done, onSubmitted: (_) => save(), keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: InputDecoration(
                            labelText: tr('Összeg'),
                            suffixText: st.csym,
                            border: const OutlineInputBorder(),
                            suffixIcon: (type == 'tr' || !st.voiceOn)
                                ? null
                                : IconButton(
                                    tooltip: tr('Hangos bevitel'),
                                    icon: Icon(listening ? Icons.mic : Icons.mic_none),
                                    onPressed: () async {
                                      setS(() => listening = true);
                                      final r = await listenVoice();
                                      if (r == null) {
                                        setS(() => listening = false);
                                        return;
                                      }
                                      final p = parseVoice(r, st.cats, st.icats);
                                      setS(() {
                                        listening = false;
                                        if (p.amt > 0) amt.text = amtStr(p.amt);
                                        if (!lock) type = p.type;
                                        if (type == 'out') {
                                          if (p.cat.isNotEmpty) cat = p.cat;
                                          item = p.item;
                                        } else if (type == 'in') {
                                          cat = p.cat;
                                        }
                                        if (p.note.isNotEmpty) note.text = note.text.isEmpty ? p.note : '${note.text} ${p.note}';
                                      });
                                    }))),
                    const SizedBox(height: 12),
                    if (type == 'tr') const Padding(padding: EdgeInsets.only(bottom: 4), child: Text('Honnan')),
                    SegmentedButton<String>(segments: const [ButtonSegment(value: 'cash', label: Text('Készpénz')), ButtonSegment(value: 'card', label: Text('Bankkártya'))], selected: {acc}, onSelectionChanged: (s) => setS(() => acc = s.first)),
                    if (type == 'tr') Padding(padding: const EdgeInsets.only(top: 8), child: Text(trf('Hová: {0}', [accName(acc == 'cash' ? 'card' : 'cash')]))),
                    if (type == 'tr') Padding(padding: const EdgeInsets.only(top: 4), child: Text(trf('Elérhető készpénz: {0}, bankkártyán: {1}', [ft(st.bal('cash')), ft(st.bal('card'))]))),
                    if (type == 'out') ...[
                      const SizedBox(height: 12),
                      if (st.cats.isEmpty)
                        const Text('Előbb hozz létre egy kategóriát a Kategóriák menüben (☰).')
                      else ...[
                        DropdownButtonFormField<String>(
                            value: cat,
                            decoration: InputDecoration(labelText: tr('Kategória'), border: OutlineInputBorder()),
                            items: [for (final c in st.cats) DropdownMenuItem(value: c.id, child: Text(c.name))],
                            onChanged: (v) => setS(() {
                                  cat = v ?? cat;
                                  item = '';
                                })),
                        const SizedBox(height: 12),
                        DropdownButtonFormField<String>(
                            value: item,
                            decoration: InputDecoration(labelText: tr('Tétel'), border: OutlineInputBorder()),
                            items: [
                              const DropdownMenuItem(value: '', child: Text('Nincs megadva')),
                              for (final i in items) DropdownMenuItem(value: i.id, child: Text(i.name)),
                            ],
                            onChanged: (v) => setS(() {
                                  item = v ?? '';
                                  if (edit == null && type == 'out' && item.isNotEmpty && item != '__new' && amt.text.isEmpty) {
                                    final ls = st.txs.where((t) => t.type == 'out' && t.cat == cat && t.item == item && !t.linked).toList()..sort((a, b) => b.date.compareTo(a.date));
                                    if (ls.isNotEmpty) {
                                      amt.text = amtStr(ls.first.amt);
                                      acc = ls.first.acc;
                                    }
                                  }
                                })),
                        if (item == '__new') ...[const SizedBox(height: 12), TextField(controller: nn, decoration: InputDecoration(labelText: tr('Új tétel neve'), border: OutlineInputBorder()))],
                      ],
                    ],
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                        onPressed: () async {
                          final p = await showDatePicker(context: ctx, initialDate: d, firstDate: DateTime(2000), lastDate: DateTime(2100));
                          if (p != null) setS(() => d = p);
                        },
                        icon: const Icon(Icons.calendar_month),
                        label: Text(dfm('yyyy. MMMM d.', d))),
                    const SizedBox(height: 12),
                    TextField(controller: note, minLines: 1, maxLines: 3, decoration: InputDecoration(labelText: tr('Megjegyzés'), border: OutlineInputBorder())),
                    if (type != 'tr') ...[
                      const SizedBox(height: 12),
                      TextField(controller: tags, decoration: InputDecoration(labelText: tr('Címkék'), hintText: tr('Pl. nyaralás, ajándék (vesszővel elválasztva)'), border: const OutlineInputBorder())),
                      const SizedBox(height: 12),
                      Row(children: [
                        if (hasPh) ...[
                          GestureDetector(
                              onTap: () => showDialog<void>(context: ctx, builder: (dd) => Dialog(child: InteractiveViewer(child: Image.file(File('$recDir/$txId.jpg'), key: ValueKey('b$phRev'))))),
                              child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File('$recDir/$txId.jpg'), key: ValueKey('t$phRev'), width: 64, height: 64, fit: BoxFit.cover))),
                          const SizedBox(width: 10),
                        ],
                        Expanded(
                            child: Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [
                          OutlinedButton.icon(
                              onPressed: () async {
                                try {
                                  final x = await ImagePicker().pickImage(source: ImageSource.camera, maxWidth: 1280, imageQuality: 72);
                                  if (x == null) return;
                                  await File(x.path).copy('$recDir/$txId.jpg');
                                  setS(() {
                                    hasPh = true;
                                    phDel = false;
                                    phRev++;
                                  });
                                } catch (_) {
                                  snack('A fotó mentése nem sikerült.');
                                }
                              },
                              icon: const Icon(Icons.photo_camera_outlined),
                              label: Text(hasPh ? 'Fotó cseréje' : 'Bizonylat fotózása')),
                          IconButton(
                              tooltip: tr('Fotó'),
                              icon: const Icon(Icons.photo_library_outlined),
                              onPressed: () async {
                                try {
                                  final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 72);
                                  if (x == null) return;
                                  await File(x.path).copy('$recDir/$txId.jpg');
                                  setS(() {
                                    hasPh = true;
                                    phDel = false;
                                    phRev++;
                                  });
                                } catch (_) {
                                  snack('A fotó mentése nem sikerült.');
                                }
                              }),
                          if (hasPh)
                            TextButton(
                                onPressed: () => setS(() {
                                      hasPh = false;
                                      phDel = true;
                                    }),
                                child: const Text('Fotó törlése')),
                        ])),
                      ]),
                      if (edit == null && type == 'out' && st.scanOn)
                        Align(
                            alignment: Alignment.centerLeft,
                            child: OutlinedButton.icon(
                                onPressed: () {
                                  Navigator.pop(ctx);
                                  scanReceipt(ImageSource.camera);
                                },
                                icon: const Icon(Icons.receipt_long_outlined),
                                label: const Text('Nyugta beolvasása'))),
                      if (edit == null) CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, value: tplSave, onChanged: (v) => setS(() => tplSave = v ?? false), title: const Text('Mentés sablonként')),
                    ],
                    if (edit == null && type != 'in') CheckboxListTile(contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, value: rep, onChanged: (v) => setS(() => rep = v ?? false), title: const Text('Rendszeres kifizetés (havonta)')),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(err!, style: const TextStyle(color: cOut))),
                    const SizedBox(height: 16),
                    Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                      if (edit != null)
                        TextButton(
                            onPressed: () {
                              final id = edit.id;
                              st.change(() {
                                st.trash.add(edit);
                                st.txs.removeWhere((x) => x.id == id);
                              });
                              Navigator.pop(ctx);
                              snackUndo('Tétel törölve.', () => undelTx([id]));
                            },
                            child: const Text('Törlés')),
                      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Mégse')),
                      const SizedBox(width: 8),
                      FilledButton(onPressed: save, child: const Text('Mentés')),
                    ]),
                  ])));
            }));
  }
}
